from DataDictionaryAdminApp.utils.normalizers import (
    canonical_portfolio_label,
    editable_from_mapping_type,
    generate_physical_name,
    generate_tech_logic,
    mapping_type_from_value,
    portfolio_from_sheet_name,
)


def test_physical_name_example():
    assert generate_physical_name("Land & Buildings(Gross)") == "gross land bldgs"


def test_tech_logic_keeps_prj_expression():
    source = (
        "Total Policy Income / Total Premiums (PRJ2946) = P&C Net Premiums Earned (PRJ2974) "
        "+ Life & Health Net Premiums Earned (PRJ436) + Life & Health Policy Revenue (PRJ2535)"
    )
    assert generate_tech_logic(source) == "(PRJ2946) = (PRJ2974) + (PRJ436) + (PRJ2535)"


def test_portfolio_detection_and_canonicalization():
    assert portfolio_from_sheet_name("FI Insurance Attributes") == "Insurance"
    assert portfolio_from_sheet_name("Insurance Attribute") == "Insurance"
    assert portfolio_from_sheet_name("FI Bank Attributes") == "Banks"
    assert portfolio_from_sheet_name("Bank Attribute") == "Banks"
    assert portfolio_from_sheet_name("UKC-General Industries") == "UKC"
    assert canonical_portfolio_label("Banks") == "FI Banks"
    assert canonical_portfolio_label("Insurance") == "FI Insurance"


def test_mapping_rules():
    assert editable_from_mapping_type("Calculated") == "N"
    assert editable_from_mapping_type("Reported") == "Y"
    assert editable_from_mapping_type("Repeated") == "Y"
    assert mapping_type_from_value("Repeated", "Calculated") == "Calculated"
    assert mapping_type_from_value("Repeated", "Reported") == "Reported"
