# Validation Results

Validation for the business/display split and PostgreSQL physical-schema update:

- 106 automated tests passed.
- Python `compileall` passed for application source and tests.
- FastAPI/OpenAPI generation passed with 29 API paths.
- Staging/final `prj_attribute_business_rules_new_test` ORM tables contain only the requested business/LLM columns.
- New staging/final `prj_attribute_display_test` tables are one-to-one with business scopes through `scope_id`.
- Existing scope-specific Attribute Definition, Attribute Description, Segment and Report Type are retained on display rows so prior functionality is not lost.
- Repository/service logic rejoins business + display for View Latest, Edit Attribute, prompts, Delta, Finalize and S3 export.
- SQL Server remains on physical `dbo` / `stg` schemas.
- PostgreSQL runtime uses SQLAlchemy schema translation `dbo -> prj_dbd` and `stg -> prj_stage`.
- PostgreSQL fresh-install DDL creates `prj_dbd` and `prj_stage`; existing-database migration 005 moves prior physical tables and splits business/display data while preserving `scope_id`.
- SQL Server migration 005 preserves existing `scope_id` values with `IDENTITY_INSERT`, creates display rows, and replaces the old combined business-rule table transactionally.
- ORM foreign keys mirror the relational contract for master, portfolio, scope and display references.
- PostgreSQL audit history records physical schema names (`prj_dbd` / `prj_stage`); SQL Server audit history retains `dbo` / `stg`.
- Existing Create/Edit, bulk upload modes, physical-name validation, filters, soft delete/reactivate, Cleanup, Prompt Management, Finalize and role controls remain covered by the regression suite.

No live SQL Server or PostgreSQL server is available in this build environment, so the DDL migration itself must still be executed and followed by the supplied `002_validate_schema.sql` in the target DEV environment before enabling writes.


## 2026-09-01 - SQL Server modal interaction + PostgreSQL Create bootstrap fix

- Removed the aggressive generic/first-child `streamlit-modal` CSS override that could leave only the grey backdrop clickable. Create/Edit now target only their keyed modal container and keep the 1900px / 96vw wide centered layout.
- PostgreSQL `/lookups/next-prj-id` now reads the required physical schemas directly: `prj_dbd` + `prj_stage`.
- If required PostgreSQL tables are missing, the API now returns an actionable HTTP 503 schema-readiness message instead of a generic HTTP 500.
- Full pytest suite: PASS.
- Python compileall: PASS.
- FastAPI OpenAPI import: PASS (29 paths).

## 2026-09-01 - Native Create/Edit dialog + PostgreSQL portfolio reference alignment
- Create/Edit moved to Streamlit native `st.dialog` so the dialog is viewport-centered by the framework on laptop/desktop.
- Native dialog is widened responsively to `min(96vw, 1600px)` without overriding overlay positioning.
- Create/Edit are invoked directly from the corresponding button click; no persistent `show_create` / `show_edit` open flag remains, preventing X-dismissed dialogs from reopening on later reruns.
- SQL Server portfolio reference remains `dbo.prj_portfolio_reference_new_test`.
- PostgreSQL portfolio reference runtime model is `prj_dbd.prj_portfolio_reference`.
- PostgreSQL fresh DDL, validator and 005 migration aligned to `prj_dbd.prj_portfolio_reference`.
- Added `sql/postgres/006_align_portfolio_reference.sql` to repoint existing PostgreSQL `port_ref_id` FKs safely.
- Full regression suite: 116/116 tests passed.
- Python compileall: PASS.
- FastAPI/OpenAPI import: PASS, 29 paths.
