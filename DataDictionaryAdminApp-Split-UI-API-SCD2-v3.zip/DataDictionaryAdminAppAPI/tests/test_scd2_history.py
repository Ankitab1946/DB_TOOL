from pathlib import Path

from DataDictionaryAdminAppAPI.model.entities import Scd2RowHistory


def test_scd2_entity_contract():
    columns = set(Scd2RowHistory.__table__.c.keys())
    assert {
        "history_id", "source_schema", "source_table", "record_key", "version_number",
        "effective_from", "effective_to", "is_current", "operation", "row_data",
        "source_operation", "changed_by", "changed_at",
    } <= columns


def test_scd2_migrations_cover_all_default_tables():
    root = Path(__file__).parents[1] / "src" / "DataDictionaryAdminAppAPI" / "sql"
    pg = (root / "postgres" / "011_add_scd2_history.sql").read_text()
    sqlserver = (root / "011_add_scd2_history.sql").read_text()
    for table in (
        "raw_prj_attribute_new_test", "prj_attribute_master_new_test",
        "prj_attribute_business_rules_new_test", "prj_attribute_display_test",
        "prj_portfolio_reference", "prj_data_sources", "audit_table_new_test",
    ):
        assert table in pg
    for table in (
        "raw_prj_attribute_new_test", "prj_attribute_master_new_test",
        "prj_attribute_business_rules_new_test", "prj_attribute_display_test",
        "prj_portfolio_reference_new_test", "prj_data_sources", "audit_table_new_test",
    ):
        assert table in sqlserver


def test_scd2_endpoint_is_additive():
    source = (Path(__file__).parents[1] / "src" / "DataDictionaryAdminAppAPI" / "api" / "routers" / "audit.py").read_text()
    assert '@router.get("/scd2-history")' in source
    assert '@router.get("")' in source
    assert '@router.post("/filter")' in source


def test_scd2_rolls_versions_without_changing_operational_keys():
    from sqlalchemy import create_engine, text
    from sqlalchemy.orm import Session
    from DataDictionaryAdminAppAPI.repositories.data_dictionary_repository import DataDictionaryRepository

    engine = create_engine("sqlite+pysqlite:///:memory:", future=True)
    with engine.begin() as conn:
        conn.exec_driver_sql("ATTACH DATABASE ':memory:' AS dbo")
        conn.exec_driver_sql("""
            CREATE TABLE dbo.scd2_row_history (
                history_id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_schema TEXT NOT NULL,
                source_table TEXT NOT NULL,
                record_key TEXT NOT NULL,
                version_number INTEGER NOT NULL,
                effective_from DATETIME NOT NULL,
                effective_to DATETIME NULL,
                is_current BOOLEAN NOT NULL,
                operation TEXT NOT NULL,
                row_data TEXT NULL,
                source_operation TEXT NULL,
                changed_by TEXT NOT NULL,
                changed_at DATETIME NOT NULL,
                UNIQUE(source_schema, source_table, record_key, version_number)
            )
        """)
    with Session(engine) as session:
        repo = DataDictionaryRepository(session)
        repo.scd2_version("dbo", "sample_table", "K1", "INSERT", None, {"value": "A"}, "tester")
        repo.scd2_version("dbo", "sample_table", "K1", "UPDATE", {"value": "A"}, {"value": "B"}, "tester")
        session.commit()
        rows = session.execute(text("""
            SELECT version_number, is_current, operation, row_data
            FROM dbo.scd2_row_history
            WHERE source_table='sample_table' AND record_key='K1'
            ORDER BY version_number
        """)).all()
        assert len(rows) == 2
        assert rows[0][0] == 1 and bool(rows[0][1]) is False and rows[0][2] == "INSERT"
        assert rows[1][0] == 2 and bool(rows[1][1]) is True and rows[1][2] == "UPDATE"
        assert '"value": "B"' in rows[1][3]
