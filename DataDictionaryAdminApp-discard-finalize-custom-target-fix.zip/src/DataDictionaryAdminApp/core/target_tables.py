"""Authoritative logical table contract and request-level target table mapping.

SQL Server uses the logical schemas directly (dbo/stg). PostgreSQL translates
``dbo -> PG_SCHEMA`` (``prj_dbd`` by default) and ``stg -> prj_stage`` in the
SQLAlchemy engine.

The six staging/final dictionary table *names* may be overridden per request by
Streamlit.  Schemas, raw/audit tables, and reference tables stay fixed so the
existing governance and lookup contracts are not destabilized.
"""
from __future__ import annotations

import re
from collections.abc import Mapping

RAW_ATTRIBUTE = "dbo.raw_prj_attribute_new_test"
PORTFOLIO_REFERENCE = "dbo.prj_portfolio_reference_new_test"
POSTGRES_PORTFOLIO_REFERENCE = "prj_dbd.prj_portfolio_reference"
DATA_SOURCES = "dbo.prj_data_sources"  # Existing read-only dependency. Never created by this app.
AUDIT = "dbo.audit_table_new_test"
STG_ATTRIBUTE_MASTER = "stg.prj_attribute_master_new_test"
STG_ATTRIBUTE_BUSINESS_RULES = "stg.prj_attribute_business_rules_new_test"
STG_ATTRIBUTE_DISPLAY = "stg.prj_attribute_display_test"
ATTRIBUTE_MASTER = "dbo.prj_attribute_master_new_test"
ATTRIBUTE_BUSINESS_RULES = "dbo.prj_attribute_business_rules_new_test"
ATTRIBUTE_DISPLAY = "dbo.prj_attribute_display_test"

POSTGRES_SCHEMA_MAP = {"dbo": "prj_dbd", "stg": "prj_stage"}

# Only these application-managed staging/final names are user-configurable.
# Raw, audit, portfolio and source-reference tables intentionally remain fixed.
TARGET_TABLE_DEFAULTS: dict[str, str] = {
    "stg_master": "prj_attribute_master_new_test",
    "stg_business": "prj_attribute_business_rules_new_test",
    "stg_display": "prj_attribute_display_test",
    "final_master": "prj_attribute_master_new_test",
    "final_business": "prj_attribute_business_rules_new_test",
    "final_display": "prj_attribute_display_test",
}

TARGET_TABLE_HEADERS: dict[str, str] = {
    "stg_master": "X-Table-Stg-Master",
    "stg_business": "X-Table-Stg-Business",
    "stg_display": "X-Table-Stg-Display",
    "final_master": "X-Table-Final-Master",
    "final_business": "X-Table-Final-Business",
    "final_display": "X-Table-Final-Display",
}

TARGET_TABLE_LABELS: dict[str, str] = {
    "stg_master": "Attribute Master",
    "stg_business": "Business Rules",
    "stg_display": "Attribute Display",
    "final_master": "Attribute Master",
    "final_business": "Business Rules",
    "final_display": "Attribute Display",
}

_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,127}$")


def validate_table_name(value: str) -> str:
    """Validate a user-supplied table basename and return its normalized value."""
    name = str(value or "").strip()
    if not _IDENTIFIER_RE.fullmatch(name):
        raise ValueError(
            "Table names must start with a letter/underscore and contain only letters, numbers, and underscores "
            "(maximum 128 characters)."
        )
    return name



def validate_target_table_set(names: Mapping[str, str]) -> dict[str, str]:
    """Validate all six target names and prevent same-schema collisions."""
    validated = {key: validate_table_name(str(names.get(key) or TARGET_TABLE_DEFAULTS[key])) for key in TARGET_TABLE_DEFAULTS}
    staging = [validated[key].casefold() for key in ("stg_master", "stg_business", "stg_display")]
    final = [validated[key].casefold() for key in ("final_master", "final_business", "final_display")]
    if len(set(staging)) != len(staging):
        raise ValueError("Staging Attribute Master, Business Rules and Attribute Display must use different table names.")
    if len(set(final)) != len(final):
        raise ValueError("Final Attribute Master, Business Rules and Attribute Display must use different table names.")
    return validated

def target_table_names_from_headers(headers: Mapping[str, str]) -> dict[str, str]:
    """Resolve the six request-level target names from HTTP headers."""
    resolved = dict(TARGET_TABLE_DEFAULTS)
    for key, header in TARGET_TABLE_HEADERS.items():
        raw = headers.get(header)
        if raw is not None and str(raw).strip():
            resolved[key] = validate_table_name(str(raw))
    return validate_target_table_set(resolved)


def build_table_rewrites(db_type: str, pg_schema: str, names: Mapping[str, str]) -> tuple[tuple[str, str, str], ...]:
    """Return ``(schema, old_name, new_name)`` rewrites for SQLAlchemy statements."""
    final_schema = str(pg_schema or "prj_dbd") if str(db_type).upper() == "POSTGRES" else "dbo"
    staging_schema = "prj_stage" if str(db_type).upper() == "POSTGRES" else "stg"
    specs = (
        (staging_schema, TARGET_TABLE_DEFAULTS["stg_master"], names["stg_master"]),
        (staging_schema, TARGET_TABLE_DEFAULTS["stg_business"], names["stg_business"]),
        (staging_schema, TARGET_TABLE_DEFAULTS["stg_display"], names["stg_display"]),
        (final_schema, TARGET_TABLE_DEFAULTS["final_master"], names["final_master"]),
        (final_schema, TARGET_TABLE_DEFAULTS["final_business"], names["final_business"]),
        (final_schema, TARGET_TABLE_DEFAULTS["final_display"], names["final_display"]),
    )
    return tuple(item for item in specs if item[1] != item[2])


APPLICATION_MANAGED_TABLES = (
    RAW_ATTRIBUTE,
    PORTFOLIO_REFERENCE,
    AUDIT,
    STG_ATTRIBUTE_MASTER,
    STG_ATTRIBUTE_BUSINESS_RULES,
    STG_ATTRIBUTE_DISPLAY,
    ATTRIBUTE_MASTER,
    ATTRIBUTE_BUSINESS_RULES,
    ATTRIBUTE_DISPLAY,
)

S3_EXPORTS = (
    ("prj_attribute_master_new_test", ATTRIBUTE_MASTER),
    ("prj_attribute_business_rules_new_test", ATTRIBUTE_BUSINESS_RULES),
)

RAW_FIELDS = (
    "portfolio",
    "prj_id",
    "prj_attribute_name",
    "prj_physical_attribute_name",
    "section",
    "sub_section",
    "data_type",
    "calculated_or_reported",
    "calculation_logic",
    "segment",
    "report_type",
    "attribute_definition",
    "attribute_description",
    "display_order",
    "tech_logic",
    "display_name",
)

MASTER_FIELDS = (
    "prj_id",
    "prj_attribute_name",
    "prj_attribute_definition",
    "prj_physical_attribute_name",
    "where_in_financial_statement",
)

BUSINESS_RULE_FIELDS = (
    "scope_id",
    "prj_id",
    "port_ref_id",
    "source_abbr_name",
    "prompt_description",
    "examples_for_llm",
    "editable",
    "data_type",
    "attribute_type",
    "business_logic",
    "calculation_logic",
)

DISPLAY_FIELDS = (
    "display_id",
    "scope_id",
    "display_order",
    "prj_id",
    "display_name",
    "section",
    "subsection",
    "prj_attribute_definition",
    "prj_attribute_description",
    "segment",
    "report_type",
)
