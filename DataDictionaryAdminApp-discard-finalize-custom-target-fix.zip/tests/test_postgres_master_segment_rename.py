from pathlib import Path

from DataDictionaryAdminApp.core.database import _rewrite_postgres_master_segment_column


def test_postgres_column_rewrite_preserves_bind_parameter_name():
    sql = (
        'UPDATE prj_stage.prj_attribute_master_new_test '
        'SET where_in_financial_statement=%(where_in_financial_statement)s '
        'WHERE prj_stage.prj_attribute_master_new_test.where_in_financial_statement IS NOT NULL'
    )
    rewritten = _rewrite_postgres_master_segment_column(sql)
    assert 'SET segment=%(where_in_financial_statement)s' in rewritten
    assert '.segment IS NOT NULL' in rewritten
    assert '%(where_in_financial_statement)s' in rewritten


def test_postgres_fresh_install_and_validator_require_segment_not_legacy_name():
    root = Path('src/DataDictionaryAdminApp/sql/postgres')
    create_sql = (root / '001_create_tables.sql').read_text(encoding='utf-8').lower()
    validate_sql = (root / '002_validate_schema.sql').read_text(encoding='utf-8').lower()
    assert 'prj_physical_attribute_name varchar(500) not null unique, segment varchar(255)' in create_sql
    assert "('prj_stage','prj_attribute_master_new_test','segment')" in validate_sql
    assert "('prj_dbd','prj_attribute_master_new_test','segment')" in validate_sql


def test_postgres_009_is_idempotent_rename_migration():
    sql = Path('src/DataDictionaryAdminApp/sql/postgres/009_rename_master_where_to_segment.sql').read_text(encoding='utf-8').lower()
    assert 'rename column where_in_financial_statement to segment' in sql
    assert "array['prj_stage','prj_dbd']" in sql
    assert 'both %.%.where_in_financial_statement and %.%.segment exist' in sql


def test_sqlserver_master_contract_keeps_where_in_financial_statement():
    create_sql = Path('src/DataDictionaryAdminApp/sql/001_create_tables.sql').read_text(encoding='utf-8').lower()
    validate_sql = Path('src/DataDictionaryAdminApp/sql/002_validate_schema.sql').read_text(encoding='utf-8').lower()
    assert 'where_in_financial_statement' in create_sql
    assert 'where_in_financial_statement' in validate_sql


def test_shared_orm_round_trips_against_physical_segment_column():
    from sqlalchemy import create_engine, text
    from sqlalchemy.orm import Session
    from DataDictionaryAdminApp.model.entities import StagingAttributeMaster

    engine = create_engine('sqlite+pysqlite:///:memory:', future=True)
    pg_like_engine = engine.execution_options(postgres_master_segment_column=True)
    with pg_like_engine.begin() as connection:
        connection.exec_driver_sql("ATTACH DATABASE ':memory:' AS stg")
        connection.exec_driver_sql('''
            CREATE TABLE stg.prj_attribute_master_new_test (
                prj_id TEXT PRIMARY KEY,
                prj_attribute_name TEXT NOT NULL,
                prj_attribute_definition TEXT,
                prj_physical_attribute_name TEXT NOT NULL UNIQUE,
                segment TEXT NOT NULL,
                is_active BOOLEAN NOT NULL,
                created_at DATETIME,
                updated_at DATETIME,
                created_by TEXT,
                updated_by TEXT
            )
        ''')
    with Session(pg_like_engine) as session:
        row = StagingAttributeMaster(
            prj_id='PRJ1',
            prj_attribute_name='Revenue',
            prj_attribute_definition=None,
            prj_physical_attribute_name='revenue',
            where_in_financial_statement='Income Statement',
            is_active=True,
            created_by='tester',
            updated_by='tester',
        )
        session.add(row)
        session.commit()
        session.expire_all()
        loaded = session.get(StagingAttributeMaster, 'PRJ1')
        assert loaded is not None
        assert loaded.where_in_financial_statement == 'Income Statement'
        physical = session.execute(text('SELECT segment FROM stg.prj_attribute_master_new_test WHERE prj_id=\'PRJ1\'')).scalar_one()
        assert physical == 'Income Statement'
