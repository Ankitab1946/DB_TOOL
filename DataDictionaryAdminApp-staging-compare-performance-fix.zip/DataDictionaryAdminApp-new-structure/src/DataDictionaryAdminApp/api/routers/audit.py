from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from DataDictionaryAdminApp.api.schemas_api import AuditFilterRequest
from DataDictionaryAdminApp.core.database import get_db
from DataDictionaryAdminApp.repositories.data_dictionary_repository import DataDictionaryRepository

router = APIRouter(prefix="/audit", tags=["Audit"])

@router.post("/filter")
def filter_audit(payload: AuditFilterRequest, db: Session = Depends(get_db)):
    return DataDictionaryRepository(db).audit_rows(payload)

@router.get("")
def list_audit(db: Session = Depends(get_db)):
    return DataDictionaryRepository(db).audit_rows(AuditFilterRequest())
