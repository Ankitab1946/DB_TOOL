from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = (ROOT / "src/DataDictionaryAdminApp/repositories/data_dictionary_repository.py").read_text(encoding="utf-8")
UI = (ROOT / "src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")


def test_postgres_portfolio_reader_uses_physical_table_and_does_not_hide_reference_rows():
    block = REPO[REPO.index("    def list_portfolios"):REPO.index("    def portfolio_ref")]
    assert 'schema, table_name = "prj_dbd", "prj_portfolio_reference"' in block
    assert "autoload_with=bind" in block
    assert 'required = ("port_ref_id", "portfolio_name", "sector_name")' in block
    assert "Return the physical table rows regardless of legacy is_active values" in block
    assert 'stmt = select(*columns).order_by(table.c.portfolio_name, table.c.sector_name, table.c.port_ref_id)' in block
    assert 'stmt = stmt.where(or_(table.c.is_active.is_(None), table.c.is_active == true()))' not in block


def test_postgres_sources_use_exact_physical_table_and_required_columns():
    source_table = REPO[REPO.index("    def _source_table"):REPO.index("    def source_table_name")]
    source_list = REPO[REPO.index("    def list_sources"):REPO.index("    def source_code")]
    assert '("prj_data_sources",) if bind.dialect.name == "postgresql"' in source_table
    assert "Required PostgreSQL source table prj_dbd.prj_data_sources does not exist." in source_list
    assert '("source_code", "source_name")' in source_list


def test_ui_fetches_postgres_portfolios_and_sources_independently():
    assert ':reference-v2"' in UI
    assert 'direct_portfolios = api("GET", "/lookups/portfolios", quiet=False)' in UI
    assert 'direct_sources = api("GET", "/lookups/sources", quiet=False)' in UI
    assert 'combined["portfolios"] = direct_portfolios or []' in UI
    assert 'combined["sources"] = direct_sources or []' in UI
    assert 'No Source values returned from prj_dbd.prj_data_sources.' in UI


def test_calculation_attribute_details_do_not_use_overflow_prone_column_grids():
    start = UI.index('with st.expander("Calculation and Attribute Details", expanded=False):')
    end = UI.index("    if locked:", start)
    details_block = UI[start:end]
    assert "st.columns(" not in details_block
    assert 'overflow-x: hidden !important;' in UI
    assert '[data-testid="stDialog"] [data-testid="stExpander"]' in UI
