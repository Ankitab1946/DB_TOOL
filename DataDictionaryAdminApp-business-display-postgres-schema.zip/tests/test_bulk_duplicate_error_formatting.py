from pathlib import Path


def test_streamlit_formats_bulk_duplicate_details_readably():
    source = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
    assert "def format_api_error_detail" in source
    assert "duplicate across CFV IDs" in source
    assert "format_api_error_detail(detail)" in source
