from pathlib import Path

from sqlalchemy import Boolean, Column, MetaData, Table, select, true
from sqlalchemy.dialects import mssql, postgresql


def test_boolean_predicate_is_valid_for_sqlserver_and_postgres():
    table = Table("sample", MetaData(), Column("is_active", Boolean))
    statement = select(table).where(table.c.is_active == true())
    sqlserver_sql = str(statement.compile(dialect=mssql.dialect(), compile_kwargs={"literal_binds": True}))
    postgres_sql = str(statement.compile(dialect=postgresql.dialect(), compile_kwargs={"literal_binds": True}))
    assert "is_active = 1" in sqlserver_sql
    assert "is_active = true" in postgres_sql
    assert "IS 1" not in sqlserver_sql


def test_runtime_has_no_boolean_is_true_predicate():
    root = Path("src/DataDictionaryAdminApp")
    for path in root.rglob("*.py"):
        text = path.read_text(encoding="utf-8")
        assert ".is_(True)" not in text, f"SQL Server-unsafe boolean predicate in {path}"
