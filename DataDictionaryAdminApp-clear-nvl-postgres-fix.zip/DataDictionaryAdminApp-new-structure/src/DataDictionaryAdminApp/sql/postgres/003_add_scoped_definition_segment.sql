/* Existing PostgreSQL databases: add per-scope Attribute Definition and Segment. */
BEGIN;

ALTER TABLE stg.prj_attribute_business_rules_new_test
    ADD COLUMN IF NOT EXISTS prj_attribute_definition text;
ALTER TABLE stg.prj_attribute_business_rules_new_test
    ADD COLUMN IF NOT EXISTS segment varchar(255) NOT NULL DEFAULT 'NA';

ALTER TABLE dbo.prj_attribute_business_rules_new_test
    ADD COLUMN IF NOT EXISTS prj_attribute_definition text;
ALTER TABLE dbo.prj_attribute_business_rules_new_test
    ADD COLUMN IF NOT EXISTS segment varchar(255) NOT NULL DEFAULT 'NA';

UPDATE stg.prj_attribute_business_rules_new_test r
SET prj_attribute_definition = COALESCE(r.prj_attribute_definition, m.prj_attribute_definition),
    segment = CASE WHEN r.segment IS NULL OR btrim(r.segment) = '' OR r.segment = 'NA'
                   THEN COALESCE(m.where_in_financial_statement, 'NA') ELSE r.segment END
FROM stg.prj_attribute_master_new_test m
WHERE m.prj_id = r.prj_id;

UPDATE dbo.prj_attribute_business_rules_new_test r
SET prj_attribute_definition = COALESCE(r.prj_attribute_definition, m.prj_attribute_definition),
    segment = CASE WHEN r.segment IS NULL OR btrim(r.segment) = '' OR r.segment = 'NA'
                   THEN COALESCE(m.where_in_financial_statement, 'NA') ELSE r.segment END
FROM dbo.prj_attribute_master_new_test m
WHERE m.prj_id = r.prj_id;

COMMIT;
