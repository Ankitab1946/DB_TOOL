from DataDictionaryAdminAppAPI.model.entities import Datasource, Datasources, DataSource, DataSources, AuditLog, AuditLogs, AuditTable

def test_legacy_entity_imports():
    assert Datasources is Datasource
    assert DataSource is Datasource
    assert DataSources is Datasource
    assert AuditLog is AuditTable
    assert AuditLogs is AuditTable
