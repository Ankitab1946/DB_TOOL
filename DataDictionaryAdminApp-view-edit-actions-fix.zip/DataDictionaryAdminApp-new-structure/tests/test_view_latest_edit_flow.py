from pathlib import Path


def test_view_latest_uses_row_selection_actions_without_separate_edit_latest_section():
    source = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
    assert 'selection_mode="single-row"' in source
    assert 'on_select="rerun"' in source
    assert 'action1.button("Edit"' in source
    assert 'action2.button("Soft Delete"' in source
    assert 'st.subheader("Edit Latest")' not in source
    assert '"Save Changes"' in source


def test_create_and_edit_forms_include_extended_fields_and_large_modals():
    source = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
    assert 'max_width=1450' in source
    assert '"Calculation Logic"' in source
    assert '"Attribute Definition"' in source
    assert '"Attribute Description / Proposed Prompt"' in source
    assert '"Tech Logic"' in source
    assert '"tech_logic": tech_logic or None' in source
    assert 'CFV ID generated:' in source
