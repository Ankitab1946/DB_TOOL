from DataDictionaryAdminApp.api.swagger_app import app


def test_required_routes_exist():
    paths = {route.path for route in app.routes}
    required = {
        "/api/v1/data-dictionary/filter-page",
        "/api/v1/data-dictionary/edit-latest",
        "/api/v1/data-dictionary/delta",
        "/api/v1/data-dictionary/finalize",
        "/api/v1/data-dictionary/download-latest",
        "/api/v1/master-upload/preview-sheet",
        "/api/v1/master-upload/finalize",
        "/api/v1/audit/filter",
        "/api/v1/prompts",
        "/api/v1/s3/export-final",
    }
    assert required <= paths
