from sqlalchemy import select
from sqlalchemy.dialects import mssql, postgresql

from DataDictionaryAdminApp.api.routers.system import health
from DataDictionaryAdminApp.model.entities import PortfolioReference
from sqlalchemy import false, true


def test_sqlserver_and_postgres_boolean_rendering():
    stmt = select(PortfolioReference).where(PortfolioReference.is_active == true())
    sqlserver = str(stmt.compile(dialect=mssql.dialect(), compile_kwargs={"literal_binds": True}))
    postgres = str(stmt.compile(dialect=postgresql.dialect(), compile_kwargs={"literal_binds": True}))
    assert "is_active = 1" in sqlserver
    assert "IS 1" not in sqlserver
    assert "is_active = true" in postgres


def test_health_advertises_current_bulk_modes_and_db_status_capability():
    payload = health()
    assert payload["version"] == "2.1.0"
    assert payload["upload_modes"] == ["MERGE", "INSERT_ONLY", "REPLACE"]
    assert payload["database_status_endpoint"] is True


def test_database_status_typo_alias_is_registered():
    from DataDictionaryAdminApp.api.swagger_app import app

    paths = {route.path for route in app.routes}
    assert "/api/v1/system/database-status" in paths
    assert "/api/v1/system/database-sttaus" in paths
