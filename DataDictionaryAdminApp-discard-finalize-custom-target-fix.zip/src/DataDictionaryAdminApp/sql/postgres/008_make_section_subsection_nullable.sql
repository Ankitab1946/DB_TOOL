/*
008_make_section_subsection_nullable.sql
PostgreSQL migration: allow blank Excel Section/Sub-Section values to persist as NULL.
Idempotent. Does not delete/recreate data.

The raw table is fixed. Display tables may use either the historical _test name or
common UI-renamed prj_attribute_display name. If you configured a different custom
Display table basename, run DROP NOT NULL for section/subsection on that table too.
*/
BEGIN;

ALTER TABLE IF EXISTS prj_dbd.raw_prj_attribute_new_test
    ALTER COLUMN section DROP NOT NULL,
    ALTER COLUMN sub_section DROP NOT NULL;

DO $$
DECLARE
    rec record;
BEGIN
    FOR rec IN
        SELECT table_schema, table_name
        FROM information_schema.tables
        WHERE table_schema IN ('prj_stage', 'prj_dbd')
          AND table_name IN ('prj_attribute_display_test', 'prj_attribute_display')
          AND table_type = 'BASE TABLE'
    LOOP
        EXECUTE format(
            'ALTER TABLE %I.%I ALTER COLUMN section DROP NOT NULL, ALTER COLUMN subsection DROP NOT NULL',
            rec.table_schema, rec.table_name
        );
    END LOOP;
END $$;

COMMIT;
SELECT 'Migration completed successfully' AS migration_result;
