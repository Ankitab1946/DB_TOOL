from __future__ import annotations

import io
from pathlib import Path

from openpyxl import Workbook
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

import DataDictionaryAdminApp.core.database  # registers table rewrite listener
from DataDictionaryAdminApp.api.schemas_api import AttributeUpsert
from DataDictionaryAdminApp.core.target_tables import TARGET_TABLE_DEFAULTS, build_table_rewrites
from DataDictionaryAdminApp.model.entities import AttributeDisplay, RawAttribute, StagingAttributeDisplay
from DataDictionaryAdminApp.service.data_dictionary_service import DataDictionaryService
from DataDictionaryAdminApp.service.excel_service import ExcelService

ROOT = Path(__file__).resolve().parents[1]
UI = (ROOT / "src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
SQLSERVER_010 = (ROOT / "src/DataDictionaryAdminApp/sql/010_default_section_subsection_na.sql").read_text(encoding="utf-8")
POSTGRES_010 = (ROOT / "src/DataDictionaryAdminApp/sql/postgres/010_default_section_subsection_na.sql").read_text(encoding="utf-8")


def _blank_section_workbook() -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = "Corporate"
    ws.append([
        "PRJID", "Attribute Name", "Section", "Sub-Section",
        "Calculated or Reported", "Display Order", "Portfolio",
    ])
    ws.append(["PRJ100", "Revenue", None, None, "Reported", 1, "Corporate Corporate"])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def test_blank_excel_section_and_subsection_default_to_na():
    result = ExcelService().parse_workbook(
        _blank_section_workbook(),
        [{"sheet_name": "Corporate", "header_row": 1, "data_start_row": 2}],
    )
    assert result["rejected"] == []
    assert len(result["rows"]) == 1
    row = result["rows"][0]
    assert row.section == "N/A"
    assert row.sub_section == "N/A"


def test_api_model_defaults_blank_section_and_subsection_to_na():
    row = AttributeUpsert(
        prj_id="PRJ1",
        portfolio="Corporate Corporate",
        prj_attribute_name="Revenue",
        section=None,
        sub_section=None,
        calculated_or_reported="Reported",
        display_order=1,
    )
    assert row.section == "N/A"
    assert row.sub_section == "N/A"


def test_orm_columns_are_not_nullable_for_raw_staging_and_final_display():
    assert RawAttribute.__table__.c.section.nullable is False
    assert RawAttribute.__table__.c.sub_section.nullable is False
    assert StagingAttributeDisplay.__table__.c.section.nullable is False
    assert StagingAttributeDisplay.__table__.c.subsection.nullable is False
    assert AttributeDisplay.__table__.c.section.nullable is False
    assert AttributeDisplay.__table__.c.subsection.nullable is False


def test_na_default_migrations_exist_for_both_engines():
    assert "SET section = N'N/A'" in SQLSERVER_010
    assert "ALTER COLUMN section nvarchar(255) NOT NULL" in SQLSERVER_010
    assert "DEFAULT(N'N/A')" in SQLSERVER_010
    assert "SET section = 'N/A'" in POSTGRES_010
    assert "ALTER COLUMN section SET DEFAULT 'N/A'" in POSTGRES_010
    assert "ALTER COLUMN section SET NOT NULL" in POSTGRES_010


def test_finalize_ui_is_single_submit_with_progress_and_loaded_prj_count():
    assert '"finalize_in_progress": False' in UI
    assert 'Finalize and Upload is in progress' in UI
    assert 'disabled=finalize_in_progress' in UI
    assert 'loaded_count = int(result.get("updated", 0) or 0)' in UI
    assert 'PRJ ID(s) were loaded into the selected Actual / Final tables' in UI
    assert 'finalize_modal.close()' in UI


def test_delta_uses_custom_final_names_when_staging_names_remain_default():
    engine = create_engine("sqlite+pysqlite:///:memory:", future=True)
    with engine.begin() as c:
        c.exec_driver_sql("ATTACH DATABASE ':memory:' AS stg")
        c.exec_driver_sql("ATTACH DATABASE ':memory:' AS dbo")
        c.exec_driver_sql("""
            CREATE TABLE stg.prj_attribute_master_new_test (
                prj_id TEXT PRIMARY KEY, prj_attribute_name TEXT NOT NULL,
                prj_attribute_definition TEXT, prj_physical_attribute_name TEXT NOT NULL UNIQUE,
                where_in_financial_statement TEXT NOT NULL, is_active BOOLEAN NOT NULL,
                created_at DATETIME, updated_at DATETIME, created_by TEXT, updated_by TEXT)
        """)
        c.exec_driver_sql("""
            CREATE TABLE stg.prj_attribute_business_rules_new_test (
                scope_id INTEGER PRIMARY KEY AUTOINCREMENT, prj_id TEXT NOT NULL,
                port_ref_id INTEGER NOT NULL, source_abbr_name TEXT NOT NULL,
                prompt_description TEXT, examples_for_llm TEXT, editable TEXT NOT NULL,
                data_type TEXT, attribute_type TEXT NOT NULL, business_logic TEXT,
                calculation_logic TEXT NOT NULL, created_at DATETIME, updated_at DATETIME,
                created_by TEXT, updated_by TEXT)
        """)
        c.exec_driver_sql("""
            CREATE TABLE stg.prj_attribute_display_test (
                display_id INTEGER PRIMARY KEY AUTOINCREMENT, scope_id INTEGER NOT NULL UNIQUE,
                display_order INTEGER NOT NULL, prj_id TEXT NOT NULL, display_name TEXT,
                section TEXT, subsection TEXT, prj_attribute_definition TEXT,
                prj_attribute_description TEXT, segment TEXT NOT NULL, report_type TEXT NOT NULL,
                created_at DATETIME, updated_at DATETIME, created_by TEXT, updated_by TEXT)
        """)
        for table in ("prj_attribute_master",):
            c.exec_driver_sql(f"""
                CREATE TABLE dbo.{table} (
                    prj_id TEXT PRIMARY KEY, prj_attribute_name TEXT NOT NULL,
                    prj_attribute_definition TEXT, prj_physical_attribute_name TEXT NOT NULL UNIQUE,
                    where_in_financial_statement TEXT NOT NULL, is_active BOOLEAN NOT NULL,
                    created_at DATETIME, updated_at DATETIME, created_by TEXT, updated_by TEXT)
            """)
        c.exec_driver_sql("""
            CREATE TABLE dbo.prj_attribute_business_rules (
                scope_id INTEGER PRIMARY KEY AUTOINCREMENT, prj_id TEXT NOT NULL,
                port_ref_id INTEGER NOT NULL, source_abbr_name TEXT NOT NULL,
                prompt_description TEXT, examples_for_llm TEXT, editable TEXT NOT NULL,
                data_type TEXT, attribute_type TEXT NOT NULL, business_logic TEXT,
                calculation_logic TEXT NOT NULL, created_at DATETIME, updated_at DATETIME,
                created_by TEXT, updated_by TEXT)
        """)
        c.exec_driver_sql("""
            CREATE TABLE dbo.prj_attribute_display (
                display_id INTEGER PRIMARY KEY AUTOINCREMENT, scope_id INTEGER NOT NULL UNIQUE,
                display_order INTEGER NOT NULL, prj_id TEXT NOT NULL, display_name TEXT,
                section TEXT, subsection TEXT, prj_attribute_definition TEXT,
                prj_attribute_description TEXT, segment TEXT NOT NULL, report_type TEXT NOT NULL,
                created_at DATETIME, updated_at DATETIME, created_by TEXT, updated_by TEXT)
        """)
        c.exec_driver_sql("""
            INSERT INTO stg.prj_attribute_master_new_test
            (prj_id,prj_attribute_name,prj_physical_attribute_name,where_in_financial_statement,is_active)
            VALUES ('PRJ77','Revenue','revenue','Income',1)
        """)
        c.exec_driver_sql("""
            INSERT INTO stg.prj_attribute_business_rules_new_test
            (prj_id,port_ref_id,source_abbr_name,editable,attribute_type,calculation_logic)
            VALUES ('PRJ77',10,'SRC','Y','Reported','NA')
        """)
        scope_id = c.exec_driver_sql(
            "SELECT scope_id FROM stg.prj_attribute_business_rules_new_test"
        ).scalar_one()
        c.exec_driver_sql(
            """
            INSERT INTO stg.prj_attribute_display_test
            (scope_id,display_order,prj_id,section,subsection,segment,report_type)
            VALUES (?,1,'PRJ77',NULL,NULL,'NA','Annual')
            """,
            (scope_id,),
        )

    names = dict(TARGET_TABLE_DEFAULTS)
    names.update({
        "final_master": "prj_attribute_master",
        "final_business": "prj_attribute_business_rules",
        "final_display": "prj_attribute_display",
    })
    routed = engine.execution_options(
        target_table_rewrites=build_table_rewrites("SQLSERVER", "prj_dbd", names)
    )
    with Session(routed) as session:
        session.info["target_table_names"] = names
        result = DataDictionaryService(session).delta()
        assert result["has_changes"] is True
        assert result["count"] == 1
        assert result["rows"][0]["prj_id"] == "PRJ77"
        assert result["rows"][0]["delta_type"] == "NEW"
