from pathlib import Path

from DataDictionaryAdminApp.api.schemas_api import AttributeUpsert
from DataDictionaryAdminApp.service.data_dictionary_service import DataDictionaryService
from DataDictionaryAdminApp.utils.normalizers import pair_pipe_values


def test_pipe_sections_and_subsections_are_positionally_paired():
    assert pair_pipe_values("Total|liabilities", "current|current2") == [
        ("Total", "current"),
        ("liabilities", "current2"),
    ]


def test_single_value_is_broadcast_across_multiple_values():
    assert pair_pipe_values("Total", "current|current2") == [
        ("Total", "current"),
        ("Total", "current2"),
    ]


def test_incompatible_multi_value_counts_are_rejected():
    try:
        pair_pipe_values("A|B", "X|Y|Z")
    except ValueError as exc:
        assert "matching counts" in str(exc)
    else:
        raise AssertionError("Expected mismatched pipe counts to be rejected")


def test_ui_create_stages_two_business_rule_rows_for_two_pairs():
    class FakeRepo:
        def __init__(self):
            self.rules = []

        def portfolio_ref(self, value):
            return {"label": "FI Banks", "port_ref_id": 1, "portfolio_name": "FI", "sector_name": "Banks"}

        def physical_name_for_prj(self, prj_id):
            return None

        def physical_name_exists(self, name, exclude_prj_id=None):
            return False

        def available_physical_name(self, base_name, exclude_prj_id=None):
            return base_name

        def original_mapping_type(self, prj_id):
            return None

        def source_code(self, source_name, source_abbr_name=None):
            return source_abbr_name or "SNPAR"

        def upsert_raw(self, row, user, source_operation, defer_insert_audit=False):
            return None

        def upsert_staging_master(self, row, user, source_operation):
            return None

        def upsert_staging_rule(self, row, user, source_operation, defer_insert_audit=False, strict_key=False):
            self.rules.append(dict(row))
            return None

        def emit_deferred_insert_audits(self, items):
            return None

    service = DataDictionaryService(db=None)
    repo = FakeRepo()
    service.repo = repo
    payload = AttributeUpsert(
        prj_id="CFV100",
        portfolio="FI Banks",
        source_abbr_name="SNPAR",
        prj_attribute_name="Test Attribute",
        section="Total|liabilities",
        sub_section="current|current2",
        data_type="Amount",
        calculated_or_reported="Reported",
        display_order=1,
    )

    result = service.stage_attribute_pending(payload, "tester", "UI_CREATE")

    assert result["business_rule_rows_staged"] == 2
    assert [(row["section"], row["subsection"]) for row in repo.rules] == [
        ("Total", "current"),
        ("liabilities", "current2"),
    ]


def test_streamlit_deprecated_container_width_is_removed_and_pair_help_present():
    source = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
    assert "use_container_width" not in source
    assert 'width="stretch"' in source
    assert "paired positionally" in source


def test_finalize_handles_multiple_rules_for_same_port_without_overwriting_second_pair():
    source = Path("src/DataDictionaryAdminApp/service/data_dictionary_service.py").read_text(encoding="utf-8")
    assert "strict_key=occurrence > 0" in source
    assert "seen_ports" in source
