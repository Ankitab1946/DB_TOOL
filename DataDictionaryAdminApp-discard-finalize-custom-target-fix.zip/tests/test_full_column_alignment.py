from DataDictionaryAdminApp.model.entities import (
    AttributeBusinessRule,
    AttributeMaster,
    AuditTable,
    PortfolioReference,
    RawAttribute,
    StagingAttributeMaster,
    StagingBusinessRule,
)

AUDIT_COLUMNS = {"is_active", "created_at", "updated_at", "created_by", "updated_by"}


def columns(model):
    return set(model.__table__.columns.keys())


def test_raw_columns_exact():
    assert columns(RawAttribute) == {
        "raw_row_id", "portfolio", "prj_id", "prj_attribute_name", "prj_physical_attribute_name",
        "section", "sub_section", "data_type", "calculated_or_reported", "calculation_logic", "segment", "report_type",
        "attribute_definition", "attribute_description", "display_order", "tech_logic", "display_name",
    } | AUDIT_COLUMNS


def test_portfolio_and_audit_columns_exact():
    assert columns(PortfolioReference) == {
        "port_ref_id", "portfolio_name", "sector_name", "sub_sector", "remarks",
    } | AUDIT_COLUMNS
    assert columns(AuditTable) == {
        "audit_id", "schema_name", "table_name", "record_key", "action", "before_value", "after_value",
        "source_operation", "performed_by", "performed_at",
    }


def test_staging_and_final_master_columns_match():
    expected = {
        "prj_id", "prj_attribute_name", "prj_attribute_definition", "prj_physical_attribute_name",
        "where_in_financial_statement",
    } | AUDIT_COLUMNS
    assert columns(StagingAttributeMaster) == expected
    assert columns(AttributeMaster) == expected


def test_staging_and_final_rule_columns_match_exactly():
    assert columns(StagingBusinessRule) == columns(AttributeBusinessRule)
