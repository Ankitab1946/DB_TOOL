# Split deployment and SCD2

## Deployment boundary
- `DataDictionaryAdminApp`: Streamlit UI only, port 8501. It calls `API_BASE_URL`; it has no DB/ORM/repository code.
- `DataDictionaryAdminAppAPI`: FastAPI/API and all database/business services, port 8503.

## SCD2 strategy
To preserve existing PK/FK relationships and API payloads, operational tables remain current-state tables. A centralized companion table `scd2_row_history` stores every effective-dated version produced by application mutations.

Columns: `source_schema`, `source_table`, `record_key`, `version_number`, `effective_from`, `effective_to`, `is_current`, `operation`, `row_data`, `source_operation`, `changed_by`, `changed_at`.

Existing audit APIs are unchanged. Additive endpoint: `GET /api/v1/audit/scd2-history`.

Run migration `011_add_scd2_history.sql` for the selected DB before deploying API v3. The migration baselines existing rows for raw, staging, final, portfolio, data-source and audit tables. Read-only data-source history is seeded; subsequent application-managed writes are versioned through the repository audit path.

## Coverage
The migration seeds and the API mutation path cover:
- raw attributes
- staging master/business/display
- final master/business/display
- portfolio reference
- data sources (read-only in this application; baseline seeded)
- audit log (append-only rows are also represented in SCD2)

Staging rows closed by Finalize/Discard and raw rows removed by Discard are explicitly ended in SCD2. Bulk replace/cleanup closes current SCD2 versions before physical deletion. Custom staging/final table names are recorded using the request-selected physical table name.
