/* SQL Server schema validator for business/display split. Read-only. */
SET NOCOUNT ON;
DECLARE @missing TABLE(object_type varchar(20),schema_name varchar(128),table_name varchar(255),column_name varchar(255),status varchar(20),fix_hint nvarchar(1000));

DECLARE @required TABLE(schema_name sysname,table_name sysname,column_name sysname);
INSERT @required VALUES
('dbo','raw_prj_attribute_new_test','raw_row_id'),('dbo','raw_prj_attribute_new_test','prj_id'),('dbo','raw_prj_attribute_new_test','report_type'),
('dbo','prj_portfolio_reference_new_test','port_ref_id'),('dbo','prj_portfolio_reference_new_test','remarks'),('dbo','audit_table_new_test','audit_id'),
('stg','prj_attribute_master_new_test','prj_id'),('stg','prj_attribute_master_new_test','prj_attribute_definition'),('stg','prj_attribute_master_new_test','where_in_financial_statement'),
('dbo','prj_attribute_master_new_test','prj_id'),('dbo','prj_attribute_master_new_test','prj_attribute_definition'),('dbo','prj_attribute_master_new_test','where_in_financial_statement'),
('stg','prj_attribute_business_rules_new_test','scope_id'),('stg','prj_attribute_business_rules_new_test','prj_id'),
('stg','prj_attribute_business_rules_new_test','port_ref_id'),('stg','prj_attribute_business_rules_new_test','source_abbr_name'),
('stg','prj_attribute_business_rules_new_test','prompt_description'),('stg','prj_attribute_business_rules_new_test','examples_for_llm'),
('stg','prj_attribute_business_rules_new_test','editable'),('stg','prj_attribute_business_rules_new_test','data_type'),
('stg','prj_attribute_business_rules_new_test','attribute_type'),('stg','prj_attribute_business_rules_new_test','business_logic'),
('stg','prj_attribute_business_rules_new_test','calculation_logic'),
('dbo','prj_attribute_business_rules_new_test','scope_id'),('dbo','prj_attribute_business_rules_new_test','prj_id'),
('dbo','prj_attribute_business_rules_new_test','port_ref_id'),('dbo','prj_attribute_business_rules_new_test','source_abbr_name'),
('dbo','prj_attribute_business_rules_new_test','prompt_description'),('dbo','prj_attribute_business_rules_new_test','examples_for_llm'),
('dbo','prj_attribute_business_rules_new_test','editable'),('dbo','prj_attribute_business_rules_new_test','data_type'),
('dbo','prj_attribute_business_rules_new_test','attribute_type'),('dbo','prj_attribute_business_rules_new_test','business_logic'),
('dbo','prj_attribute_business_rules_new_test','calculation_logic'),
('stg','prj_attribute_display_test','display_id'),('stg','prj_attribute_display_test','scope_id'),('stg','prj_attribute_display_test','display_order'),
('stg','prj_attribute_display_test','prj_id'),('stg','prj_attribute_display_test','display_name'),('stg','prj_attribute_display_test','section'),
('stg','prj_attribute_display_test','subsection'),('stg','prj_attribute_display_test','prj_attribute_definition'),
('stg','prj_attribute_display_test','prj_attribute_description'),('stg','prj_attribute_display_test','segment'),('stg','prj_attribute_display_test','report_type'),
('dbo','prj_attribute_display_test','display_id'),('dbo','prj_attribute_display_test','scope_id'),('dbo','prj_attribute_display_test','display_order'),
('dbo','prj_attribute_display_test','prj_id'),('dbo','prj_attribute_display_test','display_name'),('dbo','prj_attribute_display_test','section'),
('dbo','prj_attribute_display_test','subsection'),('dbo','prj_attribute_display_test','prj_attribute_definition'),
('dbo','prj_attribute_display_test','prj_attribute_description'),('dbo','prj_attribute_display_test','segment'),('dbo','prj_attribute_display_test','report_type');

INSERT @missing
SELECT 'COLUMN',r.schema_name,r.table_name,r.column_name,'MISSING',N'Run 003_add_scoped_definition_segment.sql. Then run 005_split_business_display.sql for the split; use 001_create_tables.sql only for a fresh database.'
FROM @required r
WHERE OBJECT_ID(QUOTENAME(r.schema_name)+'.'+QUOTENAME(r.table_name),'U') IS NULL
   OR COL_LENGTH(r.schema_name+'.'+r.table_name,r.column_name) IS NULL;

IF OBJECT_ID(N'dbo.prj_data_sources',N'U') IS NULL AND OBJECT_ID(N'dbo.prj_data_source',N'U') IS NULL
 INSERT @missing VALUES('TABLE','dbo','prj_data_sources',NULL,'MISSING',N'Read-only source reference table is required (plural or singular name supported).');

IF EXISTS(SELECT 1 FROM @missing)
BEGIN
 SELECT * FROM @missing ORDER BY schema_name,table_name,column_name;
 THROW 51090,'Schema validation failed. Review the detailed missing rows returned above.',1;
END;
SELECT 'Schema validation passed' AS validation_status,0 AS missing_count;
