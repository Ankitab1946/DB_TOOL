from DataDictionaryAdminApp.config import Settings


def test_sqlserver_url_and_environment_resolution():
    settings = Settings(
        _env_file=None,
        app_environments="LOCAL,DEV",
        selected_environment="DEV",
        selected_db_type="SQLSERVER",
        sqlserver_server="sql-host",
        sqlserver_database="PRJ_DB",
        enable_sqlserver=True,
    )
    cfg = settings.database_config("DEV", "SQLSERVER")
    assert cfg["db_type"] == "SQLSERVER"
    assert cfg["database"] == "PRJ_DB"
    assert settings.sqlalchemy_url("DEV", "SQLSERVER").drivername == "mssql+pyodbc"


def test_postgres_url_and_environment_resolution():
    settings = Settings(
        _env_file=None,
        app_environments="LOCAL,DEV",
        selected_environment="DEV",
        selected_db_type="POSTGRES",
        postgres_host="pg-host",
        postgres_port=5432,
        postgres_database="PRJ_DB",
        postgres_user="app",
        postgres_password="secret",
        enable_postgres=True,
    )
    cfg = settings.database_config("DEV", "POSTGRES")
    url = settings.sqlalchemy_url("DEV", "POSTGRES")
    assert cfg["db_type"] == "POSTGRES"
    assert cfg["host"] == "pg-host"
    assert url.drivername == "postgresql+psycopg"
    assert url.database == "PRJ_DB"
