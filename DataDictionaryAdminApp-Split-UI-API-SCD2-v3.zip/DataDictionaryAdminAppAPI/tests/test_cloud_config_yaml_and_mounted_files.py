from __future__ import annotations

import os
from pathlib import Path

import pytest

from DataDictionaryAdminAppAPI.config import Settings, bootstrap_runtime_config, runtime_config_values


DB_KEYS = [
    "SELECTED_ENVIRONMENT",
    "SELECTED_DB_TYPE",
    "ENABLE_POSTGRES",
    "PG_HOST",
    "PG_PORT",
    "PG_DATABASE",
    "PG_SCHEMA",
    "POSTGRES_USER",
    "POSTGRES_PASSWORD",
    "POSTGRES_SSLMODE",
    "ENV_DEV_PG_HOST",
    "ENV_DEV_PG_PORT",
    "ENV_DEV_PG_DATABASE",
    "ENV_DEV_PG_SCHEMA",
    "ENV_DEV_POSTGRES_USER",
    "ENV_DEV_POSTGRES_PASSWORD",
    "ENV_DEV_POSTGRES_SSLMODE",
    "ENV_DEV_ENABLE_POSTGRES",
    "APP_CONFIG_FILE",
    "APP_CONFIG_DIR",
]


@pytest.fixture(autouse=True)
def _restore_runtime_env():
    keys = set(DB_KEYS)
    original = {key: os.environ.get(key) for key in keys}
    for key in keys:
        os.environ.pop(key, None)
    yield
    for key in keys:
        os.environ.pop(key, None)
    for key, value in original.items():
        if value is not None:
            os.environ[key] = value


def _clear(monkeypatch):
    for key in DB_KEYS:
        monkeypatch.delenv(key, raising=False)


def test_dev_values_yaml_works_without_dotenv(tmp_path: Path, monkeypatch):
    _clear(monkeypatch)
    values_file = tmp_path / "dev-values.yaml"
    values_file.write_text(
        """
env:
  SELECTED_ENVIRONMENT: DEV
  SELECTED_DB_TYPE: POSTGRES
  ENABLE_POSTGRES: 'true'
  PG_HOST: pg-from-values
  PG_PORT: '5544'
  PG_DATABASE: DEV_DB
  PG_SCHEMA: prj_dbd
  POSTGRES_USER: dev_user
  POSTGRES_PASSWORD: dev_secret
  POSTGRES_SSLMODE: require
""".strip(),
        encoding="utf-8",
    )
    monkeypatch.setenv("APP_CONFIG_FILE", str(values_file))

    sources = bootstrap_runtime_config("DEV")
    settings = Settings(_env_file=None)
    cfg = settings.database_config("DEV", "POSTGRES")

    assert str(values_file) in sources
    assert cfg["host"] == "pg-from-values"
    assert cfg["port"] == 5544
    assert cfg["database"] == "DEV_DB"
    assert cfg["schema"] == "prj_dbd"
    assert cfg["user"] == "dev_user"
    assert cfg["password"] == "dev_secret"
    assert cfg["sslmode"] == "require"
    assert cfg["enabled"] is True


def test_nested_postgres_yaml_is_supported(tmp_path: Path, monkeypatch):
    _clear(monkeypatch)
    values_file = tmp_path / "dev-values.yaml"
    values_file.write_text(
        """
application:
  environment: DEV
  dbType: POSTGRES
database:
  postgres:
    host: nested-pg
    port: 6432
    database: NESTED_DB
    schema: prj_dbd
    user: nested_user
    password: nested_secret
    sslmode: require
    enabled: true
""".strip(),
        encoding="utf-8",
    )
    monkeypatch.setenv("APP_CONFIG_FILE", str(values_file))
    bootstrap_runtime_config("DEV")
    cfg = Settings(_env_file=None).database_config("DEV", "POSTGRES")
    assert cfg["host"] == "nested-pg"
    assert cfg["port"] == 6432
    assert cfg["database"] == "NESTED_DB"
    assert cfg["user"] == "nested_user"
    assert cfg["enabled"] is True


def test_mounted_config_files_override_yaml(tmp_path: Path, monkeypatch):
    _clear(monkeypatch)
    values_file = tmp_path / "dev-values.yaml"
    values_file.write_text("env:\n  PG_HOST: yaml-host\n  ENABLE_POSTGRES: 'true'\n", encoding="utf-8")
    config_dir = tmp_path / "mounted"
    config_dir.mkdir()
    (config_dir / "PG_HOST").write_text("mounted-host\n", encoding="utf-8")
    (config_dir / "PG_PORT").write_text("7444\n", encoding="utf-8")
    monkeypatch.setenv("APP_CONFIG_FILE", str(values_file))
    monkeypatch.setenv("APP_CONFIG_DIR", str(config_dir))

    bootstrap_runtime_config("DEV")
    cfg = Settings(_env_file=None, selected_environment="DEV", enable_postgres=True).database_config("DEV", "POSTGRES")
    assert cfg["host"] == "mounted-host"
    assert cfg["port"] == 7444


def test_process_environment_has_highest_priority(tmp_path: Path, monkeypatch):
    _clear(monkeypatch)
    values_file = tmp_path / "dev-values.yaml"
    values_file.write_text("env:\n  PG_HOST: yaml-host\n", encoding="utf-8")
    monkeypatch.setenv("APP_CONFIG_FILE", str(values_file))
    monkeypatch.setenv("PG_HOST", "injected-host")

    bootstrap_runtime_config("DEV")
    cfg = Settings(_env_file=None, selected_environment="DEV", enable_postgres=True).database_config("DEV", "POSTGRES")
    assert cfg["host"] == "injected-host"


def test_environment_specific_yaml_key_wins_over_generic(tmp_path: Path, monkeypatch):
    _clear(monkeypatch)
    values_file = tmp_path / "dev-values.yaml"
    values_file.write_text(
        """
env:
  PG_HOST: generic-host
  ENV_DEV_PG_HOST: dev-specific-host
  ENABLE_POSTGRES: 'true'
""".strip(),
        encoding="utf-8",
    )
    monkeypatch.setenv("APP_CONFIG_FILE", str(values_file))
    bootstrap_runtime_config("DEV")
    cfg = Settings(_env_file=None, selected_environment="DEV").database_config("DEV", "POSTGRES")
    assert cfg["host"] == "dev-specific-host"


def test_missing_dotenv_is_not_required(monkeypatch, tmp_path: Path):
    _clear(monkeypatch)
    monkeypatch.chdir(tmp_path)
    values, _sources = runtime_config_values("DEV")
    assert isinstance(values, dict)


def test_dev_values_yaml_is_auto_detected_from_working_directory(tmp_path: Path, monkeypatch):
    _clear(monkeypatch)
    monkeypatch.chdir(tmp_path)
    (tmp_path / "dev-values.yaml").write_text(
        "env:\n  SELECTED_ENVIRONMENT: DEV\n  ENABLE_POSTGRES: 'true'\n  PG_HOST: auto-dev-host\n",
        encoding="utf-8",
    )
    bootstrap_runtime_config()
    cfg = Settings(_env_file=None).database_config("DEV", "POSTGRES")
    assert cfg["host"] == "auto-dev-host"
    assert cfg["enabled"] is True
