# Validation Results

Validation for the business/display split and PostgreSQL physical-schema update:

- 106 automated tests passed.
- Python `compileall` passed for application source and tests.
- FastAPI/OpenAPI generation passed with 29 API paths.
- Staging/final `prj_attribute_business_rules_new_test` ORM tables contain only the requested business/LLM columns.
- New staging/final `prj_attribute_display_test` tables are one-to-one with business scopes through `scope_id`.
- Existing scope-specific Attribute Definition, Attribute Description, Segment and Report Type are retained on display rows so prior functionality is not lost.
- Repository/service logic rejoins business + display for View Latest, Edit Attribute, prompts, Delta, Finalize and S3 export.
- SQL Server remains on physical `dbo` / `stg` schemas.
- PostgreSQL runtime uses SQLAlchemy schema translation `dbo -> prj_dbd` and `stg -> prj_stage`.
- PostgreSQL fresh-install DDL creates `prj_dbd` and `prj_stage`; existing-database migration 005 moves prior physical tables and splits business/display data while preserving `scope_id`.
- SQL Server migration 005 preserves existing `scope_id` values with `IDENTITY_INSERT`, creates display rows, and replaces the old combined business-rule table transactionally.
- ORM foreign keys mirror the relational contract for master, portfolio, scope and display references.
- PostgreSQL audit history records physical schema names (`prj_dbd` / `prj_stage`); SQL Server audit history retains `dbo` / `stg`.
- Existing Create/Edit, bulk upload modes, physical-name validation, filters, soft delete/reactivate, Cleanup, Prompt Management, Finalize and role controls remain covered by the regression suite.

No live SQL Server or PostgreSQL server is available in this build environment, so the DDL migration itself must still be executed and followed by the supplied `002_validate_schema.sql` in the target DEV environment before enabling writes.
