# Validation Results — Staging Workflow, Compare Detail and UI Performance

## Implemented changes

- Create/Edit explicitly exposes and persists Calculation Logic, Attribute Definition, Attribute Description and Tech Logic.
- Edit detail now prefers staged data when a pending staged version exists, so saved edits are visible before Finalize without publishing them to the final tables.
- Create New Attribute pre-generates the CFV/PRJ ID before the modal opens, displays it read-only, and persists the exact displayed ID.
- Create/Edit modal width increased to 1650 px (large but still below a typical full-HD viewport width).
- Validate & Compare now returns record-level Insert/Update/Delete/Unchanged counts plus a readable field-level Before/After change list by PRJ ID and scope.
- Stage Uploaded Data uses a bulk cached staging path: raw/staging ORM objects are preloaded once, row-level SQL savepoints are removed, generated identities are flushed once, and the endpoint no longer recalculates the full Delta after commit.
- REPLACE comparisons use a direct active-PRJ-ID query instead of materializing the full editable join.
- Streamlit caches runtime context, lookups, workbook sheet names/previews, health capability data, prompts, audit results, portfolio administration data and soft-deleted records as appropriate. This avoids repeated API/Excel parsing work while Create/Edit modals rerun.
- View Latest is no longer automatically re-queried on every Streamlit widget rerun. Filter changes are applied when the user clicks View Latest.
- The two final tables (`dbo.prj_attribute_master_new_test` and `dbo.prj_attribute_business_rules_new_test`) remain publication targets only for Finalize and Upload. Create/Edit/Bulk Stage return `final_tables_updated=false`.
- Existing raw landing + staging flow remains intact; no database schema migration is required.

## Compatibility

- Existing MERGE, INSERT_ONLY and REPLACE modes remain supported.
- Portfolio/source behavior, pipe-separated Section/Sub-Section support, soft delete/reactivate, Prompt Management, Audit, S3 export, Admin/User role restrictions, SQL Server and PostgreSQL support remain intact.
- Existing startup ports/commands remain unchanged.

## Validation

- `45/45` pytest tests passed.
- Python `compileall` passed for `src` and `tests`.
- FastAPI application import passed.
- OpenAPI generation passed with `28` API paths.
- Target routes confirmed: Validate & Compare, Stage Uploaded Data, Create/Edit Attribute.
