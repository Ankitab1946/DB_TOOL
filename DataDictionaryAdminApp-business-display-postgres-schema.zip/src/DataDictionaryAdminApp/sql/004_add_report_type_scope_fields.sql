/* SQL Server / Azure SQL migration: add Report Type to raw/staging/final rules
   and make it part of the business-rule unique scope key.
   Safe to rerun. Does not drop application data. Run after 003 migrations. */
SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    BEGIN TRANSACTION;

    IF OBJECT_ID(N'dbo.raw_prj_attribute_new_test', N'U') IS NULL
        THROW 51021, 'dbo.raw_prj_attribute_new_test is missing. Run baseline schema setup first.', 1;
    IF OBJECT_ID(N'stg.prj_attribute_business_rules_new_test', N'U') IS NULL
        THROW 51022, 'stg.prj_attribute_business_rules_new_test is missing. Run baseline schema setup first.', 1;
    IF OBJECT_ID(N'dbo.prj_attribute_business_rules_new_test', N'U') IS NULL
        THROW 51023, 'dbo.prj_attribute_business_rules_new_test is missing. Run baseline schema setup first.', 1;

    IF COL_LENGTH(N'dbo.raw_prj_attribute_new_test', N'report_type') IS NULL
        ALTER TABLE dbo.raw_prj_attribute_new_test
        ADD report_type nvarchar(120) NOT NULL
            CONSTRAINT DF_raw_new_report_type DEFAULT(N'NA') WITH VALUES;

    IF COL_LENGTH(N'stg.prj_attribute_business_rules_new_test', N'report_type') IS NULL
        ALTER TABLE stg.prj_attribute_business_rules_new_test
        ADD report_type nvarchar(120) NOT NULL
            CONSTRAINT DF_stg_rules_new_report_type DEFAULT(N'NA') WITH VALUES;

    IF COL_LENGTH(N'dbo.prj_attribute_business_rules_new_test', N'report_type') IS NULL
        ALTER TABLE dbo.prj_attribute_business_rules_new_test
        ADD report_type nvarchar(120) NOT NULL
            CONSTRAINT DF_rules_new_report_type DEFAULT(N'NA') WITH VALUES;

    /* Remove the previous six-column unique constraint if present. */
    IF EXISTS (
        SELECT 1 FROM sys.key_constraints
        WHERE [type] = 'UQ' AND [name] = N'UQ_stg_rules_new_key'
          AND parent_object_id = OBJECT_ID(N'stg.prj_attribute_business_rules_new_test')
    )
        ALTER TABLE stg.prj_attribute_business_rules_new_test DROP CONSTRAINT UQ_stg_rules_new_key;

    IF EXISTS (
        SELECT 1 FROM sys.key_constraints
        WHERE [type] = 'UQ' AND [name] = N'UQ_rules_new_key'
          AND parent_object_id = OBJECT_ID(N'dbo.prj_attribute_business_rules_new_test')
    )
        ALTER TABLE dbo.prj_attribute_business_rules_new_test DROP CONSTRAINT UQ_rules_new_key;

    /* Recreate the canonical seven-column unique scope key. */
    IF NOT EXISTS (
        SELECT 1 FROM sys.key_constraints
        WHERE [type] = 'UQ' AND [name] = N'UQ_stg_rules_new_key'
          AND parent_object_id = OBJECT_ID(N'stg.prj_attribute_business_rules_new_test')
    )
        ALTER TABLE stg.prj_attribute_business_rules_new_test
        ADD CONSTRAINT UQ_stg_rules_new_key
        UNIQUE(prj_id, port_ref_id, source_abbr_name, display_order, section, subsection, report_type);

    IF NOT EXISTS (
        SELECT 1 FROM sys.key_constraints
        WHERE [type] = 'UQ' AND [name] = N'UQ_rules_new_key'
          AND parent_object_id = OBJECT_ID(N'dbo.prj_attribute_business_rules_new_test')
    )
        ALTER TABLE dbo.prj_attribute_business_rules_new_test
        ADD CONSTRAINT UQ_rules_new_key
        UNIQUE(prj_id, port_ref_id, source_abbr_name, display_order, section, subsection, report_type);

    COMMIT TRANSACTION;
    SELECT N'Report Type migration completed successfully' AS migration_result;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
