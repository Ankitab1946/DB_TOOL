/* PRJ Data Dictionary Administration Platform - new raw/staging/final schema.
   SQL Server 2019+ / Azure SQL compatible. Safe to run repeatedly. */
SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    BEGIN TRANSACTION;

    IF SCHEMA_ID(N'stg') IS NULL EXEC(N'CREATE SCHEMA stg AUTHORIZATION dbo;');

    IF OBJECT_ID(N'dbo.raw_prj_attribute_new_test', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.raw_prj_attribute_new_test (
            raw_row_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_raw_prj_attribute_new_test PRIMARY KEY,
            portfolio varchar(120) NOT NULL,
            prj_id varchar(80) NOT NULL,
            prj_attribute_name nvarchar(500) NOT NULL,
            prj_physical_attribute_name varchar(500) NOT NULL,
            section nvarchar(255) NOT NULL,
            sub_section nvarchar(255) NOT NULL,
            data_type varchar(100) NULL,
            calculated_or_reported varchar(50) NOT NULL,
            calculation_logic nvarchar(max) NOT NULL CONSTRAINT DF_raw_new_calc DEFAULT(N'NA'),
            segment nvarchar(255) NOT NULL CONSTRAINT DF_raw_new_segment DEFAULT(N'NA'),
            attribute_definition nvarchar(max) NULL,
            attribute_description nvarchar(max) NULL,
            display_order int NOT NULL,
            tech_logic nvarchar(max) NULL,
            display_name nvarchar(500) NULL,
            is_active bit NOT NULL CONSTRAINT DF_raw_new_active DEFAULT(1),
            created_at datetime2(3) NOT NULL CONSTRAINT DF_raw_new_created DEFAULT(SYSUTCDATETIME()),
            updated_at datetime2(3) NOT NULL CONSTRAINT DF_raw_new_updated DEFAULT(SYSUTCDATETIME()),
            created_by varchar(128) NOT NULL CONSTRAINT DF_raw_new_created_by DEFAULT('sysuser'),
            updated_by varchar(128) NOT NULL CONSTRAINT DF_raw_new_updated_by DEFAULT('sysuser')
        );
        CREATE INDEX IX_raw_new_prj_id ON dbo.raw_prj_attribute_new_test(prj_id, is_active);
    END;

    IF OBJECT_ID(N'dbo.prj_portfolio_reference_new_test', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.prj_portfolio_reference_new_test (
            port_ref_id int IDENTITY(1,1) NOT NULL CONSTRAINT PK_prj_portfolio_reference_new_test PRIMARY KEY,
            portfolio_name varchar(120) NOT NULL,
            sector_name varchar(120) NOT NULL,
            sub_sector varchar(120) NULL,
            remark nvarchar(500) NULL,
            is_active bit NOT NULL CONSTRAINT DF_port_new_active DEFAULT(1),
            created_at datetime2(3) NOT NULL CONSTRAINT DF_port_new_created DEFAULT(SYSUTCDATETIME()),
            updated_at datetime2(3) NOT NULL CONSTRAINT DF_port_new_updated DEFAULT(SYSUTCDATETIME()),
            created_by varchar(128) NOT NULL CONSTRAINT DF_port_new_created_by DEFAULT('sysuser'),
            updated_by varchar(128) NOT NULL CONSTRAINT DF_port_new_updated_by DEFAULT('sysuser'),
            CONSTRAINT UQ_prj_portfolio_reference_new_test UNIQUE(portfolio_name, sector_name, sub_sector)
        );
    END;

    IF OBJECT_ID(N'dbo.audit_table_new_test', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.audit_table_new_test (
            audit_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_audit_table_new_test PRIMARY KEY,
            schema_name varchar(128) NOT NULL,
            table_name varchar(255) NOT NULL,
            record_key varchar(500) NOT NULL,
            action varchar(50) NOT NULL,
            before_value nvarchar(max) NULL,
            after_value nvarchar(max) NULL,
            source_operation varchar(100) NULL,
            performed_by varchar(128) NOT NULL,
            performed_at datetime2(3) NOT NULL CONSTRAINT DF_audit_new_performed DEFAULT(SYSUTCDATETIME())
        );
        CREATE INDEX IX_audit_new_search ON dbo.audit_table_new_test(performed_at DESC, table_name, action);
    END;

    IF OBJECT_ID(N'stg.prj_attribute_master_new_test', N'U') IS NULL
    BEGIN
        CREATE TABLE stg.prj_attribute_master_new_test (
            prj_id varchar(80) NOT NULL CONSTRAINT PK_stg_prj_attribute_master_new_test PRIMARY KEY,
            prj_attribute_name nvarchar(500) NOT NULL,
            prj_attribute_definition nvarchar(max) NULL,
            prj_physical_attribute_name varchar(500) NOT NULL,
            where_in_financial_statement nvarchar(255) NOT NULL CONSTRAINT DF_stg_master_new_where DEFAULT(N'NA'),
            is_active bit NOT NULL CONSTRAINT DF_stg_master_new_active DEFAULT(1),
            created_at datetime2(3) NOT NULL CONSTRAINT DF_stg_master_new_created DEFAULT(SYSUTCDATETIME()),
            updated_at datetime2(3) NOT NULL CONSTRAINT DF_stg_master_new_updated DEFAULT(SYSUTCDATETIME()),
            created_by varchar(128) NOT NULL CONSTRAINT DF_stg_master_new_created_by DEFAULT('sysuser'),
            updated_by varchar(128) NOT NULL CONSTRAINT DF_stg_master_new_updated_by DEFAULT('sysuser')
        );
        CREATE UNIQUE INDEX UX_stg_master_new_physical ON stg.prj_attribute_master_new_test(prj_physical_attribute_name);
    END;

    IF OBJECT_ID(N'stg.prj_attribute_business_rules_new_test', N'U') IS NULL
    BEGIN
        CREATE TABLE stg.prj_attribute_business_rules_new_test (
            scope_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_stg_prj_attribute_business_rules_new_test PRIMARY KEY,
            prj_id varchar(80) NOT NULL,
            port_ref_id int NOT NULL,
            source_abbr_name varchar(50) NOT NULL CONSTRAINT DF_stg_rules_new_source DEFAULT('SNPAR'),
            editable char(1) NOT NULL,
            symbol varchar(50) NULL,
            mapping_type varchar(50) NOT NULL,
            calculation_logic nvarchar(max) NOT NULL CONSTRAINT DF_stg_rules_new_calc DEFAULT(N'NA'),
            prj_attribute_definition nvarchar(max) NULL,
            prj_attribute_description nvarchar(max) NULL,
            segment nvarchar(255) NOT NULL CONSTRAINT DF_stg_rules_new_segment DEFAULT(N'NA'),
            tech_logic nvarchar(max) NULL,
            display_order int NOT NULL,
            display_name nvarchar(500) NULL,
            section nvarchar(255) NOT NULL,
            subsection nvarchar(255) NOT NULL,
            prompt_description nvarchar(max) NULL,
            examples nvarchar(max) NULL,
            is_active bit NOT NULL CONSTRAINT DF_stg_rules_new_active DEFAULT(1),
            created_at datetime2(3) NOT NULL CONSTRAINT DF_stg_rules_new_created DEFAULT(SYSUTCDATETIME()),
            updated_at datetime2(3) NOT NULL CONSTRAINT DF_stg_rules_new_updated DEFAULT(SYSUTCDATETIME()),
            created_by varchar(128) NOT NULL CONSTRAINT DF_stg_rules_new_created_by DEFAULT('sysuser'),
            updated_by varchar(128) NOT NULL CONSTRAINT DF_stg_rules_new_updated_by DEFAULT('sysuser'),
            CONSTRAINT FK_stg_rules_new_master FOREIGN KEY(prj_id) REFERENCES stg.prj_attribute_master_new_test(prj_id),
            CONSTRAINT FK_stg_rules_new_portfolio FOREIGN KEY(port_ref_id) REFERENCES dbo.prj_portfolio_reference_new_test(port_ref_id),
            CONSTRAINT CK_stg_rules_new_editable CHECK(editable IN ('Y','N')),
            CONSTRAINT UQ_stg_rules_new_key UNIQUE(prj_id, port_ref_id, source_abbr_name, display_order, section, subsection)
        );
        CREATE INDEX IX_stg_rules_new_prj ON stg.prj_attribute_business_rules_new_test(prj_id, is_active);
    END;

    IF OBJECT_ID(N'dbo.prj_attribute_master_new_test', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.prj_attribute_master_new_test (
            prj_id varchar(80) NOT NULL CONSTRAINT PK_prj_attribute_master_new_test PRIMARY KEY,
            prj_attribute_name nvarchar(500) NOT NULL,
            prj_attribute_definition nvarchar(max) NULL,
            prj_physical_attribute_name varchar(500) NOT NULL,
            where_in_financial_statement nvarchar(255) NOT NULL CONSTRAINT DF_master_new_where DEFAULT(N'NA'),
            is_active bit NOT NULL CONSTRAINT DF_master_new_active DEFAULT(1),
            created_at datetime2(3) NOT NULL CONSTRAINT DF_master_new_created DEFAULT(SYSUTCDATETIME()),
            updated_at datetime2(3) NOT NULL CONSTRAINT DF_master_new_updated DEFAULT(SYSUTCDATETIME()),
            created_by varchar(128) NOT NULL CONSTRAINT DF_master_new_created_by DEFAULT('sysuser'),
            updated_by varchar(128) NOT NULL CONSTRAINT DF_master_new_updated_by DEFAULT('sysuser')
        );
        CREATE UNIQUE INDEX UX_master_new_physical ON dbo.prj_attribute_master_new_test(prj_physical_attribute_name);
    END;

    IF OBJECT_ID(N'dbo.prj_attribute_business_rules_new_test', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.prj_attribute_business_rules_new_test (
            scope_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_prj_attribute_business_rules_new_test PRIMARY KEY,
            prj_id varchar(80) NOT NULL,
            port_ref_id int NOT NULL,
            source_abbr_name varchar(50) NOT NULL CONSTRAINT DF_rules_new_source DEFAULT('SNPAR'),
            editable char(1) NOT NULL,
            symbol varchar(50) NULL,
            mapping_type varchar(50) NOT NULL,
            calculation_logic nvarchar(max) NOT NULL CONSTRAINT DF_rules_new_calc DEFAULT(N'NA'),
            prj_attribute_definition nvarchar(max) NULL,
            prj_attribute_description nvarchar(max) NULL,
            segment nvarchar(255) NOT NULL CONSTRAINT DF_rules_new_segment DEFAULT(N'NA'),
            tech_logic nvarchar(max) NULL,
            display_order int NOT NULL,
            display_name nvarchar(500) NULL,
            section nvarchar(255) NOT NULL,
            subsection nvarchar(255) NOT NULL,
            prompt_description nvarchar(max) NULL,
            examples nvarchar(max) NULL,
            is_active bit NOT NULL CONSTRAINT DF_rules_new_active DEFAULT(1),
            created_at datetime2(3) NOT NULL CONSTRAINT DF_rules_new_created DEFAULT(SYSUTCDATETIME()),
            updated_at datetime2(3) NOT NULL CONSTRAINT DF_rules_new_updated DEFAULT(SYSUTCDATETIME()),
            created_by varchar(128) NOT NULL CONSTRAINT DF_rules_new_created_by DEFAULT('sysuser'),
            updated_by varchar(128) NOT NULL CONSTRAINT DF_rules_new_updated_by DEFAULT('sysuser'),
            CONSTRAINT FK_rules_new_master FOREIGN KEY(prj_id) REFERENCES dbo.prj_attribute_master_new_test(prj_id),
            CONSTRAINT FK_rules_new_portfolio FOREIGN KEY(port_ref_id) REFERENCES dbo.prj_portfolio_reference_new_test(port_ref_id),
            CONSTRAINT CK_rules_new_editable CHECK(editable IN ('Y','N')),
            CONSTRAINT UQ_rules_new_key UNIQUE(prj_id, port_ref_id, source_abbr_name, display_order, section, subsection)
        );
        CREATE INDEX IX_rules_new_prj ON dbo.prj_attribute_business_rules_new_test(prj_id, is_active);
        CREATE INDEX IX_rules_new_filters ON dbo.prj_attribute_business_rules_new_test(port_ref_id, source_abbr_name, section, subsection, is_active);
    END;

    /* Stable reference IDs required by the business-rule mapping. */
    IF EXISTS (SELECT 1 FROM dbo.prj_portfolio_reference_new_test WHERE port_ref_id=1 AND NOT (portfolio_name='FI' AND sector_name='Banks'))
        THROW 51001, 'port_ref_id 1 is reserved for FI/Banks by the application contract.', 1;
    IF EXISTS (SELECT 1 FROM dbo.prj_portfolio_reference_new_test WHERE port_ref_id=2 AND NOT (portfolio_name='FI' AND sector_name='Insurance'))
        THROW 51002, 'port_ref_id 2 is reserved for FI/Insurance by the application contract.', 1;
    IF EXISTS (SELECT 1 FROM dbo.prj_portfolio_reference_new_test WHERE port_ref_id=3 AND NOT (portfolio_name='Corporate' AND sector_name='Corporate'))
        THROW 51003, 'port_ref_id 3 is reserved for Corporate/Corporate by the application contract.', 1;
    IF EXISTS (SELECT 1 FROM dbo.prj_portfolio_reference_new_test WHERE port_ref_id=4 AND NOT (portfolio_name='UKC' AND sector_name='UKC'))
        THROW 51004, 'port_ref_id 4 is reserved for UKC/UKC by the application contract.', 1;

    SET IDENTITY_INSERT dbo.prj_portfolio_reference_new_test ON;
    IF NOT EXISTS (SELECT 1 FROM dbo.prj_portfolio_reference_new_test WHERE port_ref_id=1)
        INSERT dbo.prj_portfolio_reference_new_test(port_ref_id,portfolio_name,sector_name,sub_sector,remark)
        VALUES(1,'FI','Banks',NULL,N'Financial Institutes - Banks');
    IF NOT EXISTS (SELECT 1 FROM dbo.prj_portfolio_reference_new_test WHERE port_ref_id=2)
        INSERT dbo.prj_portfolio_reference_new_test(port_ref_id,portfolio_name,sector_name,sub_sector,remark)
        VALUES(2,'FI','Insurance',NULL,N'Financial Institutes - Insurance');
    IF NOT EXISTS (SELECT 1 FROM dbo.prj_portfolio_reference_new_test WHERE port_ref_id=3)
        INSERT dbo.prj_portfolio_reference_new_test(port_ref_id,portfolio_name,sector_name,sub_sector,remark)
        VALUES(3,'Corporate','Corporate',NULL,N'Global Corporates');
    IF NOT EXISTS (SELECT 1 FROM dbo.prj_portfolio_reference_new_test WHERE port_ref_id=4)
        INSERT dbo.prj_portfolio_reference_new_test(port_ref_id,portfolio_name,sector_name,sub_sector,remark)
        VALUES(4,'UKC','UKC',NULL,N'UK Corporate');
    SET IDENTITY_INSERT dbo.prj_portfolio_reference_new_test OFF;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
