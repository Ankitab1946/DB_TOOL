from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import Response
from sqlalchemy.orm import Session

from DataDictionaryAdminAppAPI.api.schemas_api import AttributeBatchRequest, AttributeUpsert, DiscardFinalizeRequest, FilterRequest, FinalizeRequest
from DataDictionaryAdminAppAPI.core.database import get_db
from DataDictionaryAdminAppAPI.service.data_dictionary_service import DataDictionaryService
from DataDictionaryAdminAppAPI.service.excel_service import ExcelService
from DataDictionaryAdminAppAPI.utils.security import current_user

router = APIRouter(prefix="/data-dictionary", tags=["Data Dictionary"])

@router.post("/filter-page")
def filter_page(payload: FilterRequest, db: Session = Depends(get_db)):
    return DataDictionaryService(db).filter(payload)

@router.get("/edit-latest")
def edit_latest(include_deleted: bool = True, db: Session = Depends(get_db)):
    return DataDictionaryService(db).editable_rows(include_deleted=include_deleted)

@router.get("/soft-deleted")
def soft_deleted(db: Session = Depends(get_db)):
    return DataDictionaryService(db).soft_deleted_rows()

@router.get("/attributes/{prj_id}")
def detail(prj_id: str, db: Session = Depends(get_db)):
    return DataDictionaryService(db).detail(prj_id)

@router.post("/attributes")
def create_attribute(payload: AttributeUpsert, request: Request, db: Session = Depends(get_db)):
    user = current_user(request)
    service = DataDictionaryService(db)
    # The UI pre-generates and displays the CFV/PRJ ID in read-only form. Preserve
    # that exact identifier on save so the value shown to the user is the value staged.
    if not payload.prj_id:
        payload.prj_id = service.next_prj_id()
    elif payload.prj_id in service.repo.existing_prj_ids():
        raise HTTPException(
            status_code=409,
            detail=f"CFV ID {payload.prj_id} is no longer available. Close and reopen Create New Attribute to generate the next ID.",
        )
    return service.stage_attribute(payload, user, "UI_CREATE")

@router.put("/attributes/{prj_id}")
def edit_attribute(prj_id: str, payload: AttributeUpsert, request: Request, db: Session = Depends(get_db)):
    user = current_user(request)
    payload.prj_id = prj_id
    return DataDictionaryService(db).stage_attribute(payload, user, "UI_EDIT")

@router.post("/batch-stage")
def batch_stage(payload: AttributeBatchRequest, request: Request, db: Session = Depends(get_db)):
    user = current_user(request)
    return DataDictionaryService(db).stage_batch(payload.rows, user)

@router.delete("/attributes/{prj_id}")
def soft_delete(prj_id: str, request: Request, db: Session = Depends(get_db)):
    user = current_user(request)
    return DataDictionaryService(db).stage_delete(prj_id, user)

@router.post("/attributes/{prj_id}/reactivate")
def reactivate(prj_id: str, request: Request, db: Session = Depends(get_db)):
    user = current_user(request)
    return DataDictionaryService(db).stage_reactivate(prj_id, user)

@router.get("/delta")
def delta(db: Session = Depends(get_db)):
    return DataDictionaryService(db).delta()

@router.post("/finalize")
def finalize(payload: FinalizeRequest, request: Request, db: Session = Depends(get_db)):
    user = current_user(request)
    return DataDictionaryService(db).finalize(user, payload.confirm)

@router.post("/discard-finalize")
def discard_finalize(payload: DiscardFinalizeRequest, request: Request, db: Session = Depends(get_db)):
    user = current_user(request)
    return DataDictionaryService(db).discard_finalize(user, payload.prj_ids, payload.confirm)

@router.get("/download-latest")
def download_latest(db: Session = Depends(get_db)):
    service = DataDictionaryService(db)
    all_rows = []
    page = 1
    while True:
        result = service.filter(FilterRequest(page=page, page_size=1000, include_deleted=False))
        all_rows.extend(result["rows"])
        if len(all_rows) >= result["total"] or not result["rows"]:
            break
        page += 1
    content = ExcelService.latest_workbook(all_rows)
    return Response(
        content=content,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": 'attachment; filename="prj_master_dictionary_latest.xlsx"'},
    )
