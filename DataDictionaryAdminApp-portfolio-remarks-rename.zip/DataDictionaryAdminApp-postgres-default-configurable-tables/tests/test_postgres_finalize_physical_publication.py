from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session

from DataDictionaryAdminApp.service.data_dictionary_service import DataDictionaryService


def _create_pg_physical_contract(session: Session) -> None:
    session.execute(text("ATTACH DATABASE ':memory:' AS prj_stage"))
    session.execute(text("ATTACH DATABASE ':memory:' AS prj_dbd"))
    session.execute(text("""
        CREATE TABLE prj_dbd.prj_portfolio_reference (
            port_ref_id INTEGER PRIMARY KEY,
            portfolio_name TEXT,
            sector_name TEXT
        )
    """))
    session.execute(text("INSERT INTO prj_dbd.prj_portfolio_reference VALUES (10, 'FI', 'Banks')"))

    for schema in ("prj_stage", "prj_dbd"):
        session.execute(text(f"""
            CREATE TABLE {schema}.prj_attribute_master_new_test (
                prj_id TEXT PRIMARY KEY,
                prj_attribute_name TEXT NOT NULL,
                prj_attribute_definition TEXT,
                prj_physical_attribute_name TEXT NOT NULL UNIQUE,
                where_in_financial_statement TEXT NOT NULL,
                is_active BOOLEAN NOT NULL,
                created_at DATETIME,
                updated_at DATETIME,
                created_by TEXT,
                updated_by TEXT
            )
        """))
        session.execute(text(f"""
            CREATE TABLE {schema}.prj_attribute_business_rules_new_test (
                scope_id INTEGER PRIMARY KEY AUTOINCREMENT,
                prj_id TEXT NOT NULL,
                port_ref_id INTEGER NOT NULL,
                source_abbr_name TEXT NOT NULL,
                prompt_description TEXT,
                examples_for_llm TEXT,
                editable TEXT NOT NULL,
                data_type TEXT,
                attribute_type TEXT NOT NULL,
                business_logic TEXT,
                calculation_logic TEXT NOT NULL,
                created_at DATETIME,
                updated_at DATETIME,
                created_by TEXT,
                updated_by TEXT
            )
        """))
        session.execute(text(f"""
            CREATE TABLE {schema}.prj_attribute_display_test (
                display_id INTEGER PRIMARY KEY AUTOINCREMENT,
                scope_id INTEGER NOT NULL UNIQUE,
                display_order INTEGER NOT NULL,
                prj_id TEXT NOT NULL,
                display_name TEXT,
                section TEXT NOT NULL,
                subsection TEXT NOT NULL,
                prj_attribute_definition TEXT,
                prj_attribute_description TEXT,
                segment TEXT NOT NULL,
                report_type TEXT NOT NULL,
                created_at DATETIME,
                updated_at DATETIME,
                created_by TEXT,
                updated_by TEXT
            )
        """))

    session.execute(text("""
        CREATE TABLE prj_dbd.audit_table_new_test (
            audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
            schema_name TEXT NOT NULL,
            table_name TEXT NOT NULL,
            record_key TEXT NOT NULL,
            action TEXT NOT NULL,
            before_value TEXT,
            after_value TEXT,
            source_operation TEXT,
            performed_by TEXT NOT NULL,
            performed_at DATETIME NOT NULL
        )
    """))
    session.commit()


def test_postgres_finalize_publishes_physical_staging_to_main_and_clears_staging():
    engine = create_engine("sqlite+pysqlite:///:memory:", future=True)
    with Session(engine) as session:
        _create_pg_physical_contract(session)
        session.execute(text("""
            INSERT INTO prj_stage.prj_attribute_master_new_test
            (prj_id,prj_attribute_name,prj_attribute_definition,prj_physical_attribute_name,
             where_in_financial_statement,is_active,created_by,updated_by)
            VALUES ('PRJ900','Revenue','Revenue definition','revenue','Income Statement',1,'tester','tester')
        """))
        session.execute(text("""
            INSERT INTO prj_stage.prj_attribute_business_rules_new_test
            (prj_id,port_ref_id,source_abbr_name,prompt_description,examples_for_llm,editable,
             data_type,attribute_type,business_logic,calculation_logic,created_by,updated_by)
            VALUES ('PRJ900',10,'SRC','Prompt','Example','Y','Amount','Reported','PRJ1+PRJ2','NA','tester','tester')
        """))
        scope_id = session.execute(text("SELECT scope_id FROM prj_stage.prj_attribute_business_rules_new_test")).scalar_one()
        session.execute(text("""
            INSERT INTO prj_stage.prj_attribute_display_test
            (scope_id,display_order,prj_id,display_name,section,subsection,prj_attribute_definition,
             prj_attribute_description,segment,report_type,created_by,updated_by)
            VALUES (:scope_id,1,'PRJ900','Revenue','Income','Total','Revenue definition',
                    'Revenue description','NA','Annual','tester','tester')
        """), {"scope_id": scope_id})
        session.commit()

        service = DataDictionaryService(session)
        result = service._finalize_postgres(
            "tester",
            {"has_changes": True, "count": 1, "rows": [{"prj_id": "PRJ900"}]},
        )

        assert result["updated"] == 1
        assert session.execute(text("SELECT count(*) FROM prj_dbd.prj_attribute_master_new_test WHERE prj_id='PRJ900'")).scalar_one() == 1
        assert session.execute(text("SELECT count(*) FROM prj_dbd.prj_attribute_business_rules_new_test WHERE prj_id='PRJ900'")).scalar_one() == 1
        assert session.execute(text("SELECT count(*) FROM prj_dbd.prj_attribute_display_test WHERE prj_id='PRJ900'")).scalar_one() == 1
        assert session.execute(text("SELECT count(*) FROM prj_stage.prj_attribute_master_new_test")).scalar_one() == 0
        assert session.execute(text("SELECT count(*) FROM prj_stage.prj_attribute_business_rules_new_test")).scalar_one() == 0
        assert session.execute(text("SELECT count(*) FROM prj_stage.prj_attribute_display_test")).scalar_one() == 0
        assert session.execute(text("SELECT count(*) FROM prj_dbd.audit_table_new_test WHERE source_operation='FINALIZE'")).scalar_one() == 3


def test_finalize_contains_postgres_specific_branch_and_sqlserver_path_remains_after_it():
    source = open("src/DataDictionaryAdminApp/service/data_dictionary_service.py", encoding="utf-8").read()
    assert 'if self.db.get_bind().dialect.name == "postgresql":' in source
    assert 'return self._finalize_postgres(user, delta)' in source
    # Existing SQL Server ORM publication remains in the same method after the PostgreSQL branch.
    assert 'self._upsert_final_master(staged_master, user)' in source
    assert 'self._upsert_final_rule(staged_rule, user, strict_key=occurrence > 0)' in source
