from pathlib import Path

APP = Path('src/DataDictionaryAdminApp/streamlit_app.py').read_text(encoding='utf-8')


def test_create_and_edit_keep_wide_modal_configuration():
    assert 'key="create_attribute_modal"' in APP
    assert 'key="edit_attribute_modal"' in APP
    assert APP.count('max_width=1900') >= 2


def test_attribute_modal_card_is_centered_against_viewport():
    assert 'top: 50% !important;' in APP
    assert 'left: 50% !important;' in APP
    assert 'transform: translate(-50%, -50%) !important;' in APP
    assert 'width: 96vw !important;' in APP
    assert 'max-height: 90vh !important;' in APP


def test_modal_style_is_applied_to_create_and_edit():
    assert 'render_attribute_modal_style("create_attribute_modal")' in APP
    assert 'render_attribute_modal_style("edit_attribute_modal")' in APP
