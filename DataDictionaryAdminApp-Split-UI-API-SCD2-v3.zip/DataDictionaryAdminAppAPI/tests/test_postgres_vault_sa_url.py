from pathlib import Path

import pytest

from DataDictionaryAdminAppAPI.config import Settings, _extract_yaml_values


def test_yaml_accepts_exact_sa_url_path_and_vault_role_names():
    values = _extract_yaml_values({
        "database": {
            "postgres": {
                "SaURLPath": "/vault/secrets/prj-pg-url",
                "vaultRoleName": "prj-dev-role",
            }
        }
    })
    assert values["PG_SA_URL_PATH"] == "/vault/secrets/prj-pg-url"
    assert values["PG_VAULT_ROLE_NAME"] == "prj-dev-role"


def test_mounted_sa_url_file_replaces_static_username_password(tmp_path, monkeypatch):
    secret = tmp_path / "pg-url"
    secret.write_text("postgresql://vault_user:vault_pw@vault-pg:5432/vault_db", encoding="utf-8")
    monkeypatch.setenv("ENV_DEV_ENABLE_POSTGRES", "true")
    monkeypatch.setenv("ENV_DEV_PG_SA_URL_PATH", str(secret))
    monkeypatch.setenv("ENV_DEV_PG_VAULT_ROLE_NAME", "prj-dev-role")
    monkeypatch.setenv("ENV_DEV_POSTGRES_USER", "should_not_be_used")
    monkeypatch.setenv("ENV_DEV_POSTGRES_PASSWORD", "should_not_be_used")

    settings = Settings(selected_environment="DEV", enable_postgres=True)
    url = settings.sqlalchemy_url("DEV", "POSTGRES")
    assert url.drivername == "postgresql+psycopg"
    assert url.username == "vault_user"
    assert url.password == "vault_pw"
    assert url.host == "vault-pg"
    assert url.database == "vault_db"
    assert url.query["sslmode"] == "prefer"


def test_direct_sa_url_alias_works_without_user_password(monkeypatch):
    monkeypatch.setenv("ENV_DEV_ENABLE_POSTGRES", "true")
    monkeypatch.setenv("ENV_DEV_SA_URL_PATH", "postgresql://sa_user:sa_pw@sa-host:5432/sa_db?sslmode=require")
    monkeypatch.setenv("ENV_DEV_VAULT_ROLE_NAME", "role-a")
    monkeypatch.delenv("ENV_DEV_POSTGRES_USER", raising=False)
    monkeypatch.delenv("ENV_DEV_POSTGRES_PASSWORD", raising=False)

    settings = Settings(selected_environment="DEV", enable_postgres=True, postgres_user="", postgres_password="")
    cfg = settings.database_config("DEV", "POSTGRES")
    assert cfg["sa_url_path"].startswith("postgresql://")
    assert cfg["vault_role_name"] == "role-a"
    url = settings.sqlalchemy_url("DEV", "POSTGRES")
    assert url.host == "sa-host"
    assert url.username == "sa_user"


def test_vault_kubernetes_login_and_kv2_secret(monkeypatch, tmp_path):
    jwt = tmp_path / "token"
    jwt.write_text("pod-jwt", encoding="utf-8")
    monkeypatch.setenv("ENV_DEV_ENABLE_POSTGRES", "true")
    monkeypatch.setenv("ENV_DEV_PG_SA_URL_PATH", "secret/data/apps/prj/postgres")
    monkeypatch.setenv("ENV_DEV_PG_VAULT_ROLE_NAME", "prj-dev-role")
    monkeypatch.setenv("ENV_DEV_VAULT_ADDR", "https://vault.internal")
    monkeypatch.setenv("ENV_DEV_VAULT_K8S_JWT_PATH", str(jwt))
    monkeypatch.delenv("VAULT_TOKEN", raising=False)

    calls = []

    class Response:
        def __init__(self, payload):
            self.payload = payload
        def raise_for_status(self):
            return None
        def json(self):
            return self.payload

    def fake_post(url, **kwargs):
        calls.append(("POST", url, kwargs))
        assert kwargs["json"] == {"role": "prj-dev-role", "jwt": "pod-jwt"}
        return Response({"auth": {"client_token": "vault-token"}})

    def fake_get(url, **kwargs):
        calls.append(("GET", url, kwargs))
        assert kwargs["headers"]["X-Vault-Token"] == "vault-token"
        return Response({"data": {"data": {"saURL": "postgresql://dyn:secret@pg-vault:5432/prj"}}})

    monkeypatch.setattr("DataDictionaryAdminAppAPI.config.requests.post", fake_post)
    monkeypatch.setattr("DataDictionaryAdminAppAPI.config.requests.get", fake_get)

    settings = Settings(selected_environment="DEV", enable_postgres=True)
    url = settings.sqlalchemy_url("DEV", "POSTGRES")
    assert url.host == "pg-vault"
    assert url.username == "dyn"
    assert len(calls) == 2


def test_static_postgres_credentials_remain_fallback(monkeypatch):
    for key in (
        "ENV_DEV_PG_SA_URL_PATH", "ENV_DEV_SA_URL_PATH", "PG_SA_URL_PATH", "SA_URL_PATH", "SA_URLPATH"
    ):
        monkeypatch.delenv(key, raising=False)
    settings = Settings(
        selected_environment="DEV",
        enable_postgres=True,
        pg_host="legacy-host",
        pg_database="legacy-db",
        postgres_user="legacy-user",
        postgres_password="legacy-pw",
    )
    url = settings.sqlalchemy_url("DEV", "POSTGRES")
    assert url.host == "legacy-host"
    assert url.username == "legacy-user"
    assert url.password == "legacy-pw"


def test_vault_database_dynamic_credentials_build_url_from_pg_metadata(monkeypatch, tmp_path):
    jwt = tmp_path / "token-dynamic"
    jwt.write_text("pod-jwt", encoding="utf-8")
    monkeypatch.setenv("ENV_DEV_ENABLE_POSTGRES", "true")
    monkeypatch.setenv("ENV_DEV_PG_HOST", "dynamic-pg.internal")
    monkeypatch.setenv("ENV_DEV_PG_PORT", "5432")
    monkeypatch.setenv("ENV_DEV_PG_DATABASE", "PRJ_DB")
    monkeypatch.setenv("ENV_DEV_PG_SA_URL_PATH", "database/creds/prj-role")
    monkeypatch.setenv("ENV_DEV_PG_VAULT_ROLE_NAME", "prj-dev-role")
    monkeypatch.setenv("ENV_DEV_VAULT_ADDR", "https://vault.internal")
    monkeypatch.setenv("ENV_DEV_VAULT_K8S_JWT_PATH", str(jwt))
    monkeypatch.delenv("VAULT_TOKEN", raising=False)

    class Response:
        def __init__(self, payload):
            self.payload = payload
        def raise_for_status(self):
            return None
        def json(self):
            return self.payload

    monkeypatch.setattr(
        "DataDictionaryAdminAppAPI.config.requests.post",
        lambda *a, **k: Response({"auth": {"client_token": "vault-token"}}),
    )
    monkeypatch.setattr(
        "DataDictionaryAdminAppAPI.config.requests.get",
        lambda *a, **k: Response({"data": {"username": "v-dynamic", "password": "v-secret"}}),
    )

    settings = Settings(selected_environment="DEV", enable_postgres=True)
    url = settings.sqlalchemy_url("DEV", "POSTGRES")
    assert url.host == "dynamic-pg.internal"
    assert url.database == "PRJ_DB"
    assert url.username == "v-dynamic"
    assert url.password == "v-secret"


def test_exact_camelcase_process_env_names_are_supported(monkeypatch):
    monkeypatch.setenv("ENV_DEV_ENABLE_POSTGRES", "true")
    monkeypatch.setenv("ENV_DEV_SaURLPath", "postgresql://camel:secret@camel-pg:5432/camel_db")
    monkeypatch.setenv("ENV_DEV_vaultRoleName", "camel-role")
    settings = Settings(selected_environment="DEV", enable_postgres=True)
    cfg = settings.database_config("DEV", "POSTGRES")
    assert cfg["vault_role_name"] == "camel-role"
    assert cfg["auth_mode"] == "SA_URL_VAULT"
    url = settings.sqlalchemy_url("DEV", "POSTGRES")
    assert url.host == "camel-pg"
