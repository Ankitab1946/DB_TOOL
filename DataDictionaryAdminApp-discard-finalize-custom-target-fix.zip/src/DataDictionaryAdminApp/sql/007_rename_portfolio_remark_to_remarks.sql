/* SQL Server existing-database migration: rename Portfolio Reference column
   dbo.prj_portfolio_reference_new_test.remark -> remarks

   Safe/idempotent behavior:
   - Renames only when legacy [remark] exists and [remarks] does not.
   - Does nothing when [remarks] already exists.
   - Fails if both columns exist, because automatic merge/drop could lose data.
   - Does not delete or recreate the table or portfolio rows.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

IF OBJECT_ID(N'dbo.prj_portfolio_reference_new_test', N'U') IS NULL
    THROW 51097, 'Required table dbo.prj_portfolio_reference_new_test does not exist.', 1;

IF COL_LENGTH('dbo.prj_portfolio_reference_new_test', 'remark') IS NOT NULL
   AND COL_LENGTH('dbo.prj_portfolio_reference_new_test', 'remarks') IS NOT NULL
    THROW 51098, 'Both remark and remarks columns exist on dbo.prj_portfolio_reference_new_test. Resolve the duplicate columns manually before running migration 007.', 1;

IF COL_LENGTH('dbo.prj_portfolio_reference_new_test', 'remark') IS NOT NULL
   AND COL_LENGTH('dbo.prj_portfolio_reference_new_test', 'remarks') IS NULL
BEGIN
    EXEC sys.sp_rename
        N'dbo.prj_portfolio_reference_new_test.remark',
        N'remarks',
        N'COLUMN';
END;

IF COL_LENGTH('dbo.prj_portfolio_reference_new_test', 'remarks') IS NULL
    THROW 51099, 'Migration 007 failed: dbo.prj_portfolio_reference_new_test.remarks was not found after migration.', 1;

SELECT 'Migration 007 completed successfully' AS migration_status,
       'dbo.prj_portfolio_reference_new_test.remarks' AS canonical_column;
