from __future__ import annotations

import os
from fastapi import HTTPException, Request

from DataDictionaryAdminApp.config import get_settings


def current_user(request: Request) -> str:
    return (
        request.headers.get("X-App-User")
        or request.headers.get("X-Forwarded-User")
        or os.getenv("USERNAME")
        or os.getenv("USER")
        or get_settings().default_user
        or "sysuser"
    )


def require_admin(request: Request) -> str:
    user = current_user(request)
    if get_settings().is_admin(user):
        return user
    raise HTTPException(status_code=403, detail="Admin access is required for this operation.")
