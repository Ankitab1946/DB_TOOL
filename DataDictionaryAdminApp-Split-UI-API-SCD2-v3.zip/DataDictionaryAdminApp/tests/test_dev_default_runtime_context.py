from pathlib import Path

from DataDictionaryAdminApp.config import Settings


def test_default_runtime_environment_is_dev(monkeypatch):
    for key in ("SELECTED_ENVIRONMENT", "APP_ENV"):
        monkeypatch.delenv(key, raising=False)
    settings = Settings(_env_file=None)
    assert settings.app_env == "DEV"
    assert settings.selected_environment == "DEV"
    assert settings.resolve_environment() == "DEV"


def test_streamlit_runtime_fallback_is_dev():
    source = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
    assert 'os.getenv("SELECTED_ENVIRONMENT", "DEV")' in source
    assert 'st.session_state.get("environment", "DEV")' in source


def test_example_config_defaults_to_dev():
    env_example = Path(".env.example").read_text(encoding="utf-8")
    assert "APP_ENV=DEV" in env_example
    assert "SELECTED_ENVIRONMENT=DEV" in env_example


def test_streamlit_sidebar_normalizes_and_falls_back_to_dev():
    source = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
    assert '(os.getenv("SELECTED_ENVIRONMENT") or "DEV").strip().upper()' in source
    assert 'current_env = str(st.session_state.get("environment") or "DEV").strip().upper()' in source
    assert 'current_env = "DEV"' in source
    assert 'st.session_state["environment"] = "DEV"' in source


def test_streamlit_environment_widget_itself_initializes_to_dev():
    source = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
    assert 'if "runtime_environment_selector" not in st.session_state:' in source
    assert 'st.session_state["runtime_environment_selector"] = "DEV"' in source
    assert 'st.session_state["environment"] = "DEV"' in source
    assert 'st.selectbox("Environment", environments, key="runtime_environment_selector")' in source
