"""Authoritative table contract for the new raw -> staging -> final structure."""

RAW_ATTRIBUTE = "dbo.raw_prj_attribute_new_test"
PORTFOLIO_REFERENCE = "dbo.prj_portfolio_reference_new_test"
DATA_SOURCES = "dbo.prj_data_sources"  # Existing read-only dependency. Never created by this app.
AUDIT = "dbo.audit_table_new_test"
STG_ATTRIBUTE_MASTER = "stg.prj_attribute_master_new_test"
STG_ATTRIBUTE_BUSINESS_RULES = "stg.prj_attribute_business_rules_new_test"
ATTRIBUTE_MASTER = "dbo.prj_attribute_master_new_test"
ATTRIBUTE_BUSINESS_RULES = "dbo.prj_attribute_business_rules_new_test"

APPLICATION_MANAGED_TABLES = (
    RAW_ATTRIBUTE,
    PORTFOLIO_REFERENCE,
    AUDIT,
    STG_ATTRIBUTE_MASTER,
    STG_ATTRIBUTE_BUSINESS_RULES,
    ATTRIBUTE_MASTER,
    ATTRIBUTE_BUSINESS_RULES,
)

S3_EXPORTS = (
    ("prj_attribute_master_new_test", ATTRIBUTE_MASTER),
    ("prj_attribute_business_rules_new_test", ATTRIBUTE_BUSINESS_RULES),
)

RAW_FIELDS = (
    "portfolio",
    "prj_id",
    "prj_attribute_name",
    "prj_physical_attribute_name",
    "section",
    "sub_section",
    "data_type",
    "calculated_or_reported",
    "calculation_logic",
    "segment",
    "report_type",
    "attribute_definition",
    "attribute_description",
    "display_order",
    "tech_logic",
    "display_name",
)

MASTER_FIELDS = (
    "prj_id",
    "prj_attribute_name",
    "prj_attribute_definition",
    "prj_physical_attribute_name",
    "where_in_financial_statement",
)

BUSINESS_RULE_FIELDS = (
    "scope_id",
    "prj_id",
    "port_ref_id",
    "source_abbr_name",
    "editable",
    "symbol",
    "mapping_type",
    "calculation_logic",
    "prj_attribute_definition",
    "prj_attribute_description",
    "segment",
    "report_type",
    "tech_logic",
    "display_order",
    "display_name",
    "section",
    "subsection",
    "prompt_description",
    "examples",
)
