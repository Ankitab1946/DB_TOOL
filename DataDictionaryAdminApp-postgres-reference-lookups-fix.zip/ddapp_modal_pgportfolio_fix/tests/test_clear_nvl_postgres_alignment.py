from pathlib import Path
import re

from sqlalchemy import delete, select, true, update
from sqlalchemy.dialects import postgresql

from DataDictionaryAdminApp.model.entities import (
    AttributeBusinessRule,
    AttributeDisplay,
    AttributeMaster,
    AuditTable,
    PortfolioReference,
    RawAttribute,
    StagingAttributeMaster,
    StagingAttributeDisplay,
    StagingBusinessRule,
)
from DataDictionaryAdminApp.utils.normalizers import generate_tech_logic


STREAMLIT = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
PG_SQL_DIR = Path("src/DataDictionaryAdminApp/sql/postgres")


def test_clear_filters_explicitly_blank_visible_widget_state():
    block = STREAMLIT.split("def clear_view_filters()", 1)[1].split("def database_status_check", 1)[0]
    assert '"view_portfolio_filter": []' in block
    assert '"view_source_filter": []' in block
    assert '"view_prj_id_filter": ""' in block
    assert '"view_attribute_name_filter": ""' in block
    assert '"view_attribute_definition_filter": ""' in block
    assert '"view_section_filter": ""' in block
    assert '"view_subsection_filter": ""' in block
    assert '"view_search_filter": ""' in block
    assert '"view_overlapped_filter": False' in block
    assert '"view_include_inactive_filter": False' in block
    assert '"view_page_number_filter": 1' in block
    assert '"view_page_size_filter": 100' in block


def test_tech_logic_preserves_nvl_and_bodmas_while_removing_label_slashes():
    assert generate_tech_logic(
        "Total Income(PRJ362) = EBITDA(PRJ43843) /nvl(Debt/Amount(PRJ4343)+ EBITDA(PRJ43843))"
    ) == "PRJ362 = PRJ43843/nvl(PRJ4343+PRJ43843)"
    assert generate_tech_logic(
        "Total(PRJ1) = nvl((EBITDA(PRJ2) + Debt(PRJ3)) / Amount(PRJ4), 0)"
    ) == "PRJ1 = nvl((PRJ2+PRJ3)/PRJ4,0)"


def test_core_runtime_statements_compile_for_postgres():
    dialect = postgresql.dialect()
    statements = [
        select(PortfolioReference).where(PortfolioReference.is_active == true()),
        select(AttributeMaster, AttributeBusinessRule, AttributeDisplay, PortfolioReference)
        .join(AttributeBusinessRule, AttributeBusinessRule.prj_id == AttributeMaster.prj_id)
        .join(AttributeDisplay, AttributeDisplay.scope_id == AttributeBusinessRule.scope_id)
        .join(PortfolioReference, PortfolioReference.port_ref_id == AttributeBusinessRule.port_ref_id)
        .where(AttributeMaster.is_active == true()),
        select(RawAttribute).where(RawAttribute.prj_id == "PRJ1", RawAttribute.is_active == true()),
        select(StagingAttributeMaster).where(StagingAttributeMaster.prj_id == "PRJ1"),
        select(StagingBusinessRule).where(StagingBusinessRule.prj_id == "PRJ1"),
        update(AttributeMaster).where(AttributeMaster.prj_id == "PRJ1").values(is_active=False),
        delete(AuditTable).where(AuditTable.table_name == "x"),
    ]
    compiled = [str(stmt.compile(dialect=dialect, compile_kwargs={"literal_binds": True})) for stmt in statements]
    assert all("dbo." in sql or "stg." in sql for sql in compiled)
    assert any("= true" in sql.lower() for sql in compiled)
    assert not any(" is 1" in sql.lower() for sql in compiled)

def test_postgres_ddl_validate_and_migration_cover_orm_contract():
    create_sql = (PG_SQL_DIR / "001_create_tables.sql").read_text(encoding="utf-8").lower()
    validate_sql = (PG_SQL_DIR / "002_validate_schema.sql").read_text(encoding="utf-8").lower()
    migration_sql = (PG_SQL_DIR / "005_split_business_display_and_schemas.sql").read_text(encoding="utf-8").lower()
    assert "create schema if not exists prj_stage" in create_sql
    assert "create schema if not exists prj_dbd" in create_sql
    for table in (
        "prj_dbd.raw_prj_attribute_new_test", "prj_dbd.prj_portfolio_reference",
        "prj_dbd.audit_table_new_test", "prj_stage.prj_attribute_master_new_test",
        "prj_stage.prj_attribute_business_rules_new_test", "prj_stage.prj_attribute_display_test",
        "prj_dbd.prj_attribute_master_new_test", "prj_dbd.prj_attribute_business_rules_new_test",
        "prj_dbd.prj_attribute_display_test",
    ):
        assert table in create_sql
    assert "prj_dbd.prj_data_sources" in validate_sql
    assert "alter table dbo." in migration_sql
    assert "set schema prj_dbd" in migration_sql
    assert "set schema prj_stage" in migration_sql
    assert "examples_for_llm" in create_sql
    assert "business_logic" in create_sql
