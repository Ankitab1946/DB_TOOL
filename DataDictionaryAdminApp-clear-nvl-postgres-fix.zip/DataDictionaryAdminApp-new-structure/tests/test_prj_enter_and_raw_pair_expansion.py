from pathlib import Path

from DataDictionaryAdminApp.api.schemas_api import AttributeUpsert
from DataDictionaryAdminApp.service.data_dictionary_service import DataDictionaryService


def _payload() -> AttributeUpsert:
    return AttributeUpsert(
        prj_id="CFV200",
        portfolio="FI Banks",
        source_abbr_name="SNPAR",
        prj_attribute_name="Paired Raw Test",
        section="Total|liabilities",
        sub_section="current|current2",
        data_type="Amount",
        calculated_or_reported="Reported",
        display_order=1,
    )


def test_ui_pipe_pairs_are_written_as_two_raw_rows_and_two_rule_rows():
    class FakeRepo:
        def __init__(self):
            self.raw_rows = []
            self.rules = []

        def portfolio_ref(self, value):
            return {"label": "FI Banks", "port_ref_id": 1, "portfolio_name": "FI", "sector_name": "Banks"}

        def physical_name_for_prj(self, prj_id):
            return None

        def physical_name_exists(self, name, exclude_prj_id=None):
            return False

        def available_physical_name(self, base_name, exclude_prj_id=None):
            return base_name

        def original_mapping_type(self, prj_id):
            return None

        def source_code(self, source_name, source_abbr_name=None):
            return source_abbr_name or "SNPAR"

        def upsert_raw(self, row, user, source_operation, defer_insert_audit=False, strict_key=False):
            self.raw_rows.append(dict(row))
            return None

        def upsert_staging_master(self, row, user, source_operation):
            return None

        def upsert_staging_rule(self, row, user, source_operation, defer_insert_audit=False, strict_key=False):
            self.rules.append(dict(row))
            return None

        def emit_deferred_insert_audits(self, items):
            return None

    service = DataDictionaryService(db=None)
    repo = FakeRepo()
    service.repo = repo

    result = service.stage_attribute_pending(_payload(), "tester", "UI_CREATE")

    assert result["raw_rows_staged"] == 2
    assert result["business_rule_rows_staged"] == 2
    assert [(row["section"], row["sub_section"]) for row in repo.raw_rows] == [
        ("Total", "current"),
        ("liabilities", "current2"),
    ]
    assert [(row["section"], row["subsection"]) for row in repo.rules] == [
        ("Total", "current"),
        ("liabilities", "current2"),
    ]


def test_raw_repository_upserts_support_strict_pair_keys():
    source = Path("src/DataDictionaryAdminApp/repositories/data_dictionary_repository.py").read_text(encoding="utf-8")
    cached_start = source.index("def upsert_raw_cached")
    normal_start = source.index("def upsert_raw(")
    assert "strict_key: bool = False" in source[cached_start:normal_start]
    assert "strict_key: bool = False" in source[normal_start:source.index("def upsert_staging_master", normal_start)]


def test_prj_id_enter_submits_view_latest_without_button_click():
    source = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
    assert "def request_prj_filter_submit()" in source
    assert 'on_change=request_prj_filter_submit' in source
    assert '"prj_filter_submit_requested": False' in source
    assert 'if st.session_state.get("prj_filter_submit_requested"):' in source
    assert 'api("POST", "/data-dictionary/filter-page", json=payload)' in source
    assert "press Enter to refresh View Latest immediately" in source
