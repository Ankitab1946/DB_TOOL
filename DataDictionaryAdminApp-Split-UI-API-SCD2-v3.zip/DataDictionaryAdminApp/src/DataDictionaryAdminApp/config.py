"""Runtime configuration bootstrap for the Streamlit-only UI.

The UI intentionally owns no database/Vault settings. It only resolves its
runtime context and API endpoint from process env, mounted config files, Helm
values YAML, or local .env fallback.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=None, extra="ignore", case_sensitive=False)

    app_env: str = "DEV"
    selected_environment: str = "DEV"
    selected_db_type: str = "POSTGRES"
    selected_role: str = "ADMIN"
    api_base_url: str = "http://localhost:8503/api/v1"
    api_read_timeout_seconds: int = 120
    api_write_timeout_seconds: int = 600

    def resolve_environment(self) -> str:
        value = (self.selected_environment or self.app_env or "DEV").strip().upper()
        return value if value in {"LOCAL", "DEV", "UAT", "PROD"} else "DEV"


def _scalar(value: Any) -> str | None:
    if value is None or isinstance(value, (dict, list, tuple, set)):
        return None
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _yaml_values(document: Any) -> dict[str, str]:
    if not isinstance(document, dict):
        return {}
    result: dict[str, str] = {}

    # Common Helm pattern: env: {KEY: value}
    env = document.get("env")
    if isinstance(env, dict):
        for key, value in env.items():
            scalar = _scalar(value)
            if scalar is not None:
                result[str(key)] = scalar

    # Flat keys are also supported.
    for key, value in document.items():
        scalar = _scalar(value)
        if scalar is not None:
            result.setdefault(str(key), scalar)

    # Lightweight aliases for nested application/ui blocks.
    for section_name in ("application", "ui", "streamlit"):
        section = document.get(section_name)
        if not isinstance(section, dict):
            continue
        aliases = {
            "environment": "SELECTED_ENVIRONMENT",
            "env": "SELECTED_ENVIRONMENT",
            "dbType": "SELECTED_DB_TYPE",
            "databaseType": "SELECTED_DB_TYPE",
            "role": "SELECTED_ROLE",
            "apiBaseUrl": "API_BASE_URL",
            "api_base_url": "API_BASE_URL",
        }
        for source, target in aliases.items():
            if source in section:
                scalar = _scalar(section[source])
                if scalar is not None:
                    result[target] = scalar
    return result


def _candidate_yaml_files(environment: str) -> list[Path]:
    candidates: list[Path] = []
    for variable in ("APP_CONFIG_FILE", "CONFIG_FILE", "VALUES_FILE", "HELM_VALUES_FILE"):
        raw = os.getenv(variable)
        if raw:
            candidates.append(Path(raw))
    env = environment.lower()
    names = (f"{env}-values.yaml", f"values-{env}.yaml", f"{env}-values.yml", f"values-{env}.yml")
    roots = (Path.cwd(), Path.cwd() / "config", Path.cwd() / "deploy", Path("/config"), Path("/app/config"), Path("/etc/data-dictionary"))
    for root in roots:
        for name in names:
            candidates.append(root / name)
    return candidates


def runtime_config_values(environment: str | None = None) -> tuple[dict[str, str], list[str]]:
    env = (environment or os.getenv("SELECTED_ENVIRONMENT") or os.getenv("APP_ENV") or "DEV").strip().upper()
    values: dict[str, str] = {}
    sources: list[str] = []

    # Lowest priority: local .env fallback.
    dotenv = Path.cwd() / ".env"
    if dotenv.is_file():
        for line in dotenv.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip().strip('"').strip("'")
        sources.append(str(dotenv))

    # YAML overrides .env.
    for path in _candidate_yaml_files(env):
        if not path.is_file():
            continue
        try:
            loaded = yaml.safe_load(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        values.update(_yaml_values(loaded))
        sources.append(str(path))
        if os.getenv("APP_CONFIG_FILE"):
            break

    # Mounted one-value-per-file config overrides YAML.
    dirs: list[Path] = []
    for variable in ("APP_CONFIG_DIR", "CONFIG_DIR", "K8S_CONFIG_DIR"):
        raw = os.getenv(variable)
        if raw:
            dirs.append(Path(raw))
    dirs.extend((Path("/config"), Path("/etc/data-dictionary/config"), Path("/app/config")))
    for directory in dirs:
        if not directory.is_dir():
            continue
        found = False
        for child in directory.iterdir():
            if child.is_file() and child.name not in {"..data"} and not child.name.startswith(".."):
                try:
                    values[child.name] = child.read_text(encoding="utf-8").strip()
                    found = True
                except Exception:
                    pass
        if found:
            sources.append(str(directory))
            break

    # Process env is intentionally applied by bootstrap_runtime_config below as
    # the highest-priority source (existing env values are never overwritten).
    return values, sources


def bootstrap_runtime_config(environment: str | None = None) -> list[str]:
    values, sources = runtime_config_values(environment)
    for key, value in values.items():
        os.environ.setdefault(str(key), str(value))
    os.environ.setdefault("SELECTED_ENVIRONMENT", "DEV")
    os.environ.setdefault("APP_ENV", os.environ.get("SELECTED_ENVIRONMENT", "DEV"))
    os.environ.setdefault("SELECTED_DB_TYPE", "POSTGRES")
    os.environ.setdefault("SELECTED_ROLE", "ADMIN")
    os.environ.setdefault("API_BASE_URL", "http://localhost:8503/api/v1")
    return sources
