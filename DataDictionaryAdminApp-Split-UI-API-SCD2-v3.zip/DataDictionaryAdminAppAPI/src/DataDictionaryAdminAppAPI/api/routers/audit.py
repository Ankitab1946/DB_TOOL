from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from DataDictionaryAdminAppAPI.api.schemas_api import AuditFilterRequest
from DataDictionaryAdminAppAPI.core.database import get_db
from DataDictionaryAdminAppAPI.repositories.data_dictionary_repository import DataDictionaryRepository

router = APIRouter(prefix="/audit", tags=["Audit"])

@router.post("/filter")
def filter_audit(payload: AuditFilterRequest, db: Session = Depends(get_db)):
    return DataDictionaryRepository(db).audit_rows(payload)

@router.get("")
def list_audit(db: Session = Depends(get_db)):
    return DataDictionaryRepository(db).audit_rows(AuditFilterRequest())


@router.get("/scd2-history")
def scd2_history(
    schema_name: str | None = None,
    table_name: str | None = None,
    record_key: str | None = None,
    current_only: bool = False,
    limit: int = 2000,
    db: Session = Depends(get_db),
):
    """Return effective-dated row versions without changing existing audit APIs."""
    return DataDictionaryRepository(db).scd2_history(
        schema_name=schema_name, table_name=table_name, record_key=record_key,
        current_only=current_only, limit=limit,
    )
