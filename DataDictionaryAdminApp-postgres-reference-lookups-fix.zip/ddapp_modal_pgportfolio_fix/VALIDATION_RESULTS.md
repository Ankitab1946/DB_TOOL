# Validation Results

Latest fix: PostgreSQL Portfolio/Scope and Source reference lookup alignment.

- PostgreSQL Portfolio/Scope reads directly from `prj_dbd.prj_portfolio_reference`.
- PostgreSQL Source reads directly from `prj_dbd.prj_data_sources`.
- PostgreSQL reference rows are not hidden by legacy `is_active` values.
- PostgreSQL UI refreshes Portfolio and Source independently from the combined lookup endpoint.
- SQL Server lookup behavior remains unchanged.
- No database migration or DDL change is required.
- Python compileall: PASS
- FastAPI/OpenAPI import: PASS
- OpenAPI paths: 29
- Full pytest regression suite: PASS
