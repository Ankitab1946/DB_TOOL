"""SQLAlchemy entities shared by the SQL Server and PostgreSQL physical schemas."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import BigInteger, Boolean, DateTime, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from DataDictionaryAdminApp.core.database import Base


class AuditColumns:
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=datetime.utcnow)
    created_by: Mapped[str] = mapped_column(String(128), nullable=False, default="sysuser")
    updated_by: Mapped[str] = mapped_column(String(128), nullable=False, default="sysuser")


class RawAttribute(Base, AuditColumns):
    __tablename__ = "raw_prj_attribute_new_test"
    __table_args__ = {"schema": "dbo"}
    raw_row_id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    portfolio: Mapped[str] = mapped_column(String(120), nullable=False)
    prj_id: Mapped[str] = mapped_column(String(80), nullable=False)
    prj_attribute_name: Mapped[str] = mapped_column(String(500), nullable=False)
    prj_physical_attribute_name: Mapped[str] = mapped_column(String(500), nullable=False)
    section: Mapped[str] = mapped_column(String(255), nullable=False)
    sub_section: Mapped[str] = mapped_column(String(255), nullable=False)
    data_type: Mapped[str | None] = mapped_column(String(100))
    calculated_or_reported: Mapped[str] = mapped_column(String(50), nullable=False)
    calculation_logic: Mapped[str] = mapped_column(Text, nullable=False, default="NA")
    segment: Mapped[str] = mapped_column(String(255), nullable=False, default="NA")
    attribute_definition: Mapped[str | None] = mapped_column(Text)
    attribute_description: Mapped[str | None] = mapped_column(Text)
    display_order: Mapped[int] = mapped_column(Integer, nullable=False)
    tech_logic: Mapped[str | None] = mapped_column(Text)
    display_name: Mapped[str | None] = mapped_column(String(500))


class PortfolioReference(Base, AuditColumns):
    __tablename__ = "prj_portfolio_reference_new_test"
    __table_args__ = (
        UniqueConstraint("portfolio_name", "sector_name", "sub_sector", name="uq_new_portfolio_reference"),
        {"schema": "dbo"},
    )
    port_ref_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    portfolio_name: Mapped[str] = mapped_column(String(120), nullable=False)
    sector_name: Mapped[str] = mapped_column(String(120), nullable=False)
    sub_sector: Mapped[str | None] = mapped_column(String(120))
    remark: Mapped[str | None] = mapped_column(String(500))


class StagingAttributeMaster(Base, AuditColumns):
    __tablename__ = "prj_attribute_master_new_test"
    __table_args__ = {"schema": "stg"}
    prj_id: Mapped[str] = mapped_column(String(80), primary_key=True)
    prj_attribute_name: Mapped[str] = mapped_column(String(500), nullable=False)
    prj_attribute_definition: Mapped[str | None] = mapped_column(Text)
    prj_physical_attribute_name: Mapped[str] = mapped_column(String(500), nullable=False, unique=True)
    where_in_financial_statement: Mapped[str] = mapped_column(String(255), nullable=False, default="NA")


class StagingBusinessRule(Base, AuditColumns):
    __tablename__ = "prj_attribute_business_rules_new_test"
    __table_args__ = (
        UniqueConstraint(
            "prj_id", "port_ref_id", "source_abbr_name", "display_order", "section", "subsection",
            name="uq_stg_new_business_rule_key",
        ),
        {"schema": "stg"},
    )
    scope_id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    prj_id: Mapped[str] = mapped_column(String(80), nullable=False)
    port_ref_id: Mapped[int] = mapped_column(Integer, nullable=False)
    source_abbr_name: Mapped[str] = mapped_column(String(50), nullable=False, default="SNPAR")
    editable: Mapped[str] = mapped_column(String(1), nullable=False)
    symbol: Mapped[str | None] = mapped_column(String(50))
    mapping_type: Mapped[str] = mapped_column(String(50), nullable=False)
    calculation_logic: Mapped[str] = mapped_column(Text, nullable=False, default="NA")
    prj_attribute_description: Mapped[str | None] = mapped_column(Text)
    tech_logic: Mapped[str | None] = mapped_column(Text)
    display_order: Mapped[int] = mapped_column(Integer, nullable=False)
    display_name: Mapped[str | None] = mapped_column(String(500))
    section: Mapped[str] = mapped_column(String(255), nullable=False)
    subsection: Mapped[str] = mapped_column(String(255), nullable=False)
    prompt_description: Mapped[str | None] = mapped_column(Text)
    examples: Mapped[str | None] = mapped_column(Text)


class AttributeMaster(Base, AuditColumns):
    __tablename__ = "prj_attribute_master_new_test"
    __table_args__ = {"schema": "dbo"}
    prj_id: Mapped[str] = mapped_column(String(80), primary_key=True)
    prj_attribute_name: Mapped[str] = mapped_column(String(500), nullable=False)
    prj_attribute_definition: Mapped[str | None] = mapped_column(Text)
    prj_physical_attribute_name: Mapped[str] = mapped_column(String(500), nullable=False, unique=True)
    where_in_financial_statement: Mapped[str] = mapped_column(String(255), nullable=False, default="NA")


class AttributeBusinessRule(Base, AuditColumns):
    __tablename__ = "prj_attribute_business_rules_new_test"
    __table_args__ = (
        UniqueConstraint(
            "prj_id", "port_ref_id", "source_abbr_name", "display_order", "section", "subsection",
            name="uq_new_business_rule_key",
        ),
        {"schema": "dbo"},
    )
    scope_id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    prj_id: Mapped[str] = mapped_column(String(80), nullable=False)
    port_ref_id: Mapped[int] = mapped_column(Integer, nullable=False)
    source_abbr_name: Mapped[str] = mapped_column(String(50), nullable=False, default="SNPAR")
    editable: Mapped[str] = mapped_column(String(1), nullable=False)
    symbol: Mapped[str | None] = mapped_column(String(50))
    mapping_type: Mapped[str] = mapped_column(String(50), nullable=False)
    calculation_logic: Mapped[str] = mapped_column(Text, nullable=False, default="NA")
    prj_attribute_description: Mapped[str | None] = mapped_column(Text)
    tech_logic: Mapped[str | None] = mapped_column(Text)
    display_order: Mapped[int] = mapped_column(Integer, nullable=False)
    display_name: Mapped[str | None] = mapped_column(String(500))
    section: Mapped[str] = mapped_column(String(255), nullable=False)
    subsection: Mapped[str] = mapped_column(String(255), nullable=False)
    prompt_description: Mapped[str | None] = mapped_column(Text)
    examples: Mapped[str | None] = mapped_column(Text)


class AuditTable(Base):
    __tablename__ = "audit_table_new_test"
    __table_args__ = {"schema": "dbo"}
    audit_id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    schema_name: Mapped[str] = mapped_column(String(128), nullable=False)
    table_name: Mapped[str] = mapped_column(String(255), nullable=False)
    record_key: Mapped[str] = mapped_column(String(500), nullable=False)
    action: Mapped[str] = mapped_column(String(50), nullable=False)
    before_value: Mapped[str | None] = mapped_column(Text)
    after_value: Mapped[str | None] = mapped_column(Text)
    source_operation: Mapped[str | None] = mapped_column(String(100))
    performed_by: Mapped[str] = mapped_column(String(128), nullable=False)
    performed_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=datetime.utcnow)
