/* Informational preflight: lists old application tables if they are still present. */
SELECT table_schema, table_name
FROM information_schema.tables
WHERE table_type = 'BASE TABLE'
  AND table_schema IN ('dbo', 'stg')
  AND table_name IN (
      'prj_attribute_master_test',
      'prj_portfolio_reference_test',
      'prj_attribute_portfolio_scope_test',
      'prj_attribute_business_rules_test',
      'prj_scanning_prompt_reference_test',
      'audit_table_test'
  )
ORDER BY table_schema, table_name;
