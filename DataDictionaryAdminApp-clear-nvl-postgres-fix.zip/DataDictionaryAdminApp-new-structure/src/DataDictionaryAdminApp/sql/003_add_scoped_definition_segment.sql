/* Existing SQL Server databases: add per-scope Attribute Definition and Segment. */
SET XACT_ABORT ON;
BEGIN TRY
    BEGIN TRANSACTION;

    IF COL_LENGTH('stg.prj_attribute_business_rules_new_test', 'prj_attribute_definition') IS NULL
        ALTER TABLE stg.prj_attribute_business_rules_new_test ADD prj_attribute_definition nvarchar(max) NULL;

    IF COL_LENGTH('stg.prj_attribute_business_rules_new_test', 'segment') IS NULL
        ALTER TABLE stg.prj_attribute_business_rules_new_test
            ADD segment nvarchar(255) NOT NULL CONSTRAINT DF_stg_rules_new_segment DEFAULT(N'NA');

    IF COL_LENGTH('dbo.prj_attribute_business_rules_new_test', 'prj_attribute_definition') IS NULL
        ALTER TABLE dbo.prj_attribute_business_rules_new_test ADD prj_attribute_definition nvarchar(max) NULL;

    IF COL_LENGTH('dbo.prj_attribute_business_rules_new_test', 'segment') IS NULL
        ALTER TABLE dbo.prj_attribute_business_rules_new_test
            ADD segment nvarchar(255) NOT NULL CONSTRAINT DF_rules_new_segment DEFAULT(N'NA');

    /* Backfill scope fields from the existing master rows for backwards compatibility. */
    UPDATE r
       SET r.prj_attribute_definition = COALESCE(r.prj_attribute_definition, m.prj_attribute_definition),
           r.segment = CASE WHEN r.segment IS NULL OR LTRIM(RTRIM(r.segment)) = '' OR r.segment = 'NA'
                            THEN COALESCE(m.where_in_financial_statement, N'NA') ELSE r.segment END
      FROM stg.prj_attribute_business_rules_new_test r
      JOIN stg.prj_attribute_master_new_test m ON m.prj_id = r.prj_id;

    UPDATE r
       SET r.prj_attribute_definition = COALESCE(r.prj_attribute_definition, m.prj_attribute_definition),
           r.segment = CASE WHEN r.segment IS NULL OR LTRIM(RTRIM(r.segment)) = '' OR r.segment = 'NA'
                            THEN COALESCE(m.where_in_financial_statement, N'NA') ELSE r.segment END
      FROM dbo.prj_attribute_business_rules_new_test r
      JOIN dbo.prj_attribute_master_new_test m ON m.prj_id = r.prj_id;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
