/* PostgreSQL deployment preflight. Raises an exception on any missing object/column. */
DO $$
DECLARE
    item text;
    required text[][] := ARRAY[
        ARRAY['dbo','raw_prj_attribute_new_test','raw_row_id'],
        ARRAY['dbo','raw_prj_attribute_new_test','portfolio'],
        ARRAY['dbo','raw_prj_attribute_new_test','prj_id'],
        ARRAY['dbo','raw_prj_attribute_new_test','prj_attribute_name'],
        ARRAY['dbo','raw_prj_attribute_new_test','prj_physical_attribute_name'],
        ARRAY['dbo','raw_prj_attribute_new_test','section'],
        ARRAY['dbo','raw_prj_attribute_new_test','sub_section'],
        ARRAY['dbo','raw_prj_attribute_new_test','data_type'],
        ARRAY['dbo','raw_prj_attribute_new_test','calculated_or_reported'],
        ARRAY['dbo','raw_prj_attribute_new_test','calculation_logic'],
        ARRAY['dbo','raw_prj_attribute_new_test','segment'],
        ARRAY['dbo','raw_prj_attribute_new_test','attribute_definition'],
        ARRAY['dbo','raw_prj_attribute_new_test','attribute_description'],
        ARRAY['dbo','raw_prj_attribute_new_test','display_order'],
        ARRAY['dbo','raw_prj_attribute_new_test','tech_logic'],
        ARRAY['dbo','raw_prj_attribute_new_test','display_name'],
        ARRAY['dbo','raw_prj_attribute_new_test','is_active'],
        ARRAY['dbo','raw_prj_attribute_new_test','created_at'],
        ARRAY['dbo','raw_prj_attribute_new_test','updated_at'],
        ARRAY['dbo','raw_prj_attribute_new_test','created_by'],
        ARRAY['dbo','raw_prj_attribute_new_test','updated_by'],
        ARRAY['dbo','prj_portfolio_reference_new_test','port_ref_id'],
        ARRAY['dbo','prj_portfolio_reference_new_test','portfolio_name'],
        ARRAY['dbo','prj_portfolio_reference_new_test','sector_name'],
        ARRAY['dbo','prj_portfolio_reference_new_test','sub_sector'],
        ARRAY['dbo','prj_portfolio_reference_new_test','remark'],
        ARRAY['dbo','prj_portfolio_reference_new_test','is_active'],
        ARRAY['dbo','prj_portfolio_reference_new_test','created_at'],
        ARRAY['dbo','prj_portfolio_reference_new_test','updated_at'],
        ARRAY['dbo','prj_portfolio_reference_new_test','created_by'],
        ARRAY['dbo','prj_portfolio_reference_new_test','updated_by'],
        ARRAY['dbo','audit_table_new_test','audit_id'],
        ARRAY['dbo','audit_table_new_test','schema_name'],
        ARRAY['dbo','audit_table_new_test','table_name'],
        ARRAY['dbo','audit_table_new_test','record_key'],
        ARRAY['dbo','audit_table_new_test','action'],
        ARRAY['dbo','audit_table_new_test','before_value'],
        ARRAY['dbo','audit_table_new_test','after_value'],
        ARRAY['dbo','audit_table_new_test','source_operation'],
        ARRAY['dbo','audit_table_new_test','performed_by'],
        ARRAY['dbo','audit_table_new_test','performed_at'],
        ARRAY['stg','prj_attribute_master_new_test','prj_id'],
        ARRAY['stg','prj_attribute_master_new_test','prj_attribute_name'],
        ARRAY['stg','prj_attribute_master_new_test','prj_attribute_definition'],
        ARRAY['stg','prj_attribute_master_new_test','prj_physical_attribute_name'],
        ARRAY['stg','prj_attribute_master_new_test','where_in_financial_statement'],
        ARRAY['stg','prj_attribute_master_new_test','is_active'],
        ARRAY['stg','prj_attribute_master_new_test','created_at'],
        ARRAY['stg','prj_attribute_master_new_test','updated_at'],
        ARRAY['stg','prj_attribute_master_new_test','created_by'],
        ARRAY['stg','prj_attribute_master_new_test','updated_by'],
        ARRAY['stg','prj_attribute_business_rules_new_test','scope_id'],
        ARRAY['stg','prj_attribute_business_rules_new_test','prj_id'],
        ARRAY['stg','prj_attribute_business_rules_new_test','port_ref_id'],
        ARRAY['stg','prj_attribute_business_rules_new_test','source_abbr_name'],
        ARRAY['stg','prj_attribute_business_rules_new_test','editable'],
        ARRAY['stg','prj_attribute_business_rules_new_test','symbol'],
        ARRAY['stg','prj_attribute_business_rules_new_test','mapping_type'],
        ARRAY['stg','prj_attribute_business_rules_new_test','calculation_logic'],
        ARRAY['stg','prj_attribute_business_rules_new_test','prj_attribute_definition'],
        ARRAY['stg','prj_attribute_business_rules_new_test','prj_attribute_description'],
        ARRAY['stg','prj_attribute_business_rules_new_test','segment'],
        ARRAY['stg','prj_attribute_business_rules_new_test','tech_logic'],
        ARRAY['stg','prj_attribute_business_rules_new_test','display_order'],
        ARRAY['stg','prj_attribute_business_rules_new_test','display_name'],
        ARRAY['stg','prj_attribute_business_rules_new_test','section'],
        ARRAY['stg','prj_attribute_business_rules_new_test','subsection'],
        ARRAY['stg','prj_attribute_business_rules_new_test','prompt_description'],
        ARRAY['stg','prj_attribute_business_rules_new_test','examples'],
        ARRAY['stg','prj_attribute_business_rules_new_test','is_active'],
        ARRAY['stg','prj_attribute_business_rules_new_test','created_at'],
        ARRAY['stg','prj_attribute_business_rules_new_test','updated_at'],
        ARRAY['stg','prj_attribute_business_rules_new_test','created_by'],
        ARRAY['stg','prj_attribute_business_rules_new_test','updated_by'],
        ARRAY['dbo','prj_attribute_master_new_test','prj_id'],
        ARRAY['dbo','prj_attribute_master_new_test','prj_attribute_name'],
        ARRAY['dbo','prj_attribute_master_new_test','prj_attribute_definition'],
        ARRAY['dbo','prj_attribute_master_new_test','prj_physical_attribute_name'],
        ARRAY['dbo','prj_attribute_master_new_test','where_in_financial_statement'],
        ARRAY['dbo','prj_attribute_master_new_test','is_active'],
        ARRAY['dbo','prj_attribute_master_new_test','created_at'],
        ARRAY['dbo','prj_attribute_master_new_test','updated_at'],
        ARRAY['dbo','prj_attribute_master_new_test','created_by'],
        ARRAY['dbo','prj_attribute_master_new_test','updated_by'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','scope_id'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','prj_id'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','port_ref_id'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','source_abbr_name'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','editable'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','symbol'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','mapping_type'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','calculation_logic'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','prj_attribute_definition'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','prj_attribute_description'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','segment'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','tech_logic'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','display_order'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','display_name'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','section'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','subsection'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','prompt_description'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','examples'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','is_active'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','created_at'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','updated_at'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','created_by'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','updated_by']
    ];
    rec text[];
BEGIN
    IF to_regnamespace('stg') IS NULL THEN
        RAISE EXCEPTION 'Schema validation failed: schema stg is missing.';
    END IF;

    FOREACH rec SLICE 1 IN ARRAY required LOOP
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns c
            WHERE c.table_schema = rec[1] AND c.table_name = rec[2] AND c.column_name = rec[3]
        ) THEN
            item := rec[1] || '.' || rec[2] || '.' || rec[3];
            RAISE EXCEPTION 'Schema validation failed: % is missing.', item;
        END IF;
    END LOOP;

    IF to_regclass('dbo.prj_data_sources') IS NULL AND to_regclass('dbo.prj_data_source') IS NULL THEN
        RAISE EXCEPTION 'Schema validation failed: read-only dependency dbo.prj_data_sources (or singular dbo.prj_data_source) is missing.';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'dbo'
          AND table_name IN ('prj_data_sources', 'prj_data_source')
          AND column_name = 'source_code'
    ) THEN
        RAISE EXCEPTION 'Schema validation failed: read-only data source table is missing source_code.';
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = 'dbo'
          AND table_name IN ('prj_data_sources', 'prj_data_source')
          AND column_name = 'source_name'
    ) THEN
        RAISE EXCEPTION 'Schema validation failed: read-only data source table is missing source_name.';
    END IF;
END $$;

SELECT 'Schema validation passed' AS validation_result;
