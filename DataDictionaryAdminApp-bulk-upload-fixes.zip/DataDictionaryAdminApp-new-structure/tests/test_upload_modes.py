import pytest
from fastapi import HTTPException

from DataDictionaryAdminApp.api.routers.master_upload import _mode


def test_supported_upload_modes():
    assert _mode("merge") == "MERGE"
    assert _mode("insert_only") == "INSERT_ONLY"
    assert _mode("replace") == "REPLACE"


def test_unknown_upload_mode_is_rejected():
    with pytest.raises(HTTPException) as exc:
        _mode("update_all")
    assert exc.value.status_code == 422
