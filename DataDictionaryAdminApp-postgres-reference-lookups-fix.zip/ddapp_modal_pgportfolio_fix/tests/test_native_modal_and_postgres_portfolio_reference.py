from pathlib import Path

from sqlalchemy import select
from sqlalchemy.dialects import postgresql

from DataDictionaryAdminApp.model.entities import PortfolioReference, PostgresPortfolioReference
from DataDictionaryAdminApp.repositories.data_dictionary_repository import DataDictionaryRepository

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / "src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
PG_CREATE = (ROOT / "src/DataDictionaryAdminApp/sql/postgres/001_create_tables.sql").read_text(encoding="utf-8").lower()
PG_VALIDATE = (ROOT / "src/DataDictionaryAdminApp/sql/postgres/002_validate_schema.sql").read_text(encoding="utf-8").lower()
PG_MIGRATE = (ROOT / "src/DataDictionaryAdminApp/sql/postgres/005_split_business_display_and_schemas.sql").read_text(encoding="utf-8").lower()
PG_ALIGN = (ROOT / "src/DataDictionaryAdminApp/sql/postgres/006_align_portfolio_reference.sql").read_text(encoding="utf-8").lower()


def test_native_create_edit_dialogs_are_responsive_and_not_positioned_left_bottom():
    assert '@st.dialog("Create New Attribute", width="large")' in APP
    assert '@st.dialog("Edit Attribute", width="large")' in APP
    assert 'width: min(96vw, 1600px) !important;' in APP
    assert 'margin: auto !important;' in APP
    assert 'top: 50%' not in APP
    assert 'translateY(' not in APP


def test_postgres_portfolio_model_compiles_to_exact_required_table():
    sql = str(select(PostgresPortfolioReference).compile(dialect=postgresql.dialect()))
    assert "prj_dbd.prj_portfolio_reference" in sql
    assert "prj_portfolio_reference_new_test" not in sql


def test_sqlserver_portfolio_model_remains_old_table_name():
    assert PortfolioReference.__table__.schema == "dbo"
    assert PortfolioReference.__table__.name == "prj_portfolio_reference_new_test"


def test_repository_selects_postgres_portfolio_model_by_engine():
    class Dialect:
        name = "postgresql"
    class Bind:
        dialect = Dialect()
    class DB:
        @staticmethod
        def get_bind():
            return Bind()
    repo = DataDictionaryRepository(DB())
    assert repo.portfolio_model() is PostgresPortfolioReference
    assert repo.portfolio_table_name() == "prj_dbd.prj_portfolio_reference"


def test_postgres_sql_contract_uses_canonical_portfolio_reference_name():
    assert "prj_dbd.prj_portfolio_reference" in PG_CREATE
    assert "('prj_dbd','prj_portfolio_reference','port_ref_id')" in PG_VALIDATE
    assert "references prj_dbd.prj_portfolio_reference(port_ref_id)" in PG_MIGRATE
    assert "rename to prj_portfolio_reference" in PG_MIGRATE
    assert "references prj_dbd.prj_portfolio_reference(port_ref_id)" in PG_ALIGN
    assert "drop constraint" in PG_ALIGN
