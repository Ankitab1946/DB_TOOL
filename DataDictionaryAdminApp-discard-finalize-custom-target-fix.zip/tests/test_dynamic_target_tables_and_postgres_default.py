from pathlib import Path

import pytest

from DataDictionaryAdminApp.config import Settings
from DataDictionaryAdminApp.core.database import _rewrite_qualified_table
from DataDictionaryAdminApp.core.target_tables import (
    TARGET_TABLE_DEFAULTS,
    TARGET_TABLE_HEADERS,
    build_table_rewrites,
    target_table_names_from_headers,
    validate_table_name,
    validate_target_table_set,
)

ROOT = Path(__file__).resolve().parents[1]
UI = (ROOT / "src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
DB = (ROOT / "src/DataDictionaryAdminApp/core/database.py").read_text(encoding="utf-8")
SERVICE = (ROOT / "src/DataDictionaryAdminApp/service/data_dictionary_service.py").read_text(encoding="utf-8")
ENV_EXAMPLE = (ROOT / ".env.example").read_text(encoding="utf-8")


def test_postgres_is_default_database_on_page_load():
    assert Settings(_env_file=None).selected_db_type == "POSTGRES"
    assert '"database_type": "POSTGRES"' in UI
    assert 'SELECTED_DB_TYPE=POSTGRES' in ENV_EXAMPLE


def test_sidebar_exposes_six_staging_and_final_target_table_inputs():
    assert 'with st.expander("Target Tables", expanded=True):' in UI
    assert '"stg_master", "stg_business", "stg_display"' in UI
    assert '"final_master", "final_business", "final_display"' in UI
    assert 'Apply Table Names' in UI
    for header in TARGET_TABLE_HEADERS.values():
        assert header in str(TARGET_TABLE_HEADERS.values()) or header in UI


def test_request_headers_resolve_and_validate_target_table_names():
    headers = {
        TARGET_TABLE_HEADERS["stg_master"]: "prj_attribute_master",
        TARGET_TABLE_HEADERS["final_master"]: "prj_attribute_master",
    }
    resolved = target_table_names_from_headers(headers)
    assert resolved["stg_master"] == "prj_attribute_master"
    assert resolved["final_master"] == "prj_attribute_master"
    assert resolved["stg_business"] == TARGET_TABLE_DEFAULTS["stg_business"]
    with pytest.raises(ValueError):
        validate_table_name("bad-name;drop")
    collision = dict(TARGET_TABLE_DEFAULTS)
    collision["stg_business"] = collision["stg_master"]
    with pytest.raises(ValueError, match="Staging Attribute Master"):
        validate_target_table_set(collision)


def test_sqlserver_rewrite_changes_staging_and_final_independently():
    names = dict(TARGET_TABLE_DEFAULTS)
    names["stg_master"] = "prj_attribute_master_stg"
    names["final_master"] = "prj_attribute_master"
    rewrites = build_table_rewrites("SQLSERVER", "prj_dbd", names)
    assert ("stg", "prj_attribute_master_new_test", "prj_attribute_master_stg") in rewrites
    assert ("dbo", "prj_attribute_master_new_test", "prj_attribute_master") in rewrites
    sql = "SELECT * FROM [stg].[prj_attribute_master_new_test]; SELECT * FROM [dbo].[prj_attribute_master_new_test]"
    for schema, old, new in rewrites:
        sql = _rewrite_qualified_table(sql, schema, old, new)
    assert "[stg].[prj_attribute_master_stg]" in sql
    assert "[dbo].[prj_attribute_master]" in sql


def test_postgres_rewrite_uses_prj_stage_and_configured_main_schema():
    names = dict(TARGET_TABLE_DEFAULTS)
    names.update({
        "stg_business": "prj_attribute_business_rules",
        "final_business": "prj_attribute_business_rules",
    })
    rewrites = build_table_rewrites("POSTGRES", "custom_main", names)
    sql = (
        "SELECT * FROM prj_stage.prj_attribute_business_rules_new_test; "
        "SELECT * FROM custom_main.prj_attribute_business_rules_new_test"
    )
    for schema, old, new in rewrites:
        sql = _rewrite_qualified_table(sql, schema, old, new)
    assert "prj_stage.prj_attribute_business_rules" in sql
    assert "custom_main.prj_attribute_business_rules" in sql


def test_api_session_carries_target_rewrites_across_request_transactions():
    assert 'target_names = target_table_names_from_headers(request.headers)' in DB
    assert 'request_bind = base_bind.execution_options(target_table_rewrites=rewrites)' in DB
    assert 'db.info["target_table_names"] = target_names' in DB


def test_postgres_finalize_reflects_selected_target_names_not_fixed_new_test_names():
    block = SERVICE[SERVICE.index("    def _postgres_finalize_tables"):SERVICE.index("    def _postgres_audit")]
    assert 'self.repo.target_table_name("stg_master")' in block
    assert 'self.repo.target_table_name("stg_business")' in block
    assert 'self.repo.target_table_name("stg_display")' in block
    assert 'self.repo.target_table_name("final_master")' in block
    assert 'self.repo.target_table_name("final_business")' in block
    assert 'self.repo.target_table_name("final_display")' in block


def test_orm_query_is_redirected_to_selected_physical_table_name():
    from sqlalchemy import create_engine, select, text
    from sqlalchemy.orm import Session

    # Importing core.database registers the before_cursor_execute rewrite listener.
    from DataDictionaryAdminApp.model.entities import StagingAttributeMaster

    engine = create_engine("sqlite+pysqlite:///:memory:", future=True)
    with engine.begin() as connection:
        connection.exec_driver_sql("ATTACH DATABASE ':memory:' AS stg")
        connection.exec_driver_sql("""
            CREATE TABLE stg.prj_attribute_master (
                prj_id TEXT PRIMARY KEY,
                prj_attribute_name TEXT NOT NULL,
                prj_attribute_definition TEXT,
                prj_physical_attribute_name TEXT NOT NULL,
                segment TEXT NOT NULL,
                is_active BOOLEAN NOT NULL,
                created_at DATETIME,
                updated_at DATETIME,
                created_by TEXT,
                updated_by TEXT
            )
        """)
        connection.exec_driver_sql("""
            INSERT INTO stg.prj_attribute_master
            (prj_id, prj_attribute_name, prj_physical_attribute_name, segment, is_active)
            VALUES ('PRJ1', 'Revenue', 'revenue', 'Income', 1)
        """)

    routed = engine.execution_options(
        target_table_rewrites=(("stg", "prj_attribute_master_new_test", "prj_attribute_master"),)
    )
    with Session(routed) as session:
        assert session.scalars(select(StagingAttributeMaster.prj_id)).all() == ["PRJ1"]


def test_postgres_finalize_uses_selected_custom_staging_and_final_names():
    from sqlalchemy import create_engine, text
    from sqlalchemy.orm import Session
    from DataDictionaryAdminApp.service.data_dictionary_service import DataDictionaryService

    engine = create_engine("sqlite+pysqlite:///:memory:", future=True)
    with Session(engine) as session:
        session.execute(text("ATTACH DATABASE ':memory:' AS prj_stage"))
        session.execute(text("ATTACH DATABASE ':memory:' AS prj_dbd"))
        session.execute(text("CREATE TABLE prj_dbd.prj_portfolio_reference (port_ref_id INTEGER PRIMARY KEY, portfolio_name TEXT, sector_name TEXT)"))
        session.execute(text("INSERT INTO prj_dbd.prj_portfolio_reference VALUES (10, 'FI', 'Banks')"))
        names = {
            "stg_master": "prj_attribute_master_stg",
            "stg_business": "prj_attribute_business_rules_stg",
            "stg_display": "prj_attribute_display_stg",
            "final_master": "prj_attribute_master",
            "final_business": "prj_attribute_business_rules",
            "final_display": "prj_attribute_display",
        }
        for schema, suffix in (("prj_stage", "stg"), ("prj_dbd", "final")):
            master = names["stg_master" if suffix == "stg" else "final_master"]
            business = names["stg_business" if suffix == "stg" else "final_business"]
            display = names["stg_display" if suffix == "stg" else "final_display"]
            session.execute(text(f"""
                CREATE TABLE {schema}.{master} (
                    prj_id TEXT PRIMARY KEY, prj_attribute_name TEXT NOT NULL,
                    prj_attribute_definition TEXT, prj_physical_attribute_name TEXT NOT NULL UNIQUE,
                    segment TEXT NOT NULL, is_active BOOLEAN NOT NULL,
                    created_at DATETIME, updated_at DATETIME, created_by TEXT, updated_by TEXT)
            """))
            session.execute(text(f"""
                CREATE TABLE {schema}.{business} (
                    scope_id INTEGER PRIMARY KEY AUTOINCREMENT, prj_id TEXT NOT NULL,
                    port_ref_id INTEGER NOT NULL, source_abbr_name TEXT NOT NULL,
                    prompt_description TEXT, examples_for_llm TEXT, editable TEXT NOT NULL,
                    data_type TEXT, attribute_type TEXT NOT NULL, business_logic TEXT,
                    calculation_logic TEXT NOT NULL, created_at DATETIME, updated_at DATETIME,
                    created_by TEXT, updated_by TEXT)
            """))
            session.execute(text(f"""
                CREATE TABLE {schema}.{display} (
                    display_id INTEGER PRIMARY KEY AUTOINCREMENT, scope_id INTEGER NOT NULL UNIQUE,
                    display_order INTEGER NOT NULL, prj_id TEXT NOT NULL, display_name TEXT,
                    section TEXT NOT NULL, subsection TEXT NOT NULL, prj_attribute_definition TEXT,
                    prj_attribute_description TEXT, segment TEXT NOT NULL, report_type TEXT NOT NULL,
                    created_at DATETIME, updated_at DATETIME, created_by TEXT, updated_by TEXT)
            """))
        session.execute(text("""
            CREATE TABLE prj_dbd.audit_table_new_test (
                audit_id INTEGER PRIMARY KEY AUTOINCREMENT, schema_name TEXT NOT NULL,
                table_name TEXT NOT NULL, record_key TEXT NOT NULL, action TEXT NOT NULL,
                before_value TEXT, after_value TEXT, source_operation TEXT,
                performed_by TEXT NOT NULL, performed_at DATETIME NOT NULL)
        """))
        session.execute(text("""
            INSERT INTO prj_stage.prj_attribute_master_stg
            (prj_id,prj_attribute_name,prj_physical_attribute_name,segment,is_active)
            VALUES ('PRJ77','Revenue','revenue','Income',1)
        """))
        session.execute(text("""
            INSERT INTO prj_stage.prj_attribute_business_rules_stg
            (prj_id,port_ref_id,source_abbr_name,editable,attribute_type,calculation_logic)
            VALUES ('PRJ77',10,'SRC','Y','Reported','NA')
        """))
        scope_id = session.execute(text("SELECT scope_id FROM prj_stage.prj_attribute_business_rules_stg")).scalar_one()
        session.execute(text("""
            INSERT INTO prj_stage.prj_attribute_display_stg
            (scope_id,display_order,prj_id,section,subsection,segment,report_type)
            VALUES (:scope_id,1,'PRJ77','Income','Total','NA','Annual')
        """), {"scope_id": scope_id})
        session.commit()
        session.info["target_table_names"] = names
        session.info["pg_schema"] = "prj_dbd"
        session.info["staging_schema"] = "prj_stage"

        result = DataDictionaryService(session)._finalize_postgres(
            "tester", {"has_changes": True, "rows": [{"prj_id": "PRJ77"}]}
        )
        assert result["updated"] == 1
        assert session.execute(text("SELECT count(*) FROM prj_dbd.prj_attribute_master WHERE prj_id='PRJ77'")).scalar_one() == 1
        assert session.execute(text("SELECT count(*) FROM prj_dbd.prj_attribute_business_rules WHERE prj_id='PRJ77'")).scalar_one() == 1
        assert session.execute(text("SELECT count(*) FROM prj_dbd.prj_attribute_display WHERE prj_id='PRJ77'")).scalar_one() == 1
