/*
008_make_section_subsection_nullable.sql
SQL Server migration: allow blank Excel Section/Sub-Section values to persist as NULL.
Idempotent. Does not delete/recreate data.

The raw table is fixed. Display tables may use either the historical _test name or
common UI-renamed prj_attribute_display name. If you configured a different custom
Display table basename, run the same ALTER COLUMN statements against that table too.
*/
SET XACT_ABORT ON;
BEGIN TRY
    BEGIN TRANSACTION;

    IF OBJECT_ID(N'dbo.raw_prj_attribute_new_test', N'U') IS NOT NULL
    BEGIN
        ALTER TABLE dbo.raw_prj_attribute_new_test ALTER COLUMN section nvarchar(255) NULL;
        ALTER TABLE dbo.raw_prj_attribute_new_test ALTER COLUMN sub_section nvarchar(255) NULL;
    END;

    DECLARE @schema sysname, @table sysname, @sql nvarchar(max);
    DECLARE display_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT s.name, t.name
        FROM sys.tables t
        JOIN sys.schemas s ON s.schema_id = t.schema_id
        WHERE s.name IN (N'stg', N'dbo')
          AND t.name IN (N'prj_attribute_display_test', N'prj_attribute_display');

    OPEN display_cursor;
    FETCH NEXT FROM display_cursor INTO @schema, @table;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @sql = N'ALTER TABLE ' + QUOTENAME(@schema) + N'.' + QUOTENAME(@table)
                 + N' ALTER COLUMN section nvarchar(255) NULL; '
                 + N'ALTER TABLE ' + QUOTENAME(@schema) + N'.' + QUOTENAME(@table)
                 + N' ALTER COLUMN subsection nvarchar(255) NULL;';
        EXEC sys.sp_executesql @sql;
        FETCH NEXT FROM display_cursor INTO @schema, @table;
    END;
    CLOSE display_cursor;
    DEALLOCATE display_cursor;

    COMMIT TRANSACTION;
    SELECT 'Migration completed successfully' AS migration_result;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF CURSOR_STATUS('local', 'display_cursor') >= -1
    BEGIN
        CLOSE display_cursor;
        DEALLOCATE display_cursor;
    END;
    THROW;
END CATCH;
