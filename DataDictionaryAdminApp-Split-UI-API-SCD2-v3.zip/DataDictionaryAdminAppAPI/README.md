# DataDictionaryAdminAppAPI (FastAPI/API)

API-only deployment for the PRJ Data Dictionary Administration Platform.

- Runs FastAPI/Uvicorn on port 8503.
- Owns database configuration, SQLAlchemy models, repositories, services, migrations, audit and SCD2 history.
- Does not contain Streamlit runtime code.
- Public HTTP API paths remain under `/api/v1`, preserving the UI/API contract.

## Rollout order
1. Apply DB migration `sql/postgres/011_add_scd2_history.sql` (PostgreSQL) or `sql/011_add_scd2_history.sql` (SQL Server).
2. Deploy `DataDictionaryAdminAppAPI` on port 8503.
3. Point the UI `API_BASE_URL` to this API service.

The API remains migration-aware: if `scd2_row_history` is not yet present, existing CRUD continues to work, but SCD2 capture starts only after migration 011 is installed.
