from pathlib import Path

from DataDictionaryAdminApp.core.database import _rewrite_postgres_master_segment_column


def test_postgres_master_segment_rewrite_handles_qualified_select_and_update_binds():
    select_sql = (
        'SELECT "prj_attribute_master_new_test".where_in_financial_statement '
        'FROM "prj_stage"."prj_attribute_master_new_test"'
    )
    update_sql = (
        'UPDATE "prj_stage"."prj_attribute_master_new_test" '
        'SET where_in_financial_statement=%(where_in_financial_statement)s '
        'WHERE "prj_attribute_master_new_test".where_in_financial_statement IS NOT NULL'
    )
    rewritten_select = _rewrite_postgres_master_segment_column(select_sql)
    rewritten_update = _rewrite_postgres_master_segment_column(update_sql)

    assert '.segment' in rewritten_select
    assert '.where_in_financial_statement' not in rewritten_select
    assert 'SET segment=%(where_in_financial_statement)s' in rewritten_update
    assert '%(where_in_financial_statement)s' in rewritten_update
    assert '.segment IS NOT NULL' in rewritten_update


def test_postgres_translation_is_dialect_fail_safe_not_option_only():
    source = Path('src/DataDictionaryAdminApp/core/database.py').read_text(encoding='utf-8')
    assert 'conn.dialect.name == "postgresql"' in source
    assert 'postgres_master_segment_column=(db_type == "POSTGRES")' in source


def test_sqlserver_schema_contract_still_uses_legacy_master_column():
    create_sql = Path('src/DataDictionaryAdminApp/sql/001_create_tables.sql').read_text(encoding='utf-8').lower()
    assert 'where_in_financial_statement' in create_sql
