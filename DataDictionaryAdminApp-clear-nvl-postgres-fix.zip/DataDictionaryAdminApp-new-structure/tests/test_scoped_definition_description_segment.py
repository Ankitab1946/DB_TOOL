from pathlib import Path

from DataDictionaryAdminApp.api.schemas_api import AttributeUpsert
from DataDictionaryAdminApp.service.data_dictionary_service import DataDictionaryService
from DataDictionaryAdminApp.utils.normalizers import align_pipe_values


def test_aligned_pipe_values_preserve_positional_duplicates():
    assert align_pipe_values("Same|Same", 2, "Attribute Description") == ["Same", "Same"]
    assert align_pipe_values("One", 2, "Segment", default="NA") == ["One", "One"]


def test_scoped_definition_description_and_segment_expand_with_section_pairs():
    class FakeRepo:
        def __init__(self):
            self.raw_rows = []
            self.rules = []
            self.master = None

        def portfolio_ref(self, value):
            return {"label": "FI Banks", "port_ref_id": 1, "portfolio_name": "FI", "sector_name": "Banks"}

        def physical_name_for_prj(self, prj_id):
            return None

        def physical_name_exists(self, name, exclude_prj_id=None):
            return False

        def available_physical_name(self, base_name, exclude_prj_id=None):
            return base_name

        def original_mapping_type(self, prj_id):
            return None

        def source_code(self, source_name, source_abbr_name=None):
            return source_abbr_name or "SNPAR"

        def upsert_raw(self, row, user, source_operation, defer_insert_audit=False, strict_key=False):
            self.raw_rows.append(dict(row))
            return None

        def upsert_staging_master(self, row, user, source_operation):
            self.master = dict(row)

        def upsert_staging_rule(self, row, user, source_operation, defer_insert_audit=False, strict_key=False):
            self.rules.append(dict(row))
            return None

        def emit_deferred_insert_audits(self, items):
            return None

    service = DataDictionaryService(db=None)
    repo = FakeRepo()
    service.repo = repo
    payload = AttributeUpsert(
        prj_id="CFV300",
        portfolio="FI Banks",
        source_abbr_name="SNPAR",
        prj_attribute_name="Scoped Text Test",
        section="Total|Liabilities",
        sub_section="Current|Current2",
        segment="Segment Total|Segment Liabilities",
        attribute_definition="Definition Total|Definition Liabilities",
        attribute_description="Description Total|Description Liabilities",
        data_type="Amount",
        calculated_or_reported="Reported",
        display_order=1,
    )

    result = service.stage_attribute_pending(payload, "tester", "UI_CREATE")

    assert result["raw_rows_staged"] == 2
    assert result["business_rule_rows_staged"] == 2
    assert [
        (r["section"], r["sub_section"], r["segment"], r["attribute_definition"], r["attribute_description"])
        for r in repo.raw_rows
    ] == [
        ("Total", "Current", "Segment Total", "Definition Total", "Description Total"),
        ("Liabilities", "Current2", "Segment Liabilities", "Definition Liabilities", "Description Liabilities"),
    ]
    assert [
        (r["section"], r["subsection"], r["segment"], r["prj_attribute_definition"], r["prj_attribute_description"])
        for r in repo.rules
    ] == [
        ("Total", "Current", "Segment Total", "Definition Total", "Description Total"),
        ("Liabilities", "Current2", "Segment Liabilities", "Definition Liabilities", "Description Liabilities"),
    ]


def test_single_scoped_values_broadcast_to_all_pairs():
    rows = DataDictionaryService._expand_rule_pairs(
        {
            "section": "Total|Liabilities",
            "subsection": "Current|Current2",
            "segment": "Shared Segment",
            "prj_attribute_definition": "Shared Definition",
            "prj_attribute_description": "Shared Description",
            "prompt_description": "Shared Description",
        }
    )
    assert len(rows) == 2
    assert {row["segment"] for row in rows} == {"Shared Segment"}
    assert {row["prj_attribute_definition"] for row in rows} == {"Shared Definition"}
    assert {row["prj_attribute_description"] for row in rows} == {"Shared Description"}


def test_ui_contains_dynamic_pair_fields_and_pipe_segment_guidance():
    source = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
    assert "Attribute Definition and Attribute Description are captured per Section/Sub-Section pair" in source
    assert 'key=f"{prefix}_definition_{pair_index}"' in source
    assert 'key=f"{prefix}_description_{pair_index}"' in source
    assert "Segment supports positional pipe-separated values" in source


def test_existing_database_migrations_add_scoped_columns():
    sql_server = Path("src/DataDictionaryAdminApp/sql/003_add_scoped_definition_segment.sql").read_text(encoding="utf-8")
    postgres = Path("src/DataDictionaryAdminApp/sql/postgres/003_add_scoped_definition_segment.sql").read_text(encoding="utf-8")
    for sql in (sql_server, postgres):
        assert "prj_attribute_definition" in sql
        assert "segment" in sql
        assert "prj_attribute_business_rules_new_test" in sql
