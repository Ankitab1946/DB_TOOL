# Validation Results

Latest runtime compatibility patch validates the following regressions:

- Bulk upload preview/finalize accept `MERGE`, `INSERT_ONLY`, and `REPLACE`.
- `INSERT ONLY`, `INSERT-ONLY`, and `INSERTONLY` are normalized to `INSERT_ONLY`.
- SQL Server BIT predicates compile as `= 1` / `= 0`; runtime source contains no `.is_(True)` / `.is_(False)` predicates.
- PostgreSQL boolean predicates compile as `= true` / `= false`.
- `/api/v1/health` advertises the supported upload modes and database-status capability so Streamlit can detect a stale FastAPI process.
- `/api/v1/system/database-status` remains available; Streamlit performs a direct `SELECT 1` diagnostic fallback only if that API status endpoint is missing/unreachable.
- Normal application CRUD remains API-based.

No database DDL/schema changes are required by this patch.

## Import compatibility fix

- Removed the runtime dependency on `DataDictionaryAdminApp.utils.sqlalchemy_compat` so partial file-copy deployments cannot fail with `No module named DataDictionaryAdminApp.Utils.sqlalchemy_compat`.
- SQL Server/PostgreSQL boolean predicates now use SQLAlchemy built-in `true()` / `false()` expressions directly in the repository/service code.
- Verified SQL Server active predicates compile with `= 1` and PostgreSQL active predicates compile with `= true`.
- Full test suite passes after removing the helper-module dependency.

## View Latest Edit/Soft Delete UX patch
- Removed the separate Edit Latest editable-grid section.
- View Latest grid now uses single-row selection with Edit and Soft Delete actions.
- Edit opens a pre-populated editable Streamlit modal and saves changes to staging through the existing PUT API.
- Create/Edit expose Calculation Logic, Attribute Definition, Attribute Description and editable Tech Logic.
- Create/Edit modal maximum width increased from 1220 to 1450.
- Create success message displays the generated CFV/PRJ identifier after staging.
- Existing Reactivate, Bulk Upload, Finalize, Prompt Management, Audit, role gating, S3 and database behavior retained.
- Validation: 37 tests passed; Python compileall passed; FastAPI/OpenAPI import passed.
