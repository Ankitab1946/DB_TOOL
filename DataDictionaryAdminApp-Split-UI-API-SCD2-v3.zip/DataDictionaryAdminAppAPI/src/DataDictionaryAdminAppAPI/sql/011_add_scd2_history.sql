-- Central SCD2 companion history for SQL Server.
IF OBJECT_ID('dbo.scd2_row_history', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.scd2_row_history (
        history_id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        source_schema NVARCHAR(128) NOT NULL,
        source_table NVARCHAR(255) NOT NULL,
        record_key NVARCHAR(500) NOT NULL,
        version_number INT NOT NULL,
        effective_from DATETIME2 NOT NULL CONSTRAINT df_scd2_effective_from DEFAULT SYSUTCDATETIME(),
        effective_to DATETIME2 NULL,
        is_current BIT NOT NULL CONSTRAINT df_scd2_current DEFAULT 1,
        operation NVARCHAR(50) NOT NULL,
        row_data NVARCHAR(MAX) NULL,
        source_operation NVARCHAR(100) NULL,
        changed_by NVARCHAR(128) NOT NULL CONSTRAINT df_scd2_changed_by DEFAULT 'migration',
        changed_at DATETIME2 NOT NULL CONSTRAINT df_scd2_changed_at DEFAULT SYSUTCDATETIME(),
        CONSTRAINT uq_scd2_row_version UNIQUE(source_schema, source_table, record_key, version_number)
    );
    CREATE INDEX ix_scd2_row_lookup ON dbo.scd2_row_history(source_schema, source_table, record_key, is_current);
    CREATE UNIQUE INDEX uq_scd2_one_current ON dbo.scd2_row_history(source_schema, source_table, record_key) WHERE is_current = 1;
END;
GO

-- Baseline helper. Repeated safely for each existing table.
DECLARE @now DATETIME2 = SYSUTCDATETIME();
IF OBJECT_ID('dbo.raw_prj_attribute_new_test','U') IS NOT NULL
INSERT INTO dbo.scd2_row_history(source_schema,source_table,record_key,version_number,effective_from,is_current,operation,row_data,source_operation,changed_by,changed_at)
SELECT 'dbo','raw_prj_attribute_new_test',CONVERT(NVARCHAR(500),t.raw_row_id),1,@now,1,'BASELINE',(SELECT t.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),'MIGRATION','migration',@now
FROM dbo.raw_prj_attribute_new_test t WHERE NOT EXISTS (SELECT 1 FROM dbo.scd2_row_history h WHERE h.source_schema='dbo' AND h.source_table='raw_prj_attribute_new_test' AND h.record_key=CONVERT(NVARCHAR(500),t.raw_row_id));

IF OBJECT_ID('stg.prj_attribute_master_new_test','U') IS NOT NULL
INSERT INTO dbo.scd2_row_history(source_schema,source_table,record_key,version_number,effective_from,is_current,operation,row_data,source_operation,changed_by,changed_at)
SELECT 'stg','prj_attribute_master_new_test',CONVERT(NVARCHAR(500),t.prj_id),1,@now,1,'BASELINE',(SELECT t.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),'MIGRATION','migration',@now
FROM stg.prj_attribute_master_new_test t WHERE NOT EXISTS (SELECT 1 FROM dbo.scd2_row_history h WHERE h.source_schema='stg' AND h.source_table='prj_attribute_master_new_test' AND h.record_key=CONVERT(NVARCHAR(500),t.prj_id));

IF OBJECT_ID('stg.prj_attribute_business_rules_new_test','U') IS NOT NULL
INSERT INTO dbo.scd2_row_history(source_schema,source_table,record_key,version_number,effective_from,is_current,operation,row_data,source_operation,changed_by,changed_at)
SELECT 'stg','prj_attribute_business_rules_new_test',CONVERT(NVARCHAR(500),t.scope_id),1,@now,1,'BASELINE',(SELECT t.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),'MIGRATION','migration',@now
FROM stg.prj_attribute_business_rules_new_test t WHERE NOT EXISTS (SELECT 1 FROM dbo.scd2_row_history h WHERE h.source_schema='stg' AND h.source_table='prj_attribute_business_rules_new_test' AND h.record_key=CONVERT(NVARCHAR(500),t.scope_id));

IF OBJECT_ID('stg.prj_attribute_display_test','U') IS NOT NULL
INSERT INTO dbo.scd2_row_history(source_schema,source_table,record_key,version_number,effective_from,is_current,operation,row_data,source_operation,changed_by,changed_at)
SELECT 'stg','prj_attribute_display_test',CONVERT(NVARCHAR(500),t.display_id),1,@now,1,'BASELINE',(SELECT t.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),'MIGRATION','migration',@now
FROM stg.prj_attribute_display_test t WHERE NOT EXISTS (SELECT 1 FROM dbo.scd2_row_history h WHERE h.source_schema='stg' AND h.source_table='prj_attribute_display_test' AND h.record_key=CONVERT(NVARCHAR(500),t.display_id));

IF OBJECT_ID('dbo.prj_attribute_master_new_test','U') IS NOT NULL
INSERT INTO dbo.scd2_row_history(source_schema,source_table,record_key,version_number,effective_from,is_current,operation,row_data,source_operation,changed_by,changed_at)
SELECT 'dbo','prj_attribute_master_new_test',CONVERT(NVARCHAR(500),t.prj_id),1,@now,1,'BASELINE',(SELECT t.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),'MIGRATION','migration',@now
FROM dbo.prj_attribute_master_new_test t WHERE NOT EXISTS (SELECT 1 FROM dbo.scd2_row_history h WHERE h.source_schema='dbo' AND h.source_table='prj_attribute_master_new_test' AND h.record_key=CONVERT(NVARCHAR(500),t.prj_id));

IF OBJECT_ID('dbo.prj_attribute_business_rules_new_test','U') IS NOT NULL
INSERT INTO dbo.scd2_row_history(source_schema,source_table,record_key,version_number,effective_from,is_current,operation,row_data,source_operation,changed_by,changed_at)
SELECT 'dbo','prj_attribute_business_rules_new_test',CONVERT(NVARCHAR(500),t.scope_id),1,@now,1,'BASELINE',(SELECT t.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),'MIGRATION','migration',@now
FROM dbo.prj_attribute_business_rules_new_test t WHERE NOT EXISTS (SELECT 1 FROM dbo.scd2_row_history h WHERE h.source_schema='dbo' AND h.source_table='prj_attribute_business_rules_new_test' AND h.record_key=CONVERT(NVARCHAR(500),t.scope_id));

IF OBJECT_ID('dbo.prj_attribute_display_test','U') IS NOT NULL
INSERT INTO dbo.scd2_row_history(source_schema,source_table,record_key,version_number,effective_from,is_current,operation,row_data,source_operation,changed_by,changed_at)
SELECT 'dbo','prj_attribute_display_test',CONVERT(NVARCHAR(500),t.display_id),1,@now,1,'BASELINE',(SELECT t.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),'MIGRATION','migration',@now
FROM dbo.prj_attribute_display_test t WHERE NOT EXISTS (SELECT 1 FROM dbo.scd2_row_history h WHERE h.source_schema='dbo' AND h.source_table='prj_attribute_display_test' AND h.record_key=CONVERT(NVARCHAR(500),t.display_id));

IF OBJECT_ID('dbo.prj_portfolio_reference_new_test','U') IS NOT NULL
INSERT INTO dbo.scd2_row_history(source_schema,source_table,record_key,version_number,effective_from,is_current,operation,row_data,source_operation,changed_by,changed_at)
SELECT 'dbo','prj_portfolio_reference_new_test',CONVERT(NVARCHAR(500),t.port_ref_id),1,@now,1,'BASELINE',(SELECT t.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),'MIGRATION','migration',@now
FROM dbo.prj_portfolio_reference_new_test t WHERE NOT EXISTS (SELECT 1 FROM dbo.scd2_row_history h WHERE h.source_schema='dbo' AND h.source_table='prj_portfolio_reference_new_test' AND h.record_key=CONVERT(NVARCHAR(500),t.port_ref_id));

IF OBJECT_ID('dbo.prj_data_sources','U') IS NOT NULL
INSERT INTO dbo.scd2_row_history(source_schema,source_table,record_key,version_number,effective_from,is_current,operation,row_data,source_operation,changed_by,changed_at)
SELECT 'dbo','prj_data_sources',CONVERT(NVARCHAR(500),t.source_code),1,@now,1,'BASELINE',(SELECT t.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),'MIGRATION','migration',@now
FROM dbo.prj_data_sources t WHERE NOT EXISTS (SELECT 1 FROM dbo.scd2_row_history h WHERE h.source_schema='dbo' AND h.source_table='prj_data_sources' AND h.record_key=CONVERT(NVARCHAR(500),t.source_code));

IF OBJECT_ID('dbo.audit_table_new_test','U') IS NOT NULL
INSERT INTO dbo.scd2_row_history(source_schema,source_table,record_key,version_number,effective_from,is_current,operation,row_data,source_operation,changed_by,changed_at)
SELECT 'dbo','audit_table_new_test',CONVERT(NVARCHAR(500),t.audit_id),1,@now,1,'BASELINE',(SELECT t.* FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),'MIGRATION','migration',@now
FROM dbo.audit_table_new_test t WHERE NOT EXISTS (SELECT 1 FROM dbo.scd2_row_history h WHERE h.source_schema='dbo' AND h.source_table='audit_table_new_test' AND h.record_key=CONVERT(NVARCHAR(500),t.audit_id));
GO
