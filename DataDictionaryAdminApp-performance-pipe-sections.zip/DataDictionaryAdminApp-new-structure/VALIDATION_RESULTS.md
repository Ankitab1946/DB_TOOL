# Validation Results — Performance + Pipe Section Support

## Changes

- Cached reflected `dbo.prj_data_sources` metadata per SQLAlchemy engine to avoid repeated SQL Server catalog reflection.
- Bulk upload preloads portfolio/source mappings, original mapping types, and physical-name ownership once per workbook operation.
- Validate/Compare batch-fetches final master/rule state instead of querying final tables per PRJ ID.
- Delta calculation batch-fetches staging and final master/rule state in a fixed number of queries instead of multiple queries per PRJ ID.
- Raw + staging-rule identity allocation uses one flush per attribute path where possible; removed a duplicate staging-rule INSERT audit entry.
- Create Attribute caches the next PRJ ID for the modal session so Streamlit reruns do not repeatedly scan IDs.
- Physical-name availability checking is on-demand in the UI; backend uniqueness validation remains authoritative on save.
- Section and Sub-Section support multiple values separated by `|`; values are trimmed and de-duplicated while preserving order.
- Section/Sub-Section filter lookups expand pipe-separated values into individual choices and token-aware filtering remains available.

## Compatibility

- No database schema/table changes are required.
- MERGE, INSERT_ONLY, REPLACE, Create/Edit, Soft Delete/Reactivate, Finalize, S3, role restrictions, SQL Server and PostgreSQL behavior remain intact.
- Existing single Section/Sub-Section values continue to work unchanged.

## Validation

- `40/40` pytest tests passed.
- Python `compileall` passed for `src` and `tests`.
- FastAPI application import passed.
- OpenAPI generation passed with `28` API paths.
