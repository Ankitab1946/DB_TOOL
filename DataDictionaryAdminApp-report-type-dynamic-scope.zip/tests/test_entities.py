from DataDictionaryAdminApp.model.entities import (
    AttributeBusinessRule,
    AttributeMaster,
    AuditTable,
    PortfolioReference,
    RawAttribute,
    StagingAttributeMaster,
    StagingBusinessRule,
)


def test_entity_schema_alignment():
    assert RawAttribute.__table__.fullname == "dbo.raw_prj_attribute_new_test"
    assert PortfolioReference.__table__.fullname == "dbo.prj_portfolio_reference_new_test"
    assert AuditTable.__table__.fullname == "dbo.audit_table_new_test"
    assert StagingAttributeMaster.__table__.fullname == "stg.prj_attribute_master_new_test"
    assert StagingBusinessRule.__table__.fullname == "stg.prj_attribute_business_rules_new_test"
    assert AttributeMaster.__table__.fullname == "dbo.prj_attribute_master_new_test"
    assert AttributeBusinessRule.__table__.fullname == "dbo.prj_attribute_business_rules_new_test"


def test_business_rule_columns_are_aligned():
    expected = {
        "scope_id", "prj_id", "port_ref_id", "source_abbr_name", "editable", "symbol", "mapping_type",
        "calculation_logic", "prj_attribute_definition", "prj_attribute_description", "segment", "report_type", "tech_logic", "display_order", "display_name",
        "section", "subsection", "prompt_description", "examples", "is_active", "created_at", "updated_at",
        "created_by", "updated_by",
    }
    assert expected == set(AttributeBusinessRule.__table__.columns.keys())
    assert expected == set(StagingBusinessRule.__table__.columns.keys())
