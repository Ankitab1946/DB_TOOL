from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SQL_DIR = ROOT / "src" / "DataDictionaryAdminApp" / "sql"


def test_migration_canonicalizes_master_aliases_before_rule_backfill():
    sql = (SQL_DIR / "003_add_scoped_definition_segment.sql").read_text(encoding="utf-8").lower()
    assert "cfv_attribute_definition" in sql
    assert "add prj_attribute_definition" in sql
    assert "add where_in_financial_statement" in sql
    assert "sp_executesql" in sql
    # Newly-added target columns are backfilled via dynamic SQL, avoiding same-batch compile errors.
    assert "update stg.prj_attribute_master_new_test" in sql
    assert "update dbo.prj_attribute_master_new_test" in sql


def test_validator_requires_canonical_runtime_columns_and_is_read_only():
    sql = (SQL_DIR / "002_validate_schema.sql").read_text(encoding="utf-8").lower()
    assert "prj_attribute_definition" in sql
    assert "where_in_financial_statement" in sql
    assert "alter table" not in sql
    assert "update " not in sql
    assert "delete " not in sql
    assert "insert into dbo." not in sql
