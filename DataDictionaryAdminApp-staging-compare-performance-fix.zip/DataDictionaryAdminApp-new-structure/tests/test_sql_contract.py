from pathlib import Path

SQL_DIR = Path(__file__).parents[1] / "src" / "DataDictionaryAdminApp" / "sql"


def test_create_script_contains_all_new_tables_and_stg_schema():
    sql = (SQL_DIR / "001_create_tables.sql").read_text(encoding="utf-8").lower()
    for name in [
        "dbo.raw_prj_attribute_new_test",
        "dbo.prj_portfolio_reference_new_test",
        "dbo.audit_table_new_test",
        "stg.prj_attribute_master_new_test",
        "stg.prj_attribute_business_rules_new_test",
        "dbo.prj_attribute_master_new_test",
        "dbo.prj_attribute_business_rules_new_test",
    ]:
        assert name in sql
    assert "create schema stg" in sql
    assert "create table dbo.prj_data_sources" not in sql


def test_runtime_python_has_no_legacy_table_dependencies():
    root = Path(__file__).parents[1] / "src" / "DataDictionaryAdminApp"
    legacy = {
        "prj_attribute_master_test",
        "prj_portfolio_reference_test",
        "prj_attribute_portfolio_scope_test",
        "prj_attribute_business_rules_test",
        "prj_scanning_prompt_reference_test",
        "audit_table_test",
    }
    for path in root.rglob("*.py"):
        text = path.read_text(encoding="utf-8")
        assert not any(name in text for name in legacy), f"legacy table reference in {path}"
