/*
010_default_section_subsection_na.sql
SQL Server migration: revert nullable Section/Sub-Section behavior and use literal N/A defaults.
Idempotent. Existing NULL/blank values are converted to N/A before NOT NULL is restored.

The raw table is fixed. Display tables may use either the historical _test name or
common UI-renamed prj_attribute_display name. For any other custom physical display
basename, apply the same UPDATE / ALTER COLUMN / DEFAULT pattern to that table.
*/
SET XACT_ABORT ON;
BEGIN TRY
    BEGIN TRANSACTION;

    IF OBJECT_ID(N'dbo.raw_prj_attribute_new_test', N'U') IS NOT NULL
    BEGIN
        UPDATE dbo.raw_prj_attribute_new_test
        SET section = N'N/A'
        WHERE section IS NULL OR LTRIM(RTRIM(section)) = N'';

        UPDATE dbo.raw_prj_attribute_new_test
        SET sub_section = N'N/A'
        WHERE sub_section IS NULL OR LTRIM(RTRIM(sub_section)) = N'';

        ALTER TABLE dbo.raw_prj_attribute_new_test ALTER COLUMN section nvarchar(255) NOT NULL;
        ALTER TABLE dbo.raw_prj_attribute_new_test ALTER COLUMN sub_section nvarchar(255) NOT NULL;

        IF NOT EXISTS (
            SELECT 1 FROM sys.default_constraints dc
            JOIN sys.columns c ON c.object_id = dc.parent_object_id AND c.column_id = dc.parent_column_id
            WHERE dc.parent_object_id = OBJECT_ID(N'dbo.raw_prj_attribute_new_test') AND c.name = N'section'
        ) ALTER TABLE dbo.raw_prj_attribute_new_test ADD CONSTRAINT DF_raw_prj_section_na DEFAULT(N'N/A') FOR section;

        IF NOT EXISTS (
            SELECT 1 FROM sys.default_constraints dc
            JOIN sys.columns c ON c.object_id = dc.parent_object_id AND c.column_id = dc.parent_column_id
            WHERE dc.parent_object_id = OBJECT_ID(N'dbo.raw_prj_attribute_new_test') AND c.name = N'sub_section'
        ) ALTER TABLE dbo.raw_prj_attribute_new_test ADD CONSTRAINT DF_raw_prj_subsection_na DEFAULT(N'N/A') FOR sub_section;
    END;

    DECLARE @schema sysname, @table sysname, @sql nvarchar(max), @obj int;
    DECLARE display_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT s.name, t.name
        FROM sys.tables t
        JOIN sys.schemas s ON s.schema_id = t.schema_id
        WHERE s.name IN (N'stg', N'dbo')
          AND t.name IN (N'prj_attribute_display_test', N'prj_attribute_display');

    OPEN display_cursor;
    FETCH NEXT FROM display_cursor INTO @schema, @table;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @sql = N'UPDATE ' + QUOTENAME(@schema) + N'.' + QUOTENAME(@table)
                 + N' SET section = N''N/A'' WHERE section IS NULL OR LTRIM(RTRIM(section)) = N''''; '
                 + N'UPDATE ' + QUOTENAME(@schema) + N'.' + QUOTENAME(@table)
                 + N' SET subsection = N''N/A'' WHERE subsection IS NULL OR LTRIM(RTRIM(subsection)) = N''''; '
                 + N'ALTER TABLE ' + QUOTENAME(@schema) + N'.' + QUOTENAME(@table)
                 + N' ALTER COLUMN section nvarchar(255) NOT NULL; '
                 + N'ALTER TABLE ' + QUOTENAME(@schema) + N'.' + QUOTENAME(@table)
                 + N' ALTER COLUMN subsection nvarchar(255) NOT NULL;';
        EXEC sys.sp_executesql @sql;

        SET @obj = OBJECT_ID(QUOTENAME(@schema) + N'.' + QUOTENAME(@table));
        IF NOT EXISTS (
            SELECT 1 FROM sys.default_constraints dc
            JOIN sys.columns c ON c.object_id = dc.parent_object_id AND c.column_id = dc.parent_column_id
            WHERE dc.parent_object_id = @obj AND c.name = N'section'
        )
        BEGIN
            SET @sql = N'ALTER TABLE ' + QUOTENAME(@schema) + N'.' + QUOTENAME(@table)
                     + N' ADD DEFAULT(N''N/A'') FOR section;';
            EXEC sys.sp_executesql @sql;
        END;

        IF NOT EXISTS (
            SELECT 1 FROM sys.default_constraints dc
            JOIN sys.columns c ON c.object_id = dc.parent_object_id AND c.column_id = dc.parent_column_id
            WHERE dc.parent_object_id = @obj AND c.name = N'subsection'
        )
        BEGIN
            SET @sql = N'ALTER TABLE ' + QUOTENAME(@schema) + N'.' + QUOTENAME(@table)
                     + N' ADD DEFAULT(N''N/A'') FOR subsection;';
            EXEC sys.sp_executesql @sql;
        END;

        FETCH NEXT FROM display_cursor INTO @schema, @table;
    END;
    CLOSE display_cursor;
    DEALLOCATE display_cursor;

    COMMIT TRANSACTION;
    SELECT 'Migration completed successfully' AS migration_result;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    IF CURSOR_STATUS('local', 'display_cursor') >= -1
    BEGIN
        CLOSE display_cursor;
        DEALLOCATE display_cursor;
    END;
    THROW;
END CATCH;
