"""Dialect-neutral SQLAlchemy repository for SQL Server and PostgreSQL.

Business/LLM rule data and display metadata are stored separately and rejoined
here so the public service/API contract remains backward compatible.
"""
from __future__ import annotations

import json
import re
from datetime import datetime
from typing import Any

from sqlalchemy import MetaData, Table, and_, delete, distinct, false, func, inspect, or_, select, text, true, update
from sqlalchemy.orm import Session

from DataDictionaryAdminAppAPI.core.target_tables import TARGET_TABLE_DEFAULTS
from DataDictionaryAdminAppAPI.model.entities import (
    AttributeBusinessRule,
    AttributeDisplay,
    AttributeMaster,
    AuditTable,
    PortfolioReference,
    PostgresPortfolioReference,
    RawAttribute,
    Scd2RowHistory,
    StagingAttributeDisplay,
    StagingAttributeMaster,
    StagingBusinessRule,
)
from DataDictionaryAdminAppAPI.utils.normalizers import canonical_portfolio_label, split_pipe_values


def _json(value: Any) -> str | None:
    if value is None:
        return None
    return json.dumps(value, default=str, ensure_ascii=False, sort_keys=True)


def model_dict(obj: Any) -> dict[str, Any]:
    if obj is None:
        return {}
    return {column.key: getattr(obj, column.key) for column in obj.__table__.columns}


def portfolio_label(portfolio_name: str, sector_name: str) -> str:
    return f"{str(portfolio_name).strip()} {str(sector_name).strip()}".strip()


BUSINESS_INPUT_MAP = {
    "prj_id": "prj_id",
    "port_ref_id": "port_ref_id",
    "source_abbr_name": "source_abbr_name",
    "prompt_description": "prompt_description",
    "examples": "examples_for_llm",
    "editable": "editable",
    "symbol": "data_type",
    "mapping_type": "attribute_type",
    "tech_logic": "business_logic",
    "calculation_logic": "calculation_logic",
}
DISPLAY_INPUT_MAP = {
    "display_order": "display_order",
    "prj_id": "prj_id",
    "display_name": "display_name",
    "section": "section",
    "subsection": "subsection",
    "prj_attribute_definition": "prj_attribute_definition",
    "prj_attribute_description": "prj_attribute_description",
    "segment": "segment",
    "report_type": "report_type",
}


def combined_rule_dict(rule: Any, display: Any, *, is_active: bool = True) -> dict[str, Any]:
    """Return the historical combined rule shape used by API/UI/service code."""
    row = model_dict(rule)
    row.update(
        {
            "symbol": rule.data_type,
            "mapping_type": rule.attribute_type,
            "tech_logic": rule.business_logic,
            "examples": rule.examples_for_llm,
            "display_id": display.display_id,
            "display_order": display.display_order,
            "display_name": display.display_name,
            "section": display.section,
            "subsection": display.subsection,
            "prj_attribute_definition": display.prj_attribute_definition,
            "prj_attribute_description": display.prj_attribute_description,
            "segment": display.segment,
            "report_type": display.report_type,
            "is_active": bool(is_active),
        }
    )
    return row


class DataDictionaryRepository:
    _source_table_cache: dict[tuple[int, str], Table | None] = {}

    def __init__(self, db: Session):
        self.db = db

    def _session_info(self) -> dict[str, Any]:
        info = getattr(self.db, "info", None)
        return info if isinstance(info, dict) else {}

    def target_table_name(self, key: str) -> str:
        names = self._session_info().get("target_table_names") or TARGET_TABLE_DEFAULTS
        return str(names.get(key) or TARGET_TABLE_DEFAULTS[key])

    def _physical_schema(self, logical: str) -> str:
        bind = self.db.get_bind()
        if bind.dialect.name == "postgresql":
            info = self._session_info()
            return {
                "dbo": str(info.get("pg_schema") or "prj_dbd"),
                "stg": str(info.get("staging_schema") or "prj_stage"),
            }.get(logical, logical)
        return logical

    def qualified_target_table(self, key: str) -> str:
        logical_schema = "stg" if key.startswith("stg_") else "dbo"
        return f"{self._physical_schema(logical_schema)}.{self.target_table_name(key)}"

    def _physical_target_table(self, key: str, metadata: MetaData | None = None) -> Table:
        """Reflect exactly one UI-selected physical target without following legacy FKs.

        Custom Actual/Final tables are allowed to retain foreign-key metadata that
        references an older/default table basename.  Finalize preview only needs the
        selected table's own columns, so resolving referenced tables can cause false
        reflection failures.  Disable request table-name rewriting during reflection
        and do not recursively resolve foreign keys.
        """
        logical_schema = "stg" if key.startswith("stg_") else "dbo"
        physical_schema = self._physical_schema(logical_schema)
        reflection_bind = self.db.get_bind().execution_options(target_table_rewrites=())
        return Table(
            self.target_table_name(key),
            metadata or MetaData(),
            schema=physical_schema,
            autoload_with=reflection_bind,
            resolve_fks=False,
        )

    def _audited_table_name(self, schema_name: str, table_name: str) -> str:
        mapping = {
            ("stg", TARGET_TABLE_DEFAULTS["stg_master"]): "stg_master",
            ("stg", TARGET_TABLE_DEFAULTS["stg_business"]): "stg_business",
            ("stg", TARGET_TABLE_DEFAULTS["stg_display"]): "stg_display",
            ("dbo", TARGET_TABLE_DEFAULTS["final_master"]): "final_master",
            ("dbo", TARGET_TABLE_DEFAULTS["final_business"]): "final_business",
            ("dbo", TARGET_TABLE_DEFAULTS["final_display"]): "final_display",
        }
        key = mapping.get((schema_name, table_name))
        return self.target_table_name(key) if key else table_name

    def portfolio_model(self):
        """Return the physical portfolio-reference ORM model for this engine."""
        bind = self.db.get_bind()
        return PostgresPortfolioReference if bind.dialect.name == "postgresql" else PortfolioReference

    def portfolio_table_name(self) -> str:
        return (f"{self._physical_schema('dbo')}.prj_portfolio_reference"
                if self.db.get_bind().dialect.name == "postgresql"
                else "dbo.prj_portfolio_reference_new_test")

    def hard_delete_dictionary_data(self, user: str = "sysuser") -> dict[str, int]:
        deleted: dict[str, int] = {}
        targets = (
            (f"{self._physical_schema('stg')}.{self.target_table_name('stg_display')}", StagingAttributeDisplay),
            (f"{self._physical_schema('stg')}.{self.target_table_name('stg_business')}", StagingBusinessRule),
            (f"{self._physical_schema('dbo')}.{self.target_table_name('final_display')}", AttributeDisplay),
            (f"{self._physical_schema('dbo')}.{self.target_table_name('final_business')}", AttributeBusinessRule),
            (f"{self._physical_schema('stg')}.{self.target_table_name('stg_master')}", StagingAttributeMaster),
            (f"{self._physical_schema('dbo')}.{self.target_table_name('final_master')}", AttributeMaster),
            (f"{self._physical_schema('dbo')}.raw_prj_attribute_new_test", RawAttribute),
            (f"{self._physical_schema('dbo')}.audit_table_new_test", AuditTable),
        )
        for table_name, model in targets:
            count = int(self.db.scalar(select(func.count()).select_from(model)) or 0)
            logical_schema, physical_table = table_name.split(".", 1)
            self.scd2_close_table(logical_schema if logical_schema in {"dbo", "stg"} else logical_schema, physical_table)
            self.db.execute(delete(model))
            deleted[table_name] = count

        portfolio_model = self.portfolio_model()
        custom_filter = ~portfolio_model.port_ref_id.in_([1, 2, 3, 4])
        custom_rows = self.db.scalars(select(portfolio_model).where(custom_filter)).all()
        count = len(custom_rows)
        portfolio_table = "prj_portfolio_reference" if self.db.get_bind().dialect.name == "postgresql" else "prj_portfolio_reference_new_test"
        for row in custom_rows:
            self.scd2_version("dbo", portfolio_table, str(row.port_ref_id), "HARD_DELETE", model_dict(row), None, user, "CLEANUP")
        self.db.execute(delete(portfolio_model).where(custom_filter))
        deleted[f"{self.portfolio_table_name()} (custom rows)"] = count
        return deleted

    def _scd2_table(self) -> Table | None:
        """Return the physical SCD2 table when migration 011 is installed.

        This keeps rolling deployments backward compatible: API v3 can start
        against a pre-011 schema without breaking existing CRUD. SCD2 begins
        automatically as soon as the migration creates the companion table.
        """
        schema = self._physical_schema("dbo")
        connection = self.db.connection().execution_options(target_table_rewrites=())
        try:
            if not inspect(connection).has_table("scd2_row_history", schema=schema):
                return None
            return Table(
                "scd2_row_history", MetaData(), schema=schema,
                autoload_with=connection, resolve_fks=False,
            )
        except Exception:
            return None

    def scd2_version(
        self, schema_name: str, table_name: str, record_key: str, action: str,
        before: Any, after: Any, user: str, source_operation: str = "UI",
    ) -> None:
        """Append one effective-dated version without changing operational keys."""
        history = self._scd2_table()
        if history is None:
            return
        physical_schema = self._physical_schema(schema_name) if schema_name in {"dbo", "stg"} else str(schema_name)
        physical_table = self._audited_table_name(schema_name, table_name) if schema_name in {"dbo", "stg"} else str(table_name)
        key = str(record_key)
        now = datetime.utcnow()
        current = self.db.execute(
            select(history)
            .where(
                history.c.source_schema == physical_schema,
                history.c.source_table == physical_table,
                history.c.record_key == key,
                history.c.is_current == true(),
            )
            .order_by(history.c.version_number.desc())
            .limit(1)
        ).mappings().first()
        if current is not None:
            self.db.execute(
                update(history)
                .where(history.c.history_id == current["history_id"])
                .values(is_current=False, effective_to=now)
            )
        max_version = self.db.scalar(
            select(func.max(history.c.version_number)).where(
                history.c.source_schema == physical_schema,
                history.c.source_table == physical_table,
                history.c.record_key == key,
            )
        ) or 0
        terminal = str(action or "").upper() in {"DELETE", "HARD_DELETE", "REPLACE_CLEAR", "DISCARD"}
        payload = before if terminal and after is None else (after if after is not None else before)
        self.db.execute(
            history.insert().values(
                source_schema=physical_schema,
                source_table=physical_table,
                record_key=key,
                version_number=int(max_version) + 1,
                effective_from=now,
                effective_to=now if terminal else None,
                is_current=not terminal,
                operation=str(action or "UNKNOWN").upper(),
                row_data=_json(payload),
                source_operation=source_operation,
                changed_by=user,
                changed_at=now,
            )
        )

    def scd2_close_table(self, schema_name: str, table_name: str) -> None:
        """Close all current SCD2 versions before a physical bulk clear."""
        history = self._scd2_table()
        if history is None:
            return
        physical_schema = self._physical_schema(schema_name) if schema_name in {"dbo", "stg"} else str(schema_name)
        physical_table = self._audited_table_name(schema_name, table_name) if schema_name in {"dbo", "stg"} else str(table_name)
        self.db.execute(
            update(history)
            .where(
                history.c.source_schema == physical_schema,
                history.c.source_table == physical_table,
                history.c.is_current == true(),
            )
            .values(is_current=False, effective_to=datetime.utcnow())
        )

    def scd2_history(
        self, schema_name: str | None = None, table_name: str | None = None,
        record_key: str | None = None, current_only: bool = False, limit: int = 2000,
    ) -> list[dict[str, Any]]:
        history = self._scd2_table()
        if history is None:
            return []
        stmt = select(history)
        if schema_name:
            stmt = stmt.where(history.c.source_schema == str(schema_name))
        if table_name:
            stmt = stmt.where(history.c.source_table == str(table_name))
        if record_key:
            stmt = stmt.where(history.c.record_key == str(record_key))
        if current_only:
            stmt = stmt.where(history.c.is_current == true())
        stmt = stmt.order_by(history.c.changed_at.desc(), history.c.history_id.desc()).limit(max(1, min(int(limit), 10000)))
        return [dict(row) for row in self.db.execute(stmt).mappings().all()]

    def audit(self, schema_name: str, table_name: str, record_key: str, action: str, before: Any,
              after: Any, user: str, source_operation: str = "UI") -> None:
        # Persist the physical schema name in audit history. SQL Server keeps
        # dbo/stg; PostgreSQL translates those logical schemas to prj_dbd/prj_stage.
        physical_schema = self._physical_schema(schema_name)
        physical_table = self._audited_table_name(schema_name, table_name)
        self.scd2_version(schema_name, table_name, str(record_key), action, before, after, user, source_operation)
        audit_row = AuditTable(
            schema_name=physical_schema,
            table_name=physical_table,
            record_key=str(record_key),
            action=action,
            before_value=_json(before),
            after_value=_json(after),
            source_operation=source_operation,
            performed_by=user,
            performed_at=datetime.utcnow(),
        )
        self.db.add(audit_row)
        # Flush only assigns the audit identity; transaction/commit semantics stay unchanged.
        self.db.flush()
        self.scd2_version(
            "dbo", "audit_table_new_test", str(audit_row.audit_id), "INSERT",
            None, model_dict(audit_row), user, "AUDIT",
        )

    def next_prj_id(self) -> str:
        """Return the next PRJ/CFV identifier for the selected database.

        PostgreSQL uses physical schemas ``prj_dbd`` and ``prj_stage``.  This
        bootstrap lookup is invoked before the Create modal can open, so query
        those physical tables explicitly instead of relying on ORM schema
        translation.  SQL Server keeps the established ORM path (dbo/stg).
        """
        bind = self.db.get_bind()
        values: list[str] = []
        if bind.dialect.name == "postgresql":
            inspector = inspect(bind)
            main_schema = self._physical_schema("dbo")
            staging_schema = self._physical_schema("stg")
            stg_master_name = self.target_table_name("stg_master")
            final_master_name = self.target_table_name("final_master")
            required = (
                (main_schema, "raw_prj_attribute_new_test"),
                (staging_schema, stg_master_name),
                (main_schema, final_master_name),
            )
            missing = [f"{schema}.{table}" for schema, table in required if not inspector.has_table(table, schema=schema)]
            if missing:
                raise RuntimeError(
                    "PostgreSQL Data Dictionary schema is not ready. Missing required table(s): "
                    + ", ".join(missing)
                    + ". Check Target Tables in the sidebar or run the PostgreSQL setup/migration scripts and 002_validate_schema.sql."
                )
            stmt = text(
                f"SELECT prj_id FROM {main_schema}.raw_prj_attribute_new_test "
                f"UNION ALL SELECT prj_id FROM {staging_schema}.{stg_master_name} "
                f"UNION ALL SELECT prj_id FROM {main_schema}.{final_master_name}"
            )
            values.extend(str(value) for value in self.db.scalars(stmt).all() if value)
        else:
            for model in (RawAttribute, StagingAttributeMaster, AttributeMaster):
                values.extend(str(row[0]) for row in self.db.execute(select(model.prj_id)).all() if row[0])

        maximum = 0
        for value in values:
            match = re.search(r"(\d+)$", value.strip(), flags=re.IGNORECASE)
            if match:
                maximum = max(maximum, int(match.group(1)))
        return f"PRJ{maximum + 1}"

    def existing_prj_ids(self) -> set[str]:
        values: set[str] = set()
        for model in (RawAttribute, StagingAttributeMaster, AttributeMaster):
            values.update(str(value) for value in self.db.scalars(select(model.prj_id)).all() if value and str(value).strip())
        return values

    def physical_name_exists(self, physical_name: str, exclude_prj_id: str | None = None) -> bool:
        wanted = physical_name.strip().casefold()
        if not wanted:
            return False
        for model in (RawAttribute, StagingAttributeMaster, AttributeMaster):
            stmt = select(model.prj_id).where(func.lower(model.prj_physical_attribute_name) == wanted)
            if exclude_prj_id:
                stmt = stmt.where(func.lower(model.prj_id) != str(exclude_prj_id).strip().casefold())
            if self.db.execute(stmt.limit(1)).first():
                return True
        return False

    def physical_name_for_prj(self, prj_id: str) -> str | None:
        wanted = str(prj_id).strip().casefold()
        for model in (StagingAttributeMaster, AttributeMaster, RawAttribute):
            stmt = select(model.prj_physical_attribute_name).where(func.lower(model.prj_id) == wanted)
            if model is RawAttribute:
                stmt = stmt.order_by(model.raw_row_id)
            value = self.db.execute(stmt.limit(1)).scalar_one_or_none()
            if value is not None and str(value).strip():
                return str(value).strip()
        return None

    def available_physical_name(self, base_name: str, exclude_prj_id: str | None = None) -> str:
        base = base_name.strip() or "attribute"
        if not self.physical_name_exists(base, exclude_prj_id=exclude_prj_id):
            return base
        for suffix in range(2, 10001):
            suffix_text = f"_{suffix}"
            candidate = f"{base[:500-len(suffix_text)]}{suffix_text}"
            if not self.physical_name_exists(candidate, exclude_prj_id=exclude_prj_id):
                return candidate
        raise ValueError(f"Could not generate a unique PRJ Physical Attribute Name from '{base}'.")

    def _source_table(self) -> Table | None:
        bind = self.db.get_bind()
        schema = self._physical_schema("dbo")
        cache_key = (id(bind), schema)
        if cache_key in self._source_table_cache:
            return self._source_table_cache[cache_key]
        inspector = inspect(bind)
        table: Table | None = None

        # PostgreSQL has one authoritative source-reference table.  Do not fall
        # back to the SQL Server/legacy singular name because the UI contract is
        # explicitly prj_dbd.prj_data_sources.
        names = ("prj_data_sources",) if bind.dialect.name == "postgresql" else ("prj_data_sources", "prj_data_source")
        for name in names:
            if inspector.has_table(name, schema=schema):
                table = Table(name, MetaData(), schema=schema, autoload_with=bind)
                break
        self._source_table_cache[cache_key] = table
        return table

    def source_table_name(self) -> str | None:
        table = self._source_table()
        return table.fullname if table is not None else None

    def list_sources(self) -> list[dict[str, Any]]:
        table = self._source_table()
        is_postgres = self.db.get_bind().dialect.name == "postgresql"
        if table is None:
            if is_postgres:
                raise RuntimeError("Required PostgreSQL source table prj_dbd.prj_data_sources does not exist.")
            return [{"src_id": None, "source_code": "SNPAR", "source_name": "SNPAR (default)"}]

        id_col = next((table.c[name] for name in ("src_id", "prj_src_id", "source_id") if name in table.c), None)
        if "source_code" not in table.c or "source_name" not in table.c:
            if is_postgres:
                missing = [name for name in ("source_code", "source_name") if name not in table.c]
                raise RuntimeError(
                    "PostgreSQL source table prj_dbd.prj_data_sources is missing required column(s): "
                    + ", ".join(missing)
                )
            return [{"src_id": None, "source_code": "SNPAR", "source_name": "SNPAR (default)"}]

        columns = [table.c.source_code, table.c.source_name]
        if id_col is not None:
            columns.insert(0, id_col)
        result = []
        for row in self.db.execute(select(*columns).order_by(table.c.source_name, table.c.source_code)).all():
            mapping = row._mapping
            code = mapping.get("source_code")
            name = mapping.get("source_name")
            if code is None or not str(code).strip():
                continue
            result.append({
                "src_id": mapping.get(id_col.key) if id_col is not None else None,
                "source_code": str(code).strip(),
                "source_name": str(name).strip() if name is not None and str(name).strip() else str(code).strip(),
            })
        return result

    def source_code(self, source_name: str | None, source_abbr_name: str | None = None) -> str:
        requested = str(source_abbr_name or "").strip()
        table = self._source_table()
        if requested:
            if requested.upper() == "SNPAR":
                return "SNPAR"
            if table is None or "source_code" not in table.c:
                return requested
            value = self.db.execute(select(table.c.source_code).where(table.c.source_code == requested).limit(1)).scalar_one_or_none()
            if value is None:
                raise ValueError(f"Unknown source code: {requested}")
            return str(value)
        if not source_name:
            return "SNPAR"
        if table is None or "source_code" not in table.c or "source_name" not in table.c:
            return "SNPAR"
        value = self.db.execute(select(table.c.source_code).where(table.c.source_name == source_name).limit(1)).scalar_one_or_none()
        if value is None:
            raise ValueError(f"Unknown source name: {source_name}")
        return str(value)

    def list_portfolios(self, include_inactive: bool = False) -> list[dict[str, Any]]:
        """Return portfolio values without assuming optional audit columns exist.

        SQL Server continues to use the managed ORM table.  PostgreSQL may point
        at an established ``prj_dbd.prj_portfolio_reference`` table that predates
        this application and therefore can legitimately contain only the core
        portfolio columns.  Reflect the physical PostgreSQL table and select the
        columns that actually exist so valid rows are not hidden by an ORM SELECT
        that references missing audit fields.
        """
        bind = self.db.get_bind()
        result: list[dict[str, Any]] = []
        seen: set[tuple[str, str]] = set()

        if bind.dialect.name == "postgresql":
            inspector = inspect(bind)
            schema, table_name = self._physical_schema("dbo"), "prj_portfolio_reference"
            if not inspector.has_table(table_name, schema=schema):
                raise RuntimeError(f"Required PostgreSQL portfolio table {schema}.{table_name} does not exist.")
            table = Table(table_name, MetaData(), schema=schema, autoload_with=bind)
            required = ("port_ref_id", "portfolio_name", "sector_name")
            missing = [name for name in required if name not in table.c]
            if missing:
                raise RuntimeError(
                    f"PostgreSQL portfolio table {schema}.{table_name} is missing required column(s): "
                    + ", ".join(missing)
                )

            optional = ("sub_sector", "remarks", "is_active", "created_at", "updated_at", "created_by", "updated_by")
            columns = [table.c[name] for name in required]
            columns.extend(table.c[name] for name in optional if name in table.c)
            # PostgreSQL Portfolio/Scope is an authoritative reference lookup.
            # Return the physical table rows regardless of legacy is_active values;
            # users reported populated reference data being hidden by this filter.
            stmt = select(*columns).order_by(table.c.portfolio_name, table.c.sector_name, table.c.port_ref_id)
            rows = self.db.execute(stmt).all()
            for item in rows:
                mapping = dict(item._mapping)
                row = {
                    "port_ref_id": mapping.get("port_ref_id"),
                    "portfolio_name": mapping.get("portfolio_name"),
                    "sector_name": mapping.get("sector_name"),
                    "sub_sector": mapping.get("sub_sector"),
                    "remarks": mapping.get("remarks"),
                    "is_active": True if mapping.get("is_active") is None else bool(mapping.get("is_active")),
                    "created_at": mapping.get("created_at"),
                    "updated_at": mapping.get("updated_at"),
                    "created_by": mapping.get("created_by"),
                    "updated_by": mapping.get("updated_by"),
                }
                pair = (str(row["portfolio_name"] or "").strip().lower(), str(row["sector_name"] or "").strip().lower())
                if not all(pair) or pair in seen:
                    continue
                seen.add(pair)
                row["label"] = portfolio_label(row["portfolio_name"], row["sector_name"])
                result.append(row)
            return result

        portfolio_model = self.portfolio_model()
        stmt = select(portfolio_model)
        if not include_inactive:
            stmt = stmt.where(portfolio_model.is_active == true())
        stmt = stmt.order_by(portfolio_model.portfolio_name, portfolio_model.sector_name, portfolio_model.port_ref_id)
        for item in self.db.scalars(stmt).all():
            row = model_dict(item)
            pair = (str(row["portfolio_name"]).strip().lower(), str(row["sector_name"]).strip().lower())
            if pair in seen:
                continue
            seen.add(pair)
            row["label"] = portfolio_label(row["portfolio_name"], row["sector_name"])
            result.append(row)
        return result

    def portfolio_ref(self, portfolio: str) -> dict[str, Any] | None:
        wanted = canonical_portfolio_label(portfolio).lower()
        return next((row for row in self.list_portfolios(True) if str(row["label"]).lower() == wanted), None)

    @staticmethod
    def _master_model(schema: str):
        if schema == "dbo": return AttributeMaster
        if schema == "stg": return StagingAttributeMaster
        raise ValueError("Invalid schema")

    @staticmethod
    def _rule_model(schema: str):
        if schema == "dbo": return AttributeBusinessRule
        if schema == "stg": return StagingBusinessRule
        raise ValueError("Invalid schema")

    @staticmethod
    def _display_model(schema: str):
        if schema == "dbo": return AttributeDisplay
        if schema == "stg": return StagingAttributeDisplay
        raise ValueError("Invalid schema")

    def get_master(self, prj_id: str, schema: str = "dbo") -> dict[str, Any] | None:
        obj = self.db.get(self._master_model(schema), prj_id)
        return model_dict(obj) if obj else None

    def get_rules(self, prj_id: str, schema: str = "dbo") -> list[dict[str, Any]]:
        rule_model, display_model, master_model = self._rule_model(schema), self._display_model(schema), self._master_model(schema)
        portfolio_model = self.portfolio_model()
        stmt = (
            select(rule_model, display_model, portfolio_model, master_model.is_active)
            .join(display_model, display_model.scope_id == rule_model.scope_id)
            .join(portfolio_model, portfolio_model.port_ref_id == rule_model.port_ref_id)
            .join(master_model, master_model.prj_id == rule_model.prj_id)
            .where(rule_model.prj_id == prj_id)
            .order_by(rule_model.port_ref_id, display_model.display_order, rule_model.scope_id)
        )
        rows = []
        for rule, display, portfolio, active in self.db.execute(stmt).all():
            row = combined_rule_dict(rule, display, is_active=bool(active))
            row.update({
                "portfolio_name": portfolio.portfolio_name,
                "sector_name": portfolio.sector_name,
                "portfolio": portfolio_label(portfolio.portfolio_name, portfolio.sector_name),
            })
            rows.append(row)
        return rows

    def preload_state(self, prj_ids: set[str], schema: str = "dbo") -> tuple[dict[str, dict[str, Any]], dict[str, list[dict[str, Any]]]]:
        if not prj_ids:
            return {}, {}
        master_model, rule_model, display_model = self._master_model(schema), self._rule_model(schema), self._display_model(schema)
        master_objs = self.db.scalars(select(master_model).where(master_model.prj_id.in_(prj_ids))).all()
        masters = {item.prj_id: model_dict(item) for item in master_objs}
        active_by_prj = {item.prj_id: bool(item.is_active) for item in master_objs}
        rules: dict[str, list[dict[str, Any]]] = {key: [] for key in prj_ids}
        stmt = (
            select(rule_model, display_model)
            .join(display_model, display_model.scope_id == rule_model.scope_id)
            .where(rule_model.prj_id.in_(prj_ids))
            .order_by(rule_model.prj_id, rule_model.port_ref_id, display_model.display_order, rule_model.scope_id)
        )
        for rule, display in self.db.execute(stmt).all():
            rules.setdefault(rule.prj_id, []).append(combined_rule_dict(rule, display, is_active=active_by_prj.get(rule.prj_id, True)))
        return masters, rules

    def preload_final_state(self, prj_ids: set[str]):
        return self.preload_state(prj_ids, "dbo")

    def has_custom_target_tables(self) -> bool:
        """Return True when any staging/final table basename differs from the default."""
        names = self._session_info().get("target_table_names") or TARGET_TABLE_DEFAULTS
        return any(str(names.get(key) or TARGET_TABLE_DEFAULTS[key]) != default for key, default in TARGET_TABLE_DEFAULTS.items())

    def preload_target_state(
        self, prj_ids: set[str], schema: str = "dbo"
    ) -> tuple[dict[str, dict[str, Any]], dict[str, list[dict[str, Any]]]]:
        """Read staging/final state from the exact UI-selected physical tables.

        This path is used by Finalize preview/delta when custom table names are
        configured. It deliberately reflects the selected table basenames rather
        than depending on compiled ORM-name rewriting, so changing only Actual /
        Final table names is immediately visible in the delta comparison.
        """
        if not prj_ids:
            return {}, {}
        side = "stg" if schema == "stg" else "final"
        logical_schema = "stg" if side == "stg" else "dbo"
        metadata = MetaData()
        try:
            master = self._physical_target_table(f"{side}_master", metadata)
            business = self._physical_target_table(f"{side}_business", metadata)
            display = self._physical_target_table(f"{side}_display", metadata)
        except Exception as exc:
            targets = ", ".join(
                self.qualified_target_table(f"{side}_{name}") for name in ("master", "business", "display")
            )
            raise RuntimeError(
                f"Unable to read the selected {side} target tables ({targets}). "
                f"Check that the tables exist and match the expected dictionary structure. Database error: {exc}"
            ) from exc

        required = {
            "master": {"prj_id", "prj_attribute_name", "prj_physical_attribute_name", "is_active"},
            "business": {
                "scope_id", "prj_id", "port_ref_id", "source_abbr_name", "prompt_description",
                "examples_for_llm", "editable", "data_type", "attribute_type", "business_logic",
                "calculation_logic",
            },
            "display": {
                "display_id", "scope_id", "display_order", "prj_id", "display_name", "section",
                "subsection", "prj_attribute_definition", "prj_attribute_description", "segment", "report_type",
            },
        }
        missing: list[str] = []
        for label, table in (("master", master), ("business", business), ("display", display)):
            for column in sorted(required[label] - set(table.c.keys())):
                missing.append(f"{table.schema}.{table.name}.{column}")
        if "where_in_financial_statement" not in master.c and "segment" not in master.c:
            missing.append(f"{master.schema}.{master.name}.segment/where_in_financial_statement")
        if missing:
            raise RuntimeError(
                "Selected target table structure is missing required column(s): " + ", ".join(missing)
            )

        master_rows = self.db.execute(select(master).where(master.c.prj_id.in_(prj_ids))).mappings().all()
        masters: dict[str, dict[str, Any]] = {}
        for row in master_rows:
            item = dict(row)
            # PostgreSQL master tables physically use ``segment`` while the shared
            # service/API contract keeps the legacy logical field name for SQL Server
            # compatibility and to avoid changing existing UI payloads.
            if "where_in_financial_statement" not in item and "segment" in item:
                item["where_in_financial_statement"] = item.get("segment")
            masters[str(item["prj_id"])] = item
        active_by_prj = {key: bool(value.get("is_active", True)) for key, value in masters.items()}
        rules: dict[str, list[dict[str, Any]]] = {key: [] for key in prj_ids}
        stmt = (
            select(
                business.c.scope_id.label("scope_id"),
                business.c.prj_id.label("prj_id"),
                business.c.port_ref_id.label("port_ref_id"),
                business.c.source_abbr_name.label("source_abbr_name"),
                business.c.prompt_description.label("prompt_description"),
                business.c.examples_for_llm.label("examples"),
                business.c.editable.label("editable"),
                business.c.data_type.label("symbol"),
                business.c.attribute_type.label("mapping_type"),
                business.c.business_logic.label("tech_logic"),
                business.c.calculation_logic.label("calculation_logic"),
                display.c.display_id.label("display_id"),
                display.c.display_order.label("display_order"),
                display.c.display_name.label("display_name"),
                display.c.section.label("section"),
                display.c.subsection.label("subsection"),
                display.c.prj_attribute_definition.label("prj_attribute_definition"),
                display.c.prj_attribute_description.label("prj_attribute_description"),
                display.c.segment.label("segment"),
                display.c.report_type.label("report_type"),
            )
            .select_from(business.join(display, display.c.scope_id == business.c.scope_id))
            .where(business.c.prj_id.in_(prj_ids))
            .order_by(business.c.prj_id, business.c.port_ref_id, display.c.display_order, business.c.scope_id)
        )
        for row in self.db.execute(stmt).mappings().all():
            item = dict(row)
            item["is_active"] = active_by_prj.get(str(item["prj_id"]), True)
            rules.setdefault(str(item["prj_id"]), []).append(item)
        return masters, rules

    def target_staging_prj_ids(self) -> list[str]:
        """Read pending PRJ IDs from the exact selected staging master table."""
        master = self._physical_target_table("stg_master")
        return [str(value) for value in self.db.scalars(select(master.c.prj_id).order_by(master.c.prj_id)).all()]

    def clear_target_staging(
        self, prj_ids: list[str], user: str = "sysuser", source_operation: str = "WORKFLOW"
    ) -> None:
        """Delete selected rows from custom staging tables and close their SCD2 versions."""
        if not prj_ids:
            return
        metadata = MetaData()
        business = self._physical_target_table("stg_business", metadata)
        display = self._physical_target_table("stg_display", metadata)
        master = self._physical_target_table("stg_master", metadata)
        scope_ids = select(business.c.scope_id).where(business.c.prj_id.in_(prj_ids))
        for row in self.db.execute(select(display).where(display.c.scope_id.in_(scope_ids))).mappings().all():
            self.scd2_version("stg", display.name, str(row["display_id"]), "DELETE", dict(row), None, user, source_operation)
        for row in self.db.execute(select(business).where(business.c.prj_id.in_(prj_ids))).mappings().all():
            self.scd2_version("stg", business.name, str(row["scope_id"]), "DELETE", dict(row), None, user, source_operation)
        for row in self.db.execute(select(master).where(master.c.prj_id.in_(prj_ids))).mappings().all():
            self.scd2_version("stg", master.name, str(row["prj_id"]), "DELETE", dict(row), None, user, source_operation)
        self.db.execute(delete(display).where(display.c.scope_id.in_(scope_ids)))
        self.db.execute(delete(business).where(business.c.prj_id.in_(prj_ids)))
        self.db.execute(delete(master).where(master.c.prj_id.in_(prj_ids)))

    def delete_raw_for_prj_ids(
        self, prj_ids: list[str], user: str = "sysuser", source_operation: str = "WORKFLOW"
    ) -> None:
        """Remove raw rows for discarded new attributes and close SCD2 versions."""
        if not prj_ids:
            return
        rows = self.db.scalars(select(RawAttribute).where(RawAttribute.prj_id.in_(prj_ids))).all()
        for row in rows:
            self.scd2_version(
                "dbo", "raw_prj_attribute_new_test", str(row.raw_row_id), "DELETE",
                model_dict(row), None, user, source_operation,
            )
        self.db.execute(delete(RawAttribute).where(RawAttribute.prj_id.in_(prj_ids)))

    def preload_original_mapping_types(self, prj_ids: set[str]) -> dict[str, str | None]:
        result = {prj_id: None for prj_id in prj_ids}
        if not prj_ids:
            return result
        for prj_id, value in self.db.execute(
            select(AttributeBusinessRule.prj_id, AttributeBusinessRule.attribute_type)
            .where(AttributeBusinessRule.prj_id.in_(prj_ids)).order_by(AttributeBusinessRule.prj_id, AttributeBusinessRule.scope_id)
        ).all():
            if result.get(prj_id) is None and str(value or "").strip().lower() != "repeated":
                result[prj_id] = str(value)
        unresolved = {key for key, value in result.items() if value is None}
        if unresolved:
            for prj_id, value in self.db.execute(
                select(RawAttribute.prj_id, RawAttribute.calculated_or_reported)
                .where(RawAttribute.prj_id.in_(unresolved)).order_by(RawAttribute.prj_id, RawAttribute.raw_row_id)
            ).all():
                if result.get(prj_id) is None and str(value or "").strip().lower() != "repeated":
                    result[prj_id] = str(value)
        return result

    def preload_physical_names(self) -> tuple[dict[str, set[str]], dict[str, str]]:
        """Preload every physical-name owner plus the preferred name per PRJ.

        A physical name can temporarily be present for more than one PRJ across
        staging/raw/final (for example after an older bulk upload generated a
        duplicate that only fails at Finalize).  Do not collapse that state to a
        single owner: the bulk allocator needs to see *all* owners before deciding
        whether a generated name is safe.

        The preferred name for an existing PRJ comes from Final first, then
        staging, then raw.  This keeps blank MERGE uploads for established PRJs on
        their canonical Final physical name when it is still unique.
        """
        owners: dict[str, set[str]] = {}
        by_prj: dict[str, str] = {}
        for model in (AttributeMaster, StagingAttributeMaster, RawAttribute):
            stmt = select(model.prj_id, model.prj_physical_attribute_name)
            if model is RawAttribute:
                stmt = stmt.order_by(model.raw_row_id)
            for prj_id, value in self.db.execute(stmt).all():
                name = str(value or "").strip()
                prj_text = str(prj_id or "").strip()
                if not name or not prj_text:
                    continue
                owners.setdefault(name.casefold(), set()).add(prj_text)
                by_prj.setdefault(prj_text.casefold(), name)
        return owners, by_prj

    def final_detail(self, prj_id: str) -> dict[str, Any] | None:
        master = self.get_master(prj_id, "dbo")
        if master: master["rules"] = self.get_rules(prj_id, "dbo")
        return master

    def working_detail(self, prj_id: str) -> dict[str, Any] | None:
        master = self.get_master(prj_id, "stg")
        if master:
            master["rules"] = self.get_rules(prj_id, "stg"); master["data_state"] = "STAGED"; return master
        master = self.final_detail(prj_id)
        if master: master["data_state"] = "FINAL"
        return master

    @staticmethod
    def _pipe_token_condition(column: Any, value: str):
        wanted = str(value or "").strip().lower(); lowered = func.lower(column)
        return or_(lowered == wanted, lowered.like(f"{wanted}|%"), lowered.like(f"%|{wanted}|%"), lowered.like(f"%|{wanted}"))

    def filter_final(self, filters: Any, page_size: int) -> dict[str, Any]:
        m, r, d, p = AttributeMaster, AttributeBusinessRule, AttributeDisplay, self.portfolio_model()
        conditions: list[Any] = []
        if not filters.include_deleted: conditions.append(m.is_active == true())
        if filters.prj_id: conditions.append(m.prj_id.ilike(f"%{filters.prj_id.strip()}%"))
        if filters.attribute_name: conditions.append(m.prj_attribute_name.ilike(f"%{filters.attribute_name.strip()}%"))
        if filters.attribute_definition:
            term = f"%{filters.attribute_definition.strip()}%"; conditions.append(or_(d.prj_attribute_definition.ilike(term), m.prj_attribute_definition.ilike(term)))
        if filters.section: conditions.append(self._pipe_token_condition(d.section, filters.section))
        if filters.subsection: conditions.append(self._pipe_token_condition(d.subsection, filters.subsection))
        if filters.portfolios:
            ids = [int(ref["port_ref_id"]) for x in filters.portfolios if (ref := self.portfolio_ref(x))]
            conditions.append(r.port_ref_id.in_(ids) if ids else m.prj_id == "__NO_MATCH__")
        if filters.sources:
            codes = [str(x).strip() for x in filters.sources if str(x).strip()]
            if codes: conditions.append(r.source_abbr_name.in_(codes))
        if filters.overlapped_only:
            scope_stmt = select(func.count(distinct(AttributeBusinessRule.port_ref_id))).where(AttributeBusinessRule.prj_id == m.prj_id)
            conditions.append(scope_stmt.correlate(m).scalar_subquery() > 1)
        if filters.search:
            term = f"%{filters.search.strip()}%"
            conditions.append(or_(
                m.prj_id.ilike(term), m.prj_attribute_name.ilike(term), m.prj_attribute_definition.ilike(term),
                d.prj_attribute_definition.ilike(term), d.prj_attribute_description.ilike(term), d.segment.ilike(term),
                d.report_type.ilike(term), d.section.ilike(term), d.subsection.ilike(term), r.source_abbr_name.ilike(term), d.display_name.ilike(term)
            ))
        count_stmt = select(func.count()).select_from(r).join(d, d.scope_id == r.scope_id).join(m, m.prj_id == r.prj_id).join(p, p.port_ref_id == r.port_ref_id)
        data_stmt = select(m, r, d, p).join(r, r.prj_id == m.prj_id).join(d, d.scope_id == r.scope_id).join(p, p.port_ref_id == r.port_ref_id)
        if conditions:
            pred = and_(*conditions); count_stmt = count_stmt.where(pred); data_stmt = data_stmt.where(pred)
        total = int(self.db.execute(count_stmt).scalar_one()); page = max(1, int(filters.page or 1))
        result_rows = self.db.execute(data_stmt.order_by(m.prj_id, d.display_order, r.scope_id).offset((page-1)*page_size).limit(page_size)).all()
        rows = []
        for master, rule, display, portfolio in result_rows:
            item = model_dict(master)
            c = combined_rule_dict(rule, display, is_active=bool(master.is_active))
            item.update(c)
            item.update({
                "portfolio": portfolio_label(portfolio.portfolio_name, portfolio.sector_name),
                "portfolios": portfolio_label(portfolio.portfolio_name, portfolio.sector_name),
                "sources": str(rule.source_abbr_name),
                "prj_attribute_definition": display.prj_attribute_definition or master.prj_attribute_definition,
                "where_in_financial_statement": display.segment or master.where_in_financial_statement,
                "rule_is_active": bool(master.is_active),
            })
            rows.append(item)
        return {"rows": rows, "total": total, "page": page, "page_size": page_size}

    def soft_deleted_rows(self) -> list[dict[str, Any]]:
        masters = list(self.db.scalars(select(AttributeMaster).where(AttributeMaster.is_active == false()).order_by(AttributeMaster.prj_id)).all())
        if not masters: return []
        prj_ids = [x.prj_id for x in masters]
        by_prj: dict[str, list[tuple[Any, Any, Any]]] = {x: [] for x in prj_ids}
        portfolio_model = self.portfolio_model()
        stmt = (select(AttributeBusinessRule, AttributeDisplay, portfolio_model)
                .join(AttributeDisplay, AttributeDisplay.scope_id == AttributeBusinessRule.scope_id)
                .join(portfolio_model, portfolio_model.port_ref_id == AttributeBusinessRule.port_ref_id)
                .where(AttributeBusinessRule.prj_id.in_(prj_ids))
                .order_by(AttributeBusinessRule.prj_id, AttributeBusinessRule.port_ref_id, AttributeDisplay.display_order))
        for rule, display, portfolio in self.db.execute(stmt).all(): by_prj.setdefault(rule.prj_id, []).append((rule, display, portfolio))
        rows=[]
        for master in masters:
            item=model_dict(master); pairs=by_prj.get(master.prj_id, [])
            if pairs:
                rule, display, _ = pairs[0]; item.update(combined_rule_dict(rule, display, is_active=False))
            item["portfolios"] = ", ".join(dict.fromkeys(portfolio_label(p.portfolio_name,p.sector_name) for _,_,p in pairs))
            item["sources"] = ", ".join(dict.fromkeys(str(r.source_abbr_name) for r,_,_ in pairs)); item["is_active"]=False; rows.append(item)
        return rows

    def active_final_prj_ids(self) -> set[str]:
        return {str(v) for v in self.db.scalars(select(AttributeMaster.prj_id).where(AttributeMaster.is_active == true())).all() if v is not None}

    def editable_rows(self, include_deleted: bool = True) -> list[dict[str, Any]]:
        portfolio_model = self.portfolio_model()
        stmt=(select(AttributeMaster,AttributeBusinessRule,AttributeDisplay,portfolio_model)
              .join(AttributeBusinessRule,AttributeBusinessRule.prj_id==AttributeMaster.prj_id)
              .join(AttributeDisplay,AttributeDisplay.scope_id==AttributeBusinessRule.scope_id)
              .join(portfolio_model,portfolio_model.port_ref_id==AttributeBusinessRule.port_ref_id))
        if not include_deleted: stmt=stmt.where(AttributeMaster.is_active==true())
        stmt=stmt.order_by(AttributeMaster.prj_id,AttributeBusinessRule.port_ref_id,AttributeDisplay.display_order)
        rows=[]
        for master,rule,display,portfolio in self.db.execute(stmt).all():
            rows.append({
                "scope_id":rule.scope_id,"display_id":display.display_id,"prj_id":master.prj_id,
                "portfolio":portfolio_label(portfolio.portfolio_name,portfolio.sector_name),"source_abbr_name":rule.source_abbr_name,
                "prj_attribute_name":master.prj_attribute_name,"prj_physical_attribute_name":master.prj_physical_attribute_name,
                "section":display.section,"sub_section":display.subsection,"data_type":rule.data_type,
                "calculated_or_reported":rule.attribute_type,"calculation_logic":rule.calculation_logic,
                "segment":display.segment or master.where_in_financial_statement,"report_type":display.report_type,
                "prj_attribute_definition":display.prj_attribute_definition or master.prj_attribute_definition,
                "attribute_description":display.prj_attribute_description,"tech_logic":rule.business_logic,
                "display_order":display.display_order,"display_name":display.display_name,"prompt_description":rule.prompt_description,
                "examples":rule.examples_for_llm,"is_active":bool(master.is_active),
            })
        return rows

    def lookup_values(self) -> dict[str, Any]:
        section_values=list(self.db.scalars(select(distinct(AttributeDisplay.section)).join(AttributeMaster,AttributeMaster.prj_id==AttributeDisplay.prj_id).where(AttributeMaster.is_active==true()).order_by(AttributeDisplay.section)).all())
        subsection_values=list(self.db.scalars(select(distinct(AttributeDisplay.subsection)).join(AttributeMaster,AttributeMaster.prj_id==AttributeDisplay.prj_id).where(AttributeMaster.is_active==true()).order_by(AttributeDisplay.subsection)).all())
        sections=sorted({x for v in section_values for x in split_pipe_values(v)},key=str.casefold); subsections=sorted({x for v in subsection_values for x in split_pipe_values(v)},key=str.casefold)
        return {"portfolios":self.list_portfolios(True),"sources":self.list_sources(),"sections":sections,"subsections":subsections}

    def original_mapping_type(self, prj_id: str) -> str | None:
        for value in self.db.scalars(select(AttributeBusinessRule.attribute_type).where(AttributeBusinessRule.prj_id==prj_id).order_by(AttributeBusinessRule.scope_id)).all():
            if str(value or "").strip().lower() != "repeated": return str(value)
        for value in self.db.scalars(select(RawAttribute.calculated_or_reported).where(RawAttribute.prj_id==prj_id).order_by(RawAttribute.raw_row_id)).all():
            if str(value or "").strip().lower() != "repeated": return str(value)
        return None

    def active_raw_for_scope(self, prj_id: str, portfolio: str) -> list[RawAttribute]:
        return list(self.db.scalars(select(RawAttribute).where(RawAttribute.prj_id==prj_id,RawAttribute.portfolio==portfolio,RawAttribute.is_active==true()).order_by(RawAttribute.raw_row_id)).all())

    def preload_pending_objects(self, prj_ids: set[str]) -> dict[str, Any]:
        raw_by_scope: dict[tuple[str,str],list[RawAttribute]]={}; masters:dict[str,StagingAttributeMaster]={}; rules_by_scope:dict[tuple[str,int],list[tuple[StagingBusinessRule,StagingAttributeDisplay]]]={}
        if not prj_ids:return {"raw":raw_by_scope,"masters":masters,"rules":rules_by_scope}
        for item in self.db.scalars(select(RawAttribute).where(RawAttribute.prj_id.in_(prj_ids),RawAttribute.is_active==true()).order_by(RawAttribute.prj_id,RawAttribute.portfolio,RawAttribute.raw_row_id)).all(): raw_by_scope.setdefault((str(item.prj_id),str(item.portfolio)),[]).append(item)
        for item in self.db.scalars(select(StagingAttributeMaster).where(StagingAttributeMaster.prj_id.in_(prj_ids))).all(): masters[str(item.prj_id)]=item
        stmt=(select(StagingBusinessRule,StagingAttributeDisplay).join(StagingAttributeDisplay,StagingAttributeDisplay.scope_id==StagingBusinessRule.scope_id).where(StagingBusinessRule.prj_id.in_(prj_ids)).order_by(StagingBusinessRule.prj_id,StagingBusinessRule.port_ref_id,StagingAttributeDisplay.display_order,StagingBusinessRule.scope_id))
        for rule,display in self.db.execute(stmt).all(): rules_by_scope.setdefault((str(rule.prj_id),int(rule.port_ref_id)),[]).append((rule,display))
        return {"raw":raw_by_scope,"masters":masters,"rules":rules_by_scope}

    @staticmethod
    def _combined_key_match(rule: Any, display: Any, row: dict[str, Any]) -> bool:
        return (rule.source_abbr_name==row["source_abbr_name"] and int(display.display_order)==int(row["display_order"])
                and display.section==row["section"] and display.subsection==row["subsection"] and display.report_type==row.get("report_type","NA"))

    @staticmethod
    def _assign_business(rule: Any, row: dict[str, Any]) -> None:
        for incoming, physical in BUSINESS_INPUT_MAP.items(): setattr(rule,physical,row.get(incoming))

    @staticmethod
    def _assign_display(display: Any, row: dict[str, Any]) -> None:
        for incoming, physical in DISPLAY_INPUT_MAP.items(): setattr(display,physical,row.get(incoming))

    def upsert_raw_cached(self, row, user, source_operation, cache, strict_key: bool = False):
        key=(str(row["prj_id"]),str(row["portfolio"])); existing=cache.setdefault(key,[])
        target=next((x for x in existing if int(x.display_order)==int(row["display_order"]) and x.section==row["section"] and x.sub_section==row["sub_section"] and x.report_type==row.get("report_type","NA")),None)
        if target is None and len(existing)==1 and not strict_key and not source_operation.upper().startswith("BULK_"):target=existing[0]
        if target is None and len(existing)>1 and not strict_key and not source_operation.upper().startswith("BULK_"):raise ValueError(f"Cannot unambiguously update raw row for {row['prj_id']} / {row['portfolio']}; multiple raw rows exist and the edited key no longer matches.")
        if target:
            before=model_dict(target)
            for field,value in row.items():setattr(target,field,value)
            target.is_active=True;target.updated_at=datetime.utcnow();target.updated_by=user
            if target.raw_row_id is not None:self.audit("dbo","raw_prj_attribute_new_test",str(target.raw_row_id),"UPDATE",before,model_dict(target),user,source_operation)
            return None
        target=RawAttribute(**row,is_active=True,created_by=user,updated_by=user);self.db.add(target);existing.append(target)
        return {"schema":"dbo","table":"raw_prj_attribute_new_test","target":target,"key_attr":"raw_row_id","user":user,"source_operation":source_operation}

    def upsert_staging_master_cached(self,row,user,source_operation,cache):
        target=cache.get(str(row["prj_id"]));fields=("prj_attribute_name","prj_attribute_definition","prj_physical_attribute_name","where_in_financial_statement","is_active")
        if target:
            before=model_dict(target)
            for f in fields:setattr(target,f,row.get(f))
            target.updated_at=datetime.utcnow();target.updated_by=user;self.audit("stg","prj_attribute_master_new_test",str(row["prj_id"]),"UPDATE",before,model_dict(target),user,source_operation);return
        target=StagingAttributeMaster(**{f:row.get(f) for f in ("prj_id",*fields)},created_by=user,updated_by=user);self.db.add(target);cache[str(row["prj_id"])]=target;self.audit("stg","prj_attribute_master_new_test",str(row["prj_id"]),"INSERT",None,model_dict(target),user,source_operation)

    def _new_staging_pair(self,row,user):
        rule=StagingBusinessRule(created_by=user,updated_by=user);self._assign_business(rule,row)
        display=StagingAttributeDisplay(created_by=user,updated_by=user);self._assign_display(display,row);rule.display=display
        return rule,display

    def upsert_staging_rule_cached(self, row, user, source_operation, cache, strict_key: bool = False):
        key=(str(row["prj_id"]),int(row["port_ref_id"]));existing=cache.setdefault(key,[])
        pair=next(((r,d) for r,d in existing if self._combined_key_match(r,d,row)),None)
        if pair is None and len(existing)==1 and not strict_key and not source_operation.upper().startswith("BULK_"):pair=existing[0]
        if pair is None and len(existing)>1 and not strict_key and not source_operation.upper().startswith("BULK_"):raise ValueError(f"Cannot unambiguously update staging rule for {row['prj_id']} / port_ref_id {row['port_ref_id']}; multiple staged rules exist and the edited key no longer matches.")
        if pair:
            rule,display=pair;before_rule=model_dict(rule);before_display=model_dict(display);self._assign_business(rule,row);self._assign_display(display,row);now=datetime.utcnow();rule.updated_at=display.updated_at=now;rule.updated_by=display.updated_by=user
            if rule.scope_id is not None:
                self.audit("stg","prj_attribute_business_rules_new_test",str(rule.scope_id),"UPDATE",before_rule,model_dict(rule),user,source_operation)
                self.audit("stg","prj_attribute_display_test",str(display.display_id),"UPDATE",before_display,model_dict(display),user,source_operation)
            return None
        rule,display=self._new_staging_pair(row,user);self.db.add(rule);existing.append((rule,display))
        return {"targets":[
            {"schema":"stg","table":"prj_attribute_business_rules_new_test","target":rule,"key_attr":"scope_id"},
            {"schema":"stg","table":"prj_attribute_display_test","target":display,"key_attr":"display_id"},
        ],"user":user,"source_operation":source_operation}

    def upsert_raw(self, row, user, source_operation, defer_insert_audit=False, strict_key: bool = False):
        existing=self.active_raw_for_scope(row["prj_id"],row["portfolio"]);target=next((x for x in existing if int(x.display_order)==int(row["display_order"]) and x.section==row["section"] and x.sub_section==row["sub_section"] and x.report_type==row.get("report_type","NA")),None)
        if target is None and len(existing)==1 and not strict_key and not source_operation.upper().startswith("BULK_"):target=existing[0]
        if target is None and len(existing)>1 and not strict_key and not source_operation.upper().startswith("BULK_"):raise ValueError(f"Cannot unambiguously update raw row for {row['prj_id']} / {row['portfolio']}; multiple raw rows exist and the edited key no longer matches.")
        if target:
            before=model_dict(target)
            for k,v in row.items():setattr(target,k,v)
            target.is_active=True;target.updated_at=datetime.utcnow();target.updated_by=user;self.audit("dbo","raw_prj_attribute_new_test",str(target.raw_row_id),"UPDATE",before,model_dict(target),user,source_operation);return None
        target=RawAttribute(**row,is_active=True,created_by=user,updated_by=user);self.db.add(target)
        if defer_insert_audit:return {"schema":"dbo","table":"raw_prj_attribute_new_test","target":target,"key_attr":"raw_row_id","user":user,"source_operation":source_operation}
        self.db.flush();self.audit("dbo","raw_prj_attribute_new_test",str(target.raw_row_id),"INSERT",None,model_dict(target),user,source_operation);return None

    def upsert_staging_master(self,row,user,source_operation):
        target=self.db.get(StagingAttributeMaster,row["prj_id"]);fields=("prj_attribute_name","prj_attribute_definition","prj_physical_attribute_name","where_in_financial_statement","is_active")
        if target:
            before=model_dict(target)
            for k in fields:setattr(target,k,row.get(k))
            target.updated_at=datetime.utcnow();target.updated_by=user;self.audit("stg","prj_attribute_master_new_test",row["prj_id"],"UPDATE",before,model_dict(target),user,source_operation)
        else:
            target=StagingAttributeMaster(**{k:row[k] for k in ("prj_id",*fields)},created_by=user,updated_by=user);self.db.add(target);self.audit("stg","prj_attribute_master_new_test",row["prj_id"],"INSERT",None,model_dict(target),user,source_operation)

    def upsert_staging_rule(self, row, user, source_operation, defer_insert_audit=False, strict_key: bool = False):
        stmt=(select(StagingBusinessRule,StagingAttributeDisplay).join(StagingAttributeDisplay,StagingAttributeDisplay.scope_id==StagingBusinessRule.scope_id).where(StagingBusinessRule.prj_id==row["prj_id"],StagingBusinessRule.port_ref_id==row["port_ref_id"]).order_by(StagingBusinessRule.scope_id))
        existing=list(self.db.execute(stmt).all());pair=next(((r,d) for r,d in existing if self._combined_key_match(r,d,row)),None)
        if pair is None and len(existing)==1 and not strict_key and not source_operation.upper().startswith("BULK_"):pair=existing[0]
        if pair is None and len(existing)>1 and not strict_key and not source_operation.upper().startswith("BULK_"):raise ValueError(f"Cannot unambiguously update staging rule for {row['prj_id']} / port_ref_id {row['port_ref_id']}; multiple staged rules exist and the edited key no longer matches.")
        if pair:
            rule,display=pair;before_rule=model_dict(rule);before_display=model_dict(display);self._assign_business(rule,row);self._assign_display(display,row);now=datetime.utcnow();rule.updated_at=display.updated_at=now;rule.updated_by=display.updated_by=user
            self.audit("stg","prj_attribute_business_rules_new_test",str(rule.scope_id),"UPDATE",before_rule,model_dict(rule),user,source_operation);self.audit("stg","prj_attribute_display_test",str(display.display_id),"UPDATE",before_display,model_dict(display),user,source_operation);return None
        rule,display=self._new_staging_pair(row,user);self.db.add(rule)
        if defer_insert_audit:return {"targets":[{"schema":"stg","table":"prj_attribute_business_rules_new_test","target":rule,"key_attr":"scope_id"},{"schema":"stg","table":"prj_attribute_display_test","target":display,"key_attr":"display_id"}],"user":user,"source_operation":source_operation}
        self.db.flush();self.audit("stg","prj_attribute_business_rules_new_test",str(rule.scope_id),"INSERT",None,model_dict(rule),user,source_operation);self.audit("stg","prj_attribute_display_test",str(display.display_id),"INSERT",None,model_dict(display),user,source_operation);return None

    def emit_deferred_insert_audits(self,items):
        if not items:return
        self.db.flush()
        for item in items:
            targets=item.get("targets") or [{"schema":item["schema"],"table":item["table"],"target":item["target"],"key_attr":item["key_attr"]}]
            for entry in targets:self.audit(entry["schema"],entry["table"],str(getattr(entry["target"],entry["key_attr"])),"INSERT",None,model_dict(entry["target"]),item["user"],item["source_operation"])

    def stage_delete_attribute(self,prj_id,active,user,source_operation):
        base=self.get_master(prj_id,"stg") or self.get_master(prj_id,"dbo")
        if not base:raise KeyError(prj_id)
        self.upsert_staging_master({"prj_id":base["prj_id"],"prj_attribute_name":base["prj_attribute_name"],"prj_attribute_definition":base.get("prj_attribute_definition"),"prj_physical_attribute_name":base["prj_physical_attribute_name"],"where_in_financial_statement":base.get("where_in_financial_statement") or "NA","is_active":bool(active)},user,source_operation)
        rules=self.get_rules(prj_id,"stg") or self.get_rules(prj_id,"dbo")
        keys=("prj_id","port_ref_id","source_abbr_name","editable","symbol","mapping_type","calculation_logic","prj_attribute_definition","prj_attribute_description","segment","report_type","tech_logic","display_order","display_name","section","subsection","prompt_description","examples")
        for item in rules:self.upsert_staging_rule({k:item.get(k) for k in keys},user,source_operation)
        for raw in self.db.scalars(select(RawAttribute).where(RawAttribute.prj_id==prj_id)).all():
            before=model_dict(raw);raw.is_active=bool(active);raw.updated_at=datetime.utcnow();raw.updated_by=user;self.audit("dbo","raw_prj_attribute_new_test",str(raw.raw_row_id),"REACTIVATE" if active else "SOFT_DELETE",before,model_dict(raw),user,source_operation)

    def staging_prj_ids(self):return list(self.db.scalars(select(StagingAttributeMaster.prj_id).order_by(StagingAttributeMaster.prj_id)).all())

    def clear_staging(self, prj_ids=None, user: str = "sysuser", source_operation: str = "WORKFLOW"):
        display_stmt = select(StagingAttributeDisplay)
        business_stmt = select(StagingBusinessRule)
        master_stmt = select(StagingAttributeMaster)
        if prj_ids:
            scope_ids = select(StagingBusinessRule.scope_id).where(StagingBusinessRule.prj_id.in_(prj_ids))
            display_stmt = display_stmt.where(StagingAttributeDisplay.scope_id.in_(scope_ids))
            business_stmt = business_stmt.where(StagingBusinessRule.prj_id.in_(prj_ids))
            master_stmt = master_stmt.where(StagingAttributeMaster.prj_id.in_(prj_ids))
        for row in self.db.scalars(display_stmt).all():
            self.scd2_version("stg", "prj_attribute_display_test", str(row.display_id), "DELETE", model_dict(row), None, user, source_operation)
        for row in self.db.scalars(business_stmt).all():
            self.scd2_version("stg", "prj_attribute_business_rules_new_test", str(row.scope_id), "DELETE", model_dict(row), None, user, source_operation)
        for row in self.db.scalars(master_stmt).all():
            self.scd2_version("stg", "prj_attribute_master_new_test", str(row.prj_id), "DELETE", model_dict(row), None, user, source_operation)
        if prj_ids:
            scope_ids=select(StagingBusinessRule.scope_id).where(StagingBusinessRule.prj_id.in_(prj_ids));self.db.execute(delete(StagingAttributeDisplay).where(StagingAttributeDisplay.scope_id.in_(scope_ids)));self.db.execute(delete(StagingBusinessRule).where(StagingBusinessRule.prj_id.in_(prj_ids)));self.db.execute(delete(StagingAttributeMaster).where(StagingAttributeMaster.prj_id.in_(prj_ids)))
        else:self.db.execute(delete(StagingAttributeDisplay));self.db.execute(delete(StagingBusinessRule));self.db.execute(delete(StagingAttributeMaster))

    def clear_raw_and_staging_for_replace(self,user):
        raw_count=int(self.db.execute(select(func.count()).select_from(RawAttribute)).scalar_one());stg_count=int(self.db.execute(select(func.count()).select_from(StagingAttributeMaster)).scalar_one());self.audit("dbo","raw_prj_attribute_new_test","*","REPLACE_CLEAR",{"row_count":raw_count},None,user,"BULK_REPLACE");self.audit("stg","prj_attribute_master_new_test","*","REPLACE_CLEAR",{"row_count":stg_count},None,user,"BULK_REPLACE");self.scd2_close_table("stg","prj_attribute_display_test");self.scd2_close_table("stg","prj_attribute_business_rules_new_test");self.scd2_close_table("stg","prj_attribute_master_new_test");self.scd2_close_table("dbo","raw_prj_attribute_new_test");self.db.execute(delete(StagingAttributeDisplay));self.db.execute(delete(StagingBusinessRule));self.db.execute(delete(StagingAttributeMaster));self.db.execute(delete(RawAttribute))

    def audit_rows(self,filters,limit=2000):
        stmt=select(AuditTable);conditions=[]
        for field in ("table_name","record_key","action","performed_by","source_operation"):
            value=getattr(filters,field,None)
            if value:conditions.append(getattr(AuditTable,field).ilike(f"%{value}%"))
        if getattr(filters,"search",None):
            term=f"%{filters.search}%";conditions.append(or_(AuditTable.table_name.ilike(term),AuditTable.record_key.ilike(term),AuditTable.before_value.ilike(term),AuditTable.after_value.ilike(term)))
        if conditions:stmt=stmt.where(and_(*conditions))
        stmt=stmt.order_by(AuditTable.performed_at.desc(),AuditTable.audit_id.desc()).limit(limit);return [model_dict(x) for x in self.db.scalars(stmt).all()]
