-- PostgreSQL migration: add Report Type to raw/staging/final business-rule storage
-- and include it in the unique scope key. Safe to rerun.
BEGIN;

ALTER TABLE dbo.raw_prj_attribute_new_test
    ADD COLUMN IF NOT EXISTS report_type varchar(120) NOT NULL DEFAULT 'NA';
ALTER TABLE stg.prj_attribute_business_rules_new_test
    ADD COLUMN IF NOT EXISTS report_type varchar(120) NOT NULL DEFAULT 'NA';
ALTER TABLE dbo.prj_attribute_business_rules_new_test
    ADD COLUMN IF NOT EXISTS report_type varchar(120) NOT NULL DEFAULT 'NA';

ALTER TABLE stg.prj_attribute_business_rules_new_test
    DROP CONSTRAINT IF EXISTS uq_stg_new_business_rule_key;
ALTER TABLE stg.prj_attribute_business_rules_new_test
    ADD CONSTRAINT uq_stg_new_business_rule_key
    UNIQUE(prj_id, port_ref_id, source_abbr_name, display_order, section, subsection, report_type);

ALTER TABLE dbo.prj_attribute_business_rules_new_test
    DROP CONSTRAINT IF EXISTS uq_new_business_rule_key;
ALTER TABLE dbo.prj_attribute_business_rules_new_test
    ADD CONSTRAINT uq_new_business_rule_key
    UNIQUE(prj_id, port_ref_id, source_abbr_name, display_order, section, subsection, report_type);

COMMIT;
