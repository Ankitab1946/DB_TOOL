from DataDictionaryAdminApp.model.entities import (
    AttributeBusinessRule, AttributeDisplay, AttributeMaster, AuditTable, PortfolioReference, RawAttribute,
    StagingAttributeDisplay, StagingAttributeMaster, StagingBusinessRule,
)


def test_entity_schema_alignment():
    assert RawAttribute.__table__.fullname == "dbo.raw_prj_attribute_new_test"
    assert PortfolioReference.__table__.fullname == "dbo.prj_portfolio_reference_new_test"
    assert AuditTable.__table__.fullname == "dbo.audit_table_new_test"
    assert StagingAttributeMaster.__table__.fullname == "stg.prj_attribute_master_new_test"
    assert StagingBusinessRule.__table__.fullname == "stg.prj_attribute_business_rules_new_test"
    assert StagingAttributeDisplay.__table__.fullname == "stg.prj_attribute_display_test"
    assert AttributeMaster.__table__.fullname == "dbo.prj_attribute_master_new_test"
    assert AttributeBusinessRule.__table__.fullname == "dbo.prj_attribute_business_rules_new_test"
    assert AttributeDisplay.__table__.fullname == "dbo.prj_attribute_display_test"


def test_business_rule_columns_are_split_and_aligned():
    expected = {
        "scope_id", "prj_id", "port_ref_id", "source_abbr_name", "prompt_description", "examples_for_llm",
        "editable", "data_type", "attribute_type", "business_logic", "calculation_logic",
        "created_at", "updated_at", "created_by", "updated_by",
    }
    assert expected == set(AttributeBusinessRule.__table__.columns.keys())
    assert expected == set(StagingBusinessRule.__table__.columns.keys())


def test_display_columns_are_split_and_aligned():
    expected = {
        "display_id", "scope_id", "display_order", "prj_id", "display_name", "section", "subsection",
        "prj_attribute_definition", "prj_attribute_description", "segment", "report_type",
        "created_at", "updated_at", "created_by", "updated_by",
    }
    assert expected == set(AttributeDisplay.__table__.columns.keys())
    assert expected == set(StagingAttributeDisplay.__table__.columns.keys())
