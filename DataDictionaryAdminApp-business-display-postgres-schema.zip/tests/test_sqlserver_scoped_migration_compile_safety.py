from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MIGRATION = ROOT / "src/DataDictionaryAdminApp/sql/003_add_scoped_definition_segment.sql"
VALIDATE = ROOT / "src/DataDictionaryAdminApp/sql/002_validate_schema.sql"


def test_scoped_migration_uses_dynamic_sql_after_add_column():
    text = MIGRATION.read_text(encoding="utf-8")
    # SQL Server must compile the backfill after newly-added target columns exist.
    assert "EXEC sys.sp_executesql @sql" in text
    assert "ALTER TABLE stg.prj_attribute_business_rules_new_test ADD prj_attribute_definition" in text
    assert "ALTER TABLE dbo.prj_attribute_business_rules_new_test ADD prj_attribute_definition" in text
    assert "UPDATE r\n       SET r.prj_attribute_definition" not in text


def test_scoped_migration_is_idempotent_and_accepts_migration_aliases():
    text = MIGRATION.read_text(encoding="utf-8")
    assert "COL_LENGTH(N'stg.prj_attribute_business_rules_new_test', N'prj_attribute_definition') IS NULL" in text
    assert "cfv_attribute_definition" in text
    assert "attribute_definition" in text
    assert "Migration completed successfully" in text


def test_sqlserver_validator_returns_detailed_missing_rows():
    text = VALIDATE.read_text(encoding="utf-8")
    assert "object_type" in text
    assert "fix_hint" in text
    assert "Run 003_add_scoped_definition_segment.sql." in text
    assert "Schema validation passed" in text
