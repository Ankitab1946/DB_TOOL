from pathlib import Path

from DataDictionaryAdminApp.api.schemas_api import PortfolioUpsert
from DataDictionaryAdminApp.model.entities import PortfolioReference, PostgresPortfolioReference

ROOT = Path(__file__).resolve().parents[1]


def test_portfolio_runtime_contract_uses_remarks():
    assert "remarks" in PortfolioReference.__table__.c
    assert "remark" not in PortfolioReference.__table__.c
    assert "remarks" in PostgresPortfolioReference.__table__.c
    assert "remark" not in PostgresPortfolioReference.__table__.c
    payload = PortfolioUpsert(portfolio_name="FI", sector_name="Banks", remarks="Bank scope")
    assert payload.remarks == "Bank scope"
    assert "remark" not in payload.model_dump()
    legacy = PortfolioUpsert(portfolio_name="FI", sector_name="Banks", remark="Legacy API value")
    assert legacy.remarks == "Legacy API value"
    assert legacy.model_dump()["remarks"] == "Legacy API value"


def test_sqlserver_007_renames_remark_to_remarks_and_validator_requires_new_name():
    migration = (ROOT / "src/DataDictionaryAdminApp/sql/007_rename_portfolio_remark_to_remarks.sql").read_text().lower()
    validator = (ROOT / "src/DataDictionaryAdminApp/sql/002_validate_schema.sql").read_text().lower()
    fresh = (ROOT / "src/DataDictionaryAdminApp/sql/001_create_tables.sql").read_text().lower()
    assert "sp_rename" in migration
    assert "prj_portfolio_reference_new_test.remark" in migration
    assert "n'remarks'" in migration
    assert "'prj_portfolio_reference_new_test','remarks'" in validator
    assert "remarks nvarchar(500)" in fresh


def test_postgres_007_renames_remark_to_remarks_and_validator_requires_new_name():
    migration = (ROOT / "src/DataDictionaryAdminApp/sql/postgres/007_rename_portfolio_remark_to_remarks.sql").read_text().lower()
    validator = (ROOT / "src/DataDictionaryAdminApp/sql/postgres/002_validate_schema.sql").read_text().lower()
    fresh = (ROOT / "src/DataDictionaryAdminApp/sql/postgres/001_create_tables.sql").read_text().lower()
    assert "rename column remark to remarks" in migration
    assert "prj_dbd.prj_portfolio_reference" in migration
    assert "('prj_dbd','prj_portfolio_reference','remarks')" in validator
    assert "remarks varchar(500)" in fresh
