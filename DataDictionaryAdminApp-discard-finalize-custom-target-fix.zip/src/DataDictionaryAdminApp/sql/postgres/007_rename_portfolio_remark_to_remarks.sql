/* PostgreSQL existing-database migration: rename Portfolio Reference column
   prj_dbd.prj_portfolio_reference.remark -> remarks

   Safe/idempotent behavior:
   - Renames only when legacy remark exists and remarks does not.
   - Does nothing when remarks already exists.
   - Fails if both columns exist, because automatic merge/drop could lose data.
   - Does not delete or recreate the table or portfolio rows.
*/
BEGIN;

DO $$
DECLARE
  has_remark boolean;
  has_remarks boolean;
BEGIN
  IF to_regclass('prj_dbd.prj_portfolio_reference') IS NULL THEN
    RAISE EXCEPTION 'Required table prj_dbd.prj_portfolio_reference does not exist.';
  END IF;

  SELECT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='prj_dbd' AND table_name='prj_portfolio_reference' AND column_name='remark'
  ) INTO has_remark;

  SELECT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='prj_dbd' AND table_name='prj_portfolio_reference' AND column_name='remarks'
  ) INTO has_remarks;

  IF has_remark AND has_remarks THEN
    RAISE EXCEPTION 'Both remark and remarks columns exist on prj_dbd.prj_portfolio_reference. Resolve the duplicate columns manually before running migration 007.';
  ELSIF has_remark AND NOT has_remarks THEN
    ALTER TABLE prj_dbd.prj_portfolio_reference RENAME COLUMN remark TO remarks;
  ELSIF NOT has_remarks THEN
    RAISE EXCEPTION 'Neither remark nor remarks exists on prj_dbd.prj_portfolio_reference.';
  END IF;
END $$;

COMMIT;

SELECT 'Migration 007 completed successfully' AS migration_status,
       'prj_dbd.prj_portfolio_reference.remarks' AS canonical_column;
