from pathlib import Path

def test_ui_has_no_database_or_api_server_packages():
    root = Path(__file__).parents[1] / "src" / "DataDictionaryAdminApp"
    assert not (root / "model").exists()
    assert not (root / "repositories").exists()
    assert not (root / "service").exists()
    assert not (root / "api").exists()
    source = (root / "streamlit_app.py").read_text()
    assert "DataDictionaryAdminApp.core.database" not in source
    assert "DIRECT_FALLBACK" not in source
