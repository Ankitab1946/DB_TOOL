# Validation Results

Validation date: 2026-08-17

## Fixes in this build

1. Bulk-upload Portfolio control now auto-detects `Insurance` from sheet names containing `Insurance` and `Banks` from sheet names containing `Bank`; the dropdown can be used as a manual override.
2. Per-sheet `Data starts at row (1-based)` allows secondary/tertiary header rows to be skipped independently of the selected header row.
3. Database raw-load modes are `MERGE`, `INSERT_ONLY`, and `REPLACE`.
4. `INSERT_ONLY` skips PRJ IDs already present in raw, staging, or final storage and does not overwrite them.
5. `View Soft Deleted Records` displays finalized inactive attributes and provides a Reactivate action.
6. SQLAlchemy boolean predicates were made SQL Server/PostgreSQL dialect-safe (`= 1` for SQL Server BIT rather than invalid `IS 1`).

## Automated validation

- `python -m compileall -q src tests`: PASS
- `pytest -q`: 29 tests PASS
- FastAPI OpenAPI application load: PASS
- API paths: 27
- SQL Server unsafe `.is_(True)` / `.is_(False)` runtime scan: PASS (none found)
- SQL Server boolean-dialect contract test: PASS
- PostgreSQL boolean-dialect contract test: PASS
- Excel data-start-row test with extra header rows: PASS
- Portfolio sheet-name detection tests for `Insurance Attribute` and `Bank Attribute`: PASS
- UI contract tests for Insert-Only, data-start row, soft-deleted view, database/role controls: PASS

No physical database schema/table changes are required for this patch.
