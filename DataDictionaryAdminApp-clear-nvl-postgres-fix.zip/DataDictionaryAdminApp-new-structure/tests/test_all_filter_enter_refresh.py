from pathlib import Path


APP = Path(__file__).resolve().parents[1] / "src" / "DataDictionaryAdminApp" / "streamlit_app.py"


def test_all_view_latest_filters_use_shared_refresh_callback():
    source = APP.read_text(encoding="utf-8")

    assert "def request_filter_submit()" in source
    assert '"filter_submit_requested": False' in source
    assert 'st.session_state["filter_submit_requested"] = True' in source

    # Text filters refresh when Enter commits the value.
    for key in (
        "view_attribute_name_filter",
        "view_attribute_definition_filter",
        "view_search_filter",
    ):
        anchor = f'key="{key}"'
        start = source.index(anchor)
        block = source[start:start + 260]
        assert "on_change=request_filter_submit" in block

    # Selection/paging filters refresh as soon as their selection/value is committed.
    for key in (
        "view_portfolio_filter",
        "view_source_filter",
        "view_section_filter",
        "view_subsection_filter",
        "view_overlapped_filter",
        "view_include_inactive_filter",
        "view_page_size_filter",
        "view_page_number_filter",
    ):
        anchor = f'key="{key}"'
        start = source.index(anchor)
        block = source[start:start + 260]
        assert "on_change=request_filter_submit" in block


def test_prj_filter_remains_enter_compatible_and_view_latest_button_is_retained():
    source = APP.read_text(encoding="utf-8")
    assert 'key="view_prj_id_filter"' in source
    assert "on_change=request_prj_filter_submit" in source
    assert "request_filter_submit()" in source
    assert 'button("View Latest", width="stretch")' in source
    assert 'api("POST", "/data-dictionary/filter-page", json=payload)' in source
