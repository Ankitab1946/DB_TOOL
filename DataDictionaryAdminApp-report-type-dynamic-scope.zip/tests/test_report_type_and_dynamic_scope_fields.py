from pathlib import Path

from DataDictionaryAdminApp.api.schemas_api import AttributeUpsert
from DataDictionaryAdminApp.model.entities import RawAttribute, StagingBusinessRule, AttributeBusinessRule
from DataDictionaryAdminApp.service.data_dictionary_service import DataDictionaryService
from DataDictionaryAdminApp.utils.normalizers import detect_column_mapping


def _service_with_fake_repo():
    class FakeRepo:
        def __init__(self):
            self.raw_rows = []
            self.rules = []
            self.master = None

        def portfolio_ref(self, value):
            return {"label": "FI Banks", "port_ref_id": 1, "portfolio_name": "FI", "sector_name": "Banks"}

        def physical_name_for_prj(self, prj_id): return None
        def physical_name_exists(self, name, exclude_prj_id=None): return False
        def available_physical_name(self, base_name, exclude_prj_id=None): return base_name
        def original_mapping_type(self, prj_id): return None
        def source_code(self, source_name, source_abbr_name=None): return source_abbr_name or "SNPAR"
        def upsert_raw(self, row, user, source_operation, defer_insert_audit=False, strict_key=False):
            self.raw_rows.append(dict(row)); return None
        def upsert_staging_master(self, row, user, source_operation): self.master = dict(row)
        def upsert_staging_rule(self, row, user, source_operation, defer_insert_audit=False, strict_key=False):
            self.rules.append(dict(row)); return None
        def emit_deferred_insert_audits(self, items): return None

    service = DataDictionaryService(db=None)
    repo = FakeRepo()
    service.repo = repo
    return service, repo


def test_report_type_and_all_requested_fields_expand_positionally():
    service, repo = _service_with_fake_repo()
    payload = AttributeUpsert(
        prj_id="CFV700",
        portfolio="FI Banks",
        source_abbr_name="SNPAR",
        prj_attribute_name="Scoped Complete Test",
        section="Total|Liabilities",
        sub_section="Current|Current2",
        segment="Seg1|Seg2",
        attribute_definition="Def1|Def2",
        attribute_description="Desc1|Desc2",
        calculation_logic="A(PRJ1)+B(PRJ2)|C(PRJ3)-D(PRJ4)",
        report_type="Annual|Quarterly",
        display_order="10|20",
        tech_logic="PRJ1+PRJ2|PRJ3-PRJ4",
        examples="Example1|Example2",
        display_name="Display1|Display2",
        data_type="Amount",
        calculated_or_reported="Reported",
    )
    result = service.stage_attribute_pending(payload, "tester", "UI_CREATE")
    assert result["raw_rows_staged"] == 2
    assert result["business_rule_rows_staged"] == 2
    assert [(r["section"], r["sub_section"], r["report_type"], r["display_order"], r["calculation_logic"], r["tech_logic"], r["display_name"])
            for r in repo.raw_rows] == [
        ("Total", "Current", "Annual", 10, "A(PRJ1)+B(PRJ2)", "PRJ1+PRJ2", "Display1"),
        ("Liabilities", "Current2", "Quarterly", 20, "C(PRJ3)-D(PRJ4)", "PRJ3-PRJ4", "Display2"),
    ]
    assert [(r["section"], r["subsection"], r["report_type"], r["display_order"], r["calculation_logic"], r["tech_logic"], r["examples"], r["display_name"])
            for r in repo.rules] == [
        ("Total", "Current", "Annual", 10, "A(PRJ1)+B(PRJ2)", "PRJ1+PRJ2", "Example1", "Display1"),
        ("Liabilities", "Current2", "Quarterly", 20, "C(PRJ3)-D(PRJ4)", "PRJ3-PRJ4", "Example2", "Display2"),
    ]


def test_report_type_is_part_of_orm_unique_scope_key_and_raw_contract():
    assert "report_type" in RawAttribute.__table__.columns
    for model in (StagingBusinessRule, AttributeBusinessRule):
        unique = next(c for c in model.__table__.constraints if c.__class__.__name__ == "UniqueConstraint")
        names = [column.name for column in unique.columns]
        assert names == ["prj_id", "port_ref_id", "source_abbr_name", "display_order", "section", "subsection", "report_type"]


def test_master_dictionary_detects_report_type_and_examples():
    mapping = detect_column_mapping(["PRJID", "Report Type", "Examples"])
    assert mapping["report_type"] == "Report Type"
    assert mapping["examples"] == "Examples"


def test_existing_db_migrations_add_report_type_and_rebuild_scope_key():
    sql_server = Path("src/DataDictionaryAdminApp/sql/004_add_report_type_scope_fields.sql").read_text(encoding="utf-8")
    postgres = Path("src/DataDictionaryAdminApp/sql/postgres/004_add_report_type_scope_fields.sql").read_text(encoding="utf-8")
    for sql in (sql_server, postgres):
        lowered = sql.lower()
        assert "report_type" in lowered
        assert "unique(prj_id, port_ref_id, source_abbr_name, display_order, section, subsection, report_type)" in lowered.replace("\n", " ").replace("    ", " ") or "report_type" in lowered


def test_ui_contains_dynamic_scope_inputs_for_requested_fields():
    source = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
    for key in (
        'key=f"{prefix}_calc_{pair_index}"',
        'key=f"{prefix}_report_type_{pair_index}"',
        'key=f"{prefix}_order_{pair_index}"',
        'tech_key = f"{prefix}_tech_{pair_index}"',
        'key=f"{prefix}_examples_{pair_index}"',
        'key=f"{prefix}_display_{pair_index}"',
    ):
        assert key in source
