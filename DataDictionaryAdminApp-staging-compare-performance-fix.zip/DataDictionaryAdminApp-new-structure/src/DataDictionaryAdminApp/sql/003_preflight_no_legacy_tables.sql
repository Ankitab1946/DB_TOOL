/* Informational only: this v2 application does not read/write the old *_test tables. */
SELECT name AS legacy_table_present
FROM sys.tables
WHERE name IN (
  'prj_attribute_master_test',
  'prj_portfolio_reference_test',
  'prj_attribute_portfolio_scope_test',
  'prj_attribute_business_rules_test',
  'prj_scanning_prompt_reference_test',
  'audit_table_test'
)
ORDER BY name;
