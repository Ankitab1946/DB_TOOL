from pathlib import Path

SOURCE = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")


def test_create_and_edit_modals_use_native_viewport_centered_dialog():
    assert '@st.dialog("Create New Attribute", width="large")' in SOURCE
    assert '@st.dialog("Edit Attribute", width="large")' in SOURCE
    assert '[data-testid="stDialog"] [role="dialog"]' in SOURCE
    assert 'margin: auto !important;' in SOURCE


def test_x_close_has_no_persistent_open_flag_to_reopen_dialog():
    create_block = SOURCE.split('if create_col.button("Create New Attribute"', 1)[1].split('if deleted_col.button', 1)[0]
    edit_block = SOURCE.split('if action1.button("Edit"', 1)[1].split('if action2.button', 1)[0]
    assert 'show_create' not in create_block
    assert 'show_edit' not in edit_block
    assert 'create_modal.open()' not in SOURCE
    assert 'edit_modal.open()' not in SOURCE


def test_programmatic_close_reruns_after_state_cleanup():
    assert 'if st.button("Close", key="create_close", width="stretch"):' in SOURCE
    assert 'if st.button("Close", key="edit_close", width="stretch"):' in SOURCE
    assert '_clear_create_dialog_state()' in SOURCE
    assert SOURCE.count('st.rerun()') >= 2
