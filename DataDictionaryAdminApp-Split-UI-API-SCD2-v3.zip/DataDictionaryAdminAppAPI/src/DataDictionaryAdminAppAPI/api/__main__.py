import uvicorn

if __name__ == "__main__":
    uvicorn.run("DataDictionaryAdminAppAPI.api.swagger_app:app", host="0.0.0.0", port=8503, reload=False)
