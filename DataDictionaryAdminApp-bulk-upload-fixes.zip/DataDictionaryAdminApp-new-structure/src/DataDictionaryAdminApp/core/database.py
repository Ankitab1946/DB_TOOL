"""SQLAlchemy session factory supporting SQL Server and PostgreSQL."""
from __future__ import annotations

from functools import lru_cache

from fastapi import HTTPException, Request
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from DataDictionaryAdminApp.config import get_settings


class Base(DeclarativeBase):
    pass


@lru_cache(maxsize=16)
def _session_factory(environment: str, db_type: str):
    settings = get_settings()
    cfg = settings.database_config(environment, db_type)
    if not cfg["enabled"]:
        raise RuntimeError(f"{cfg['db_type']} database access is disabled for environment {cfg['environment']}.")

    connect_args = {}
    if cfg["db_type"] == "SQLSERVER":
        connect_args["timeout"] = settings.db_connect_timeout_seconds
    else:
        connect_args["connect_timeout"] = settings.db_connect_timeout_seconds

    engine_kwargs = {
        "future": True,
        "pool_pre_ping": settings.sqlalchemy_pool_pre_ping,
        "pool_use_lifo": True,
        "pool_size": settings.sqlalchemy_pool_size,
        "max_overflow": settings.sqlalchemy_max_overflow,
        "pool_timeout": settings.sqlalchemy_pool_timeout_seconds,
        "pool_recycle": settings.sqlalchemy_pool_recycle_seconds,
        "connect_args": connect_args,
    }
    if cfg["db_type"] == "SQLSERVER":
        engine_kwargs["fast_executemany"] = True

    engine = create_engine(
        settings.sqlalchemy_url(cfg["environment"], cfg["db_type"]),
        **engine_kwargs,
    )
    return sessionmaker(bind=engine, autocommit=False, autoflush=False, expire_on_commit=False)


def get_db(request: Request):
    settings = get_settings()
    environment = settings.resolve_environment(
        request.headers.get("X-App-Environment") or request.query_params.get("environment")
    )
    db_type = settings.resolve_db_type(request.headers.get("X-DB-Type") or request.query_params.get("db_type"))
    try:
        session_local = _session_factory(environment, db_type)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    db = session_local()
    try:
        yield db
    finally:
        db.close()
