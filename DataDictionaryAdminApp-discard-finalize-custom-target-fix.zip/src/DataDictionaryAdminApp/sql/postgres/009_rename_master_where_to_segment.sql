/* Existing PostgreSQL databases: rename master column
   where_in_financial_statement -> segment in staging and final master tables.
   Idempotent; no data is deleted. */
BEGIN;

DO $$
DECLARE
    target_schema text;
    target_table text := 'prj_attribute_master_new_test';
    has_old boolean;
    has_new boolean;
BEGIN
    FOREACH target_schema IN ARRAY ARRAY['prj_stage','prj_dbd']
    LOOP
        IF to_regclass(format('%I.%I', target_schema, target_table)) IS NULL THEN
            RAISE EXCEPTION 'Required table %.% does not exist.', target_schema, target_table;
        END IF;

        SELECT EXISTS (
            SELECT 1 FROM information_schema.columns
            WHERE table_schema=target_schema AND table_name=target_table
              AND column_name='where_in_financial_statement'
        ) INTO has_old;
        SELECT EXISTS (
            SELECT 1 FROM information_schema.columns
            WHERE table_schema=target_schema AND table_name=target_table
              AND column_name='segment'
        ) INTO has_new;

        IF has_old AND has_new THEN
            RAISE EXCEPTION 'Both %.%.where_in_financial_statement and %.%.segment exist. Resolve the duplicate columns before running migration 009.',
                target_schema, target_table, target_schema, target_table;
        ELSIF has_old THEN
            EXECUTE format('ALTER TABLE %I.%I RENAME COLUMN where_in_financial_statement TO segment', target_schema, target_table);
            RAISE NOTICE 'Renamed %.%.where_in_financial_statement to segment.', target_schema, target_table;
        ELSIF has_new THEN
            RAISE NOTICE '%.%.segment already exists; no rename required.', target_schema, target_table;
        ELSE
            RAISE EXCEPTION 'Neither where_in_financial_statement nor segment exists in %.%.', target_schema, target_table;
        END IF;
    END LOOP;
END $$;

COMMIT;
