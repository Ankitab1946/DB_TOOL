STANDARD_FIELDS = [
    "prj_id", "prj_attribute_name", "prj_physical_attribute_name", "section", "sub_section",
    "data_type", "calculated_or_reported", "calculation_logic", "segment", "report_type",
    "attribute_definition", "attribute_description", "display_order", "tech_logic", "display_name",
    "examples", "portfolio",
]
