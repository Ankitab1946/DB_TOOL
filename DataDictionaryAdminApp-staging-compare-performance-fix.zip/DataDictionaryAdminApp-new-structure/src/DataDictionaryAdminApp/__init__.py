"""PRJ Data Dictionary Administration Platform."""
__version__ = "2.0.0"
