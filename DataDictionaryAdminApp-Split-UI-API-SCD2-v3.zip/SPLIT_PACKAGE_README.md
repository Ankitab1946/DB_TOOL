# PRJ Data Dictionary - split deployment

## 1. DataDictionaryAdminApp
Streamlit UI only (port 8501). Configure `API_BASE_URL` to point to the separately deployed API service.

## 2. DataDictionaryAdminAppAPI
FastAPI + database/business services (port 8503). Owns SQLAlchemy, database/Vault configuration, migrations, audit and SCD2.

## SCD2 rollout
Apply migration 011 before the API v3 rollout:
- PostgreSQL: `src/DataDictionaryAdminAppAPI/sql/postgres/011_add_scd2_history.sql`
- SQL Server: `src/DataDictionaryAdminAppAPI/sql/011_add_scd2_history.sql`

Operational table primary/foreign keys remain unchanged. Effective-dated versions are stored centrally in `scd2_row_history`.
