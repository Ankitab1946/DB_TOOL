import io
from openpyxl import Workbook, load_workbook
from DataDictionaryAdminApp.service.excel_service import ExcelService


def workbook_bytes():
    wb = Workbook()
    ws = wb.active
    ws.title = "FI Bank Attributes"
    ws.append(["PRJ Data Dictionary Mapping"])
    ws.append([
        "PRJID",
        "Attribtue Name to be Viewed on Historical and HITL)",
        "prjPhysical Attribute Name",
        "Section(to be used in both PRJUI)",
        "Sub-Section(TO be showed in UI)",
        "DATA TYPE(Amount/%/Ratio/actual)",
        "Calculated or Reported",
        "Calculation logic when attribute come under calculated or reported or calculated category)",
        "Segment where attribute needs to be captured( used for Scanning Purpose)",
        "Attribute Definition",
        "Attribute Description (Proposed one-shot prompt) based on which PRJID will be Mapped (used in Scanning)",
        "Display Order(to be used in Showing PRJUI",
        "Tech Description",
    ])
    ws.append([
        "PRJ100", "Land & Buildings(Gross)", "", "Balance Sheet", "Assets", "Amount", "Calculated",
        "(PRJ100) = Buildings (PRJ10) + Land (PRJ11)", "Balance Sheet", "Definition", "Prompt text", 12, "",
    ])
    stream = io.BytesIO()
    wb.save(stream)
    return stream.getvalue()


def test_per_sheet_header_mapping_and_auto_portfolio():
    content = workbook_bytes()
    service = ExcelService()
    preview = service.preview_sheet(content, "FI Bank Attributes", 2)
    assert preview["portfolio_detected"] == "Banks"
    assert preview["detected_mapping"]["prj_id"] == "PRJID"
    parsed = service.parse_workbook(content, [{"sheet_name": "FI Bank Attributes", "header_row": 2, "mapping": {}}])
    assert parsed["rejected"] == []
    row = parsed["rows"][0]
    assert row.prj_id == "PRJ100"
    assert row.portfolio == "Banks"
    assert row.prj_physical_attribute_name == "gross land bldgs"
    assert row.display_order == 12
    assert row.tech_logic == "(PRJ100) = (PRJ10) + (PRJ11)"


def test_latest_excel_contains_metadata_and_validations():
    content = ExcelService.latest_workbook([{ "prj_id": "PRJ1", "prj_attribute_name": "Cash" }])
    wb = load_workbook(io.BytesIO(content))
    assert wb.sheetnames == ["Master Dictionary", "Metadata"]
    assert wb["Metadata"]["A1"].value == "Template Version"
    assert len(wb["Master Dictionary"].data_validations.dataValidation) >= 2
