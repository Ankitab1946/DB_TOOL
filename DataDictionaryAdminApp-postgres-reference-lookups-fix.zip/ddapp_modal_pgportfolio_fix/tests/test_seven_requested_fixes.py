from pathlib import Path

from DataDictionaryAdminApp.api.schemas_api import AttributeUpsert
from DataDictionaryAdminApp.service.data_dictionary_service import DataDictionaryService


def test_create_edit_fields_cfv_and_modal_size_are_explicit():
    source = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
    assert '@st.dialog("Create New Attribute", width="large")' in source
    assert '"CFV ID"' in source
    assert 'disabled=True' in source
    for label in ("Calculation Logic", "Attribute Definition", "Attribute Description", "Tech Logic"):
        assert f'"{label}"' in source
    for key in ('"calculation_logic": calculation_logic', '"attribute_definition": attribute_definition',
                '"attribute_description": attribute_description', '"tech_logic": tech_logic'):
        assert key in source


def test_edit_prefers_staged_detail_and_create_preserves_generated_id():
    repo = Path("src/DataDictionaryAdminApp/repositories/data_dictionary_repository.py").read_text(encoding="utf-8")
    router = Path("src/DataDictionaryAdminApp/api/routers/data_dictionary.py").read_text(encoding="utf-8")
    assert 'def working_detail' in repo
    assert 'self.get_master(prj_id, "stg")' in repo
    assert 'master["data_state"] = "STAGED"' in repo
    assert 'payload.prj_id = None' not in router
    assert 'CFV ID {payload.prj_id} is no longer available' in router


def test_bulk_stage_uses_fast_cached_path_and_does_not_recalculate_delta():
    router = Path("src/DataDictionaryAdminApp/api/routers/master_upload.py").read_text(encoding="utf-8")
    service = Path("src/DataDictionaryAdminApp/service/data_dictionary_service.py").read_text(encoding="utf-8")
    repo = Path("src/DataDictionaryAdminApp/repositories/data_dictionary_repository.py").read_text(encoding="utf-8")
    assert 'stage_bulk_pending' in service
    assert 'preload_pending_objects' in repo
    assert 'service.stage_bulk_pending' in router
    assert 'db.begin_nested()' not in router
    stage_return = router[router.index('return {', router.index('async def upload_and_stage')):]
    assert 'service.delta()' not in stage_return
    assert '"final_tables_updated": False' in router


def test_validate_compare_returns_counts_and_readable_before_after_rows():
    class FakeRepo:
        def list_portfolios(self, include_inactive):
            return [{"label": "FI Banks", "port_ref_id": 1, "portfolio_name": "FI", "sector_name": "Banks"}]
        def source_table_name(self):
            return None
        def preload_original_mapping_types(self, ids):
            return {key: None for key in ids}
        def preload_physical_names(self):
            return ({"old physical": "PRJ1"}, {"PRJ1": "old physical"})
        def source_code(self, source_name, source_abbr_name=None):
            return source_abbr_name or "SNPAR"
        def preload_final_state(self, ids):
            return ({
                "PRJ1": {
                    "prj_id": "PRJ1", "prj_attribute_name": "Old Name", "prj_attribute_definition": "Old Def",
                    "prj_physical_attribute_name": "old physical", "where_in_financial_statement": "NA", "is_active": True,
                }
            }, {"PRJ1": [{
                "prj_id": "PRJ1", "port_ref_id": 1, "source_abbr_name": "SNPAR", "editable": "Y",
                "symbol": "Amount", "mapping_type": "Reported", "calculation_logic": "NA",
                "prj_attribute_description": "Old Desc", "tech_logic": "NA", "display_order": 1,
                "display_name": "Old Name", "section": "Assets", "subsection": "Current",
                "prompt_description": "Old Desc", "examples": None, "is_active": True,
            }]})
        def active_final_prj_ids(self):
            return {"PRJ1"}
        def physical_name_for_prj(self, prj_id):
            return "old physical"
        def original_mapping_type(self, prj_id):
            return None
        def portfolio_ref(self, value):
            return {"label": "FI Banks", "port_ref_id": 1, "portfolio_name": "FI", "sector_name": "Banks"}

    service = DataDictionaryService(db=None)
    service.repo = FakeRepo()
    payload = AttributeUpsert(
        prj_id="PRJ1", portfolio="FI Banks", source_abbr_name="SNPAR",
        prj_attribute_name="New Name", prj_physical_attribute_name="old physical", physical_name_source="SUPPLIED",
        section="Assets", sub_section="Current", data_type="Amount", calculated_or_reported="Reported",
        calculation_logic="A+B", attribute_definition="New Def", attribute_description="New Desc",
        tech_logic="A+B", display_order=1, display_name="New Name",
    )
    result = service.compare_upload([payload])
    assert result["summary"]["updated"] == 1
    assert result["summary"]["inserted"] == 0
    assert result["rows"][0]["prj_id"] == "PRJ1"
    changed = {(row["field"], row["before_value"], row["after_value"]) for row in result["changes"]}
    assert ("Attribute Name", "Old Name", "New Name") in changed
    assert ("Attribute Definition", "Old Def", "New Def") in changed
    assert ("Attribute Description", "Old Desc", "New Desc") in changed
    assert ("Calculation Logic", "NA", "A+B") in changed


def test_modal_reruns_do_not_refetch_every_heavy_page():
    source = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
    assert '"view_loaded": False' in source
    assert '"lookup_cache": None' in source
    assert '"runtime_context": None' in source
    assert '"upload_sheet_preview_cache": {}' in source
    assert 'modal_active = bool(' in source
    assert 'prompts = st.session_state.get("prompts_cache") or []' in source
    assert 'audit_rows = st.session_state.get("audit_cache_rows") or []' in source
