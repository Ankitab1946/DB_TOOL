/*
010_default_section_subsection_na.sql
PostgreSQL migration: revert nullable Section/Sub-Section behavior and use literal N/A defaults.
Idempotent. Existing NULL/blank values are converted to N/A before NOT NULL is restored.

The raw table is fixed. Display tables may use either the historical _test name or
common UI-renamed prj_attribute_display name. For any other custom physical display
basename, apply the same UPDATE / ALTER COLUMN / DEFAULT pattern to that table.
*/
BEGIN;

DO $$
BEGIN
    IF to_regclass('prj_dbd.raw_prj_attribute_new_test') IS NOT NULL THEN
        UPDATE prj_dbd.raw_prj_attribute_new_test
        SET section = 'N/A'
        WHERE section IS NULL OR btrim(section) = '';

        UPDATE prj_dbd.raw_prj_attribute_new_test
        SET sub_section = 'N/A'
        WHERE sub_section IS NULL OR btrim(sub_section) = '';

        ALTER TABLE prj_dbd.raw_prj_attribute_new_test
            ALTER COLUMN section SET DEFAULT 'N/A',
            ALTER COLUMN section SET NOT NULL,
            ALTER COLUMN sub_section SET DEFAULT 'N/A',
            ALTER COLUMN sub_section SET NOT NULL;
    END IF;
END $$;

DO $$
DECLARE
    rec record;
BEGIN
    FOR rec IN
        SELECT table_schema, table_name
        FROM information_schema.tables
        WHERE table_schema IN ('prj_stage', 'prj_dbd')
          AND table_name IN ('prj_attribute_display_test', 'prj_attribute_display')
          AND table_type = 'BASE TABLE'
    LOOP
        EXECUTE format(
            'UPDATE %I.%I SET section = ''N/A'' WHERE section IS NULL OR btrim(section) = ''''; '
            'UPDATE %I.%I SET subsection = ''N/A'' WHERE subsection IS NULL OR btrim(subsection) = ''''; '
            'ALTER TABLE %I.%I ALTER COLUMN section SET DEFAULT ''N/A'', ALTER COLUMN section SET NOT NULL, '
            'ALTER COLUMN subsection SET DEFAULT ''N/A'', ALTER COLUMN subsection SET NOT NULL',
            rec.table_schema, rec.table_name,
            rec.table_schema, rec.table_name,
            rec.table_schema, rec.table_name
        );
    END LOOP;
END $$;

COMMIT;
SELECT 'Migration completed successfully' AS migration_result;
