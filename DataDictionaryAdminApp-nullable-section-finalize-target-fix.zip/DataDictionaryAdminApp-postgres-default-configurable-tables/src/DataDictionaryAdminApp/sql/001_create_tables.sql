/* SQL Server 2019+ / Azure SQL - fresh install. */
SET NOCOUNT ON;
SET XACT_ABORT ON;
BEGIN TRY
    BEGIN TRANSACTION;
    IF SCHEMA_ID(N'stg') IS NULL EXEC(N'CREATE SCHEMA stg AUTHORIZATION dbo;');

    IF OBJECT_ID(N'dbo.raw_prj_attribute_new_test', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.raw_prj_attribute_new_test (
            raw_row_id bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
            portfolio varchar(120) NOT NULL, prj_id varchar(80) NOT NULL,
            prj_attribute_name nvarchar(500) NOT NULL, prj_physical_attribute_name varchar(500) NOT NULL,
            section nvarchar(255) NULL, sub_section nvarchar(255) NULL,
            data_type varchar(100) NULL, calculated_or_reported varchar(50) NOT NULL,
            calculation_logic nvarchar(max) NOT NULL DEFAULT(N'NA'), segment nvarchar(255) NOT NULL DEFAULT(N'NA'),
            report_type nvarchar(120) NOT NULL DEFAULT(N'NA'), attribute_definition nvarchar(max) NULL,
            attribute_description nvarchar(max) NULL, display_order int NOT NULL, tech_logic nvarchar(max) NULL,
            display_name nvarchar(500) NULL, is_active bit NOT NULL DEFAULT(1),
            created_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()), updated_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()),
            created_by varchar(128) NOT NULL DEFAULT('sysuser'), updated_by varchar(128) NOT NULL DEFAULT('sysuser')
        );
        CREATE INDEX IX_raw_new_prj_id ON dbo.raw_prj_attribute_new_test(prj_id,is_active);
    END;

    IF OBJECT_ID(N'dbo.prj_portfolio_reference_new_test', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.prj_portfolio_reference_new_test (
            port_ref_id int IDENTITY(1,1) NOT NULL PRIMARY KEY, portfolio_name varchar(120) NOT NULL,
            sector_name varchar(120) NOT NULL, sub_sector varchar(120) NULL, remarks nvarchar(500) NULL,
            is_active bit NOT NULL DEFAULT(1), created_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()),
            updated_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()), created_by varchar(128) NOT NULL DEFAULT('sysuser'),
            updated_by varchar(128) NOT NULL DEFAULT('sysuser'),
            CONSTRAINT UQ_prj_portfolio_reference_new_test UNIQUE(portfolio_name,sector_name,sub_sector)
        );
    END;

    IF OBJECT_ID(N'dbo.audit_table_new_test', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.audit_table_new_test (
            audit_id bigint IDENTITY(1,1) NOT NULL PRIMARY KEY, schema_name varchar(128) NOT NULL,
            table_name varchar(255) NOT NULL, record_key varchar(500) NOT NULL, action varchar(50) NOT NULL,
            before_value nvarchar(max) NULL, after_value nvarchar(max) NULL, source_operation varchar(100) NULL,
            performed_by varchar(128) NOT NULL, performed_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME())
        );
        CREATE INDEX IX_audit_new_search ON dbo.audit_table_new_test(performed_at DESC,table_name,action);
    END;

    IF OBJECT_ID(N'stg.prj_attribute_master_new_test', N'U') IS NULL
    BEGIN
        CREATE TABLE stg.prj_attribute_master_new_test (
            prj_id varchar(80) NOT NULL PRIMARY KEY, prj_attribute_name nvarchar(500) NOT NULL,
            prj_attribute_definition nvarchar(max) NULL, prj_physical_attribute_name varchar(500) NOT NULL,
            where_in_financial_statement nvarchar(255) NOT NULL DEFAULT(N'NA'), is_active bit NOT NULL DEFAULT(1),
            created_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()), updated_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()),
            created_by varchar(128) NOT NULL DEFAULT('sysuser'), updated_by varchar(128) NOT NULL DEFAULT('sysuser')
        );
        CREATE UNIQUE INDEX UX_stg_master_new_physical ON stg.prj_attribute_master_new_test(prj_physical_attribute_name);
    END;

    IF OBJECT_ID(N'stg.prj_attribute_business_rules_new_test', N'U') IS NULL
    BEGIN
        CREATE TABLE stg.prj_attribute_business_rules_new_test (
            scope_id bigint IDENTITY(1,1) NOT NULL PRIMARY KEY, prj_id varchar(80) NOT NULL, port_ref_id int NOT NULL,
            source_abbr_name varchar(50) NOT NULL DEFAULT('SNPAR'), prompt_description nvarchar(max) NULL,
            examples_for_llm nvarchar(max) NULL, editable char(1) NOT NULL, data_type varchar(50) NULL,
            attribute_type varchar(50) NOT NULL, business_logic nvarchar(max) NULL,
            calculation_logic nvarchar(max) NOT NULL DEFAULT(N'NA'),
            created_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()), updated_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()),
            created_by varchar(128) NOT NULL DEFAULT('sysuser'), updated_by varchar(128) NOT NULL DEFAULT('sysuser'),
            CONSTRAINT FK_stg_rules_master_split FOREIGN KEY(prj_id) REFERENCES stg.prj_attribute_master_new_test(prj_id),
            CONSTRAINT FK_stg_rules_portfolio_split FOREIGN KEY(port_ref_id) REFERENCES dbo.prj_portfolio_reference_new_test(port_ref_id),
            CONSTRAINT CK_stg_rules_editable_split CHECK(editable IN ('Y','N'))
        );
        CREATE INDEX IX_stg_rules_split_prj ON stg.prj_attribute_business_rules_new_test(prj_id,port_ref_id,source_abbr_name);
    END;

    IF OBJECT_ID(N'stg.prj_attribute_display_test', N'U') IS NULL
    BEGIN
        CREATE TABLE stg.prj_attribute_display_test (
            display_id bigint IDENTITY(1,1) NOT NULL PRIMARY KEY, scope_id bigint NOT NULL, display_order int NOT NULL,
            prj_id varchar(80) NOT NULL, display_name nvarchar(500) NULL, section nvarchar(255) NULL,
            subsection nvarchar(255) NULL, prj_attribute_definition nvarchar(max) NULL,
            prj_attribute_description nvarchar(max) NULL, segment nvarchar(255) NOT NULL DEFAULT(N'NA'),
            report_type nvarchar(120) NOT NULL DEFAULT(N'NA'),
            created_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()), updated_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()),
            created_by varchar(128) NOT NULL DEFAULT('sysuser'), updated_by varchar(128) NOT NULL DEFAULT('sysuser'),
            CONSTRAINT UQ_stg_display_scope UNIQUE(scope_id),
            CONSTRAINT FK_stg_display_scope FOREIGN KEY(scope_id) REFERENCES stg.prj_attribute_business_rules_new_test(scope_id),
            CONSTRAINT FK_stg_display_master FOREIGN KEY(prj_id) REFERENCES stg.prj_attribute_master_new_test(prj_id)
        );
        CREATE INDEX IX_stg_display_filters ON stg.prj_attribute_display_test(prj_id,section,subsection,display_order);
    END;

    IF OBJECT_ID(N'dbo.prj_attribute_master_new_test', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.prj_attribute_master_new_test (
            prj_id varchar(80) NOT NULL PRIMARY KEY, prj_attribute_name nvarchar(500) NOT NULL,
            prj_attribute_definition nvarchar(max) NULL, prj_physical_attribute_name varchar(500) NOT NULL,
            where_in_financial_statement nvarchar(255) NOT NULL DEFAULT(N'NA'), is_active bit NOT NULL DEFAULT(1),
            created_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()), updated_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()),
            created_by varchar(128) NOT NULL DEFAULT('sysuser'), updated_by varchar(128) NOT NULL DEFAULT('sysuser')
        );
        CREATE UNIQUE INDEX UX_master_new_physical ON dbo.prj_attribute_master_new_test(prj_physical_attribute_name);
    END;

    IF OBJECT_ID(N'dbo.prj_attribute_business_rules_new_test', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.prj_attribute_business_rules_new_test (
            scope_id bigint IDENTITY(1,1) NOT NULL PRIMARY KEY, prj_id varchar(80) NOT NULL, port_ref_id int NOT NULL,
            source_abbr_name varchar(50) NOT NULL DEFAULT('SNPAR'), prompt_description nvarchar(max) NULL,
            examples_for_llm nvarchar(max) NULL, editable char(1) NOT NULL, data_type varchar(50) NULL,
            attribute_type varchar(50) NOT NULL, business_logic nvarchar(max) NULL,
            calculation_logic nvarchar(max) NOT NULL DEFAULT(N'NA'),
            created_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()), updated_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()),
            created_by varchar(128) NOT NULL DEFAULT('sysuser'), updated_by varchar(128) NOT NULL DEFAULT('sysuser'),
            CONSTRAINT FK_rules_master_split FOREIGN KEY(prj_id) REFERENCES dbo.prj_attribute_master_new_test(prj_id),
            CONSTRAINT FK_rules_portfolio_split FOREIGN KEY(port_ref_id) REFERENCES dbo.prj_portfolio_reference_new_test(port_ref_id),
            CONSTRAINT CK_rules_editable_split CHECK(editable IN ('Y','N'))
        );
        CREATE INDEX IX_rules_split_prj ON dbo.prj_attribute_business_rules_new_test(prj_id,port_ref_id,source_abbr_name);
    END;

    IF OBJECT_ID(N'dbo.prj_attribute_display_test', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.prj_attribute_display_test (
            display_id bigint IDENTITY(1,1) NOT NULL PRIMARY KEY, scope_id bigint NOT NULL, display_order int NOT NULL,
            prj_id varchar(80) NOT NULL, display_name nvarchar(500) NULL, section nvarchar(255) NULL,
            subsection nvarchar(255) NULL, prj_attribute_definition nvarchar(max) NULL,
            prj_attribute_description nvarchar(max) NULL, segment nvarchar(255) NOT NULL DEFAULT(N'NA'),
            report_type nvarchar(120) NOT NULL DEFAULT(N'NA'),
            created_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()), updated_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()),
            created_by varchar(128) NOT NULL DEFAULT('sysuser'), updated_by varchar(128) NOT NULL DEFAULT('sysuser'),
            CONSTRAINT UQ_display_scope UNIQUE(scope_id),
            CONSTRAINT FK_display_scope FOREIGN KEY(scope_id) REFERENCES dbo.prj_attribute_business_rules_new_test(scope_id),
            CONSTRAINT FK_display_master FOREIGN KEY(prj_id) REFERENCES dbo.prj_attribute_master_new_test(prj_id)
        );
        CREATE INDEX IX_display_filters ON dbo.prj_attribute_display_test(prj_id,section,subsection,display_order);
    END;

    /* Stable reference IDs. */
    IF EXISTS (SELECT 1 FROM dbo.prj_portfolio_reference_new_test WHERE port_ref_id=1 AND NOT (portfolio_name='FI' AND sector_name='Banks')) THROW 51001,'port_ref_id 1 is reserved for FI/Banks.',1;
    IF EXISTS (SELECT 1 FROM dbo.prj_portfolio_reference_new_test WHERE port_ref_id=2 AND NOT (portfolio_name='FI' AND sector_name='Insurance')) THROW 51002,'port_ref_id 2 is reserved for FI/Insurance.',1;
    IF EXISTS (SELECT 1 FROM dbo.prj_portfolio_reference_new_test WHERE port_ref_id=3 AND NOT (portfolio_name='Corporate' AND sector_name='Corporate')) THROW 51003,'port_ref_id 3 is reserved for Corporate/Corporate.',1;
    IF EXISTS (SELECT 1 FROM dbo.prj_portfolio_reference_new_test WHERE port_ref_id=4 AND NOT (portfolio_name='UKC' AND sector_name='UKC')) THROW 51004,'port_ref_id 4 is reserved for UKC/UKC.',1;
    SET IDENTITY_INSERT dbo.prj_portfolio_reference_new_test ON;
    IF NOT EXISTS(SELECT 1 FROM dbo.prj_portfolio_reference_new_test WHERE port_ref_id=1) INSERT dbo.prj_portfolio_reference_new_test(port_ref_id,portfolio_name,sector_name,sub_sector,remarks) VALUES(1,'FI','Banks',NULL,N'Financial Institutes - Banks');
    IF NOT EXISTS(SELECT 1 FROM dbo.prj_portfolio_reference_new_test WHERE port_ref_id=2) INSERT dbo.prj_portfolio_reference_new_test(port_ref_id,portfolio_name,sector_name,sub_sector,remarks) VALUES(2,'FI','Insurance',NULL,N'Financial Institutes - Insurance');
    IF NOT EXISTS(SELECT 1 FROM dbo.prj_portfolio_reference_new_test WHERE port_ref_id=3) INSERT dbo.prj_portfolio_reference_new_test(port_ref_id,portfolio_name,sector_name,sub_sector,remarks) VALUES(3,'Corporate','Corporate',NULL,N'Global Corporates');
    IF NOT EXISTS(SELECT 1 FROM dbo.prj_portfolio_reference_new_test WHERE port_ref_id=4) INSERT dbo.prj_portfolio_reference_new_test(port_ref_id,portfolio_name,sector_name,sub_sector,remarks) VALUES(4,'UKC','UKC',NULL,N'UK Corporate');
    SET IDENTITY_INSERT dbo.prj_portfolio_reference_new_test OFF;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
