# Validation Results

Latest fix: PostgreSQL Portfolio/Scope and Source reference lookup alignment.

- PostgreSQL Portfolio/Scope reads directly from `prj_dbd.prj_portfolio_reference`.
- PostgreSQL Source reads directly from `prj_dbd.prj_data_sources`.
- PostgreSQL reference rows are not hidden by legacy `is_active` values.
- PostgreSQL UI refreshes Portfolio and Source independently from the combined lookup endpoint.
- SQL Server lookup behavior remains unchanged.
- No database migration or DDL change is required.
- Python compileall: PASS
- FastAPI/OpenAPI import: PASS
- OpenAPI paths: 29
- Full pytest regression suite: PASS

## PostgreSQL Finalize publication fix
- PostgreSQL Finalize now publishes through the physical schemas `prj_stage` -> `prj_dbd`.
- Canonical Portfolio/Scope validation uses `prj_dbd.prj_portfolio_reference` before publication.
- Publication covers master, business rules, and display rows and writes audit history before staging cleanup.
- SQL Server retains the existing ORM finalize path unchanged.
- Missing PostgreSQL tables/columns return descriptive API errors rather than a generic Internal Server Error.
- Focused physical-schema publication regression test added.
- Full regression suite: 122 tests passed.
- Python compileall: PASS.
- FastAPI/OpenAPI: PASS (29 paths).


## PG environment-variable rename
- Renamed PostgreSQL connection settings: `POSTGRES_HOST` -> `PG_HOST`, `POSTGRES_PORT` -> `PG_PORT`, `POSTGRES_DATABASE` -> `PG_DATABASE`.
- Added/renamed schema setting to `PG_SCHEMA` (default `prj_dbd`).
- Environment-specific overrides now use `ENV_<ENV>_PG_HOST`, `ENV_<ENV>_PG_PORT`, `ENV_<ENV>_PG_DATABASE`, `ENV_<ENV>_PG_SCHEMA`.
- `POSTGRES_USER`, `POSTGRES_PASSWORD`, `POSTGRES_SSLMODE`, and `ENABLE_POSTGRES` remain unchanged.
- Full pytest regression suite passed; Python compileall passed.


## PostgreSQL default + configurable target table names
- PostgreSQL is now the default database selection on Streamlit page load and the default `Settings.selected_db_type`.
- `.env.example` now defaults `SELECTED_DB_TYPE=POSTGRES`.
- Sidebar shows editable staging and actual/final targets for Attribute Master, Business Rules and Attribute Display.
- Target names are maintained independently for PostgreSQL and SQL Server during the Streamlit session and sent on every API request.
- SQLAlchemy applies request-level qualified table rewrites, preserving existing ORM/service/repository behavior.
- PostgreSQL Finalize reflects the selected `prj_stage` / main-schema table names directly.
- Target identifiers are validated to safe SQL basenames.
- Raw, audit, Portfolio and Data Source reference table contracts remain unchanged.
- Focused runtime test proves ORM redirection to a custom physical table.
- Focused PostgreSQL Finalize test proves custom staging and final table names publish successfully.
- Full pytest regression suite: **132 tests passed**.
- Python compileall: PASS.
- FastAPI/OpenAPI: PASS (29 paths).
- No SQL migration is required for this application-routing change.

## Portfolio remarks rename
- Renamed Portfolio Reference runtime/API/UI field from `remark` to `remarks`.
- Added SQL Server migration `007_rename_portfolio_remark_to_remarks.sql`.
- Added PostgreSQL migration `postgres/007_rename_portfolio_remark_to_remarks.sql`.
- Updated fresh-install DDL and schema validators to require `remarks`.
- API input keeps backward compatibility with legacy `remark`, while serializing/storing the canonical `remarks` field.
- Full regression suite passed after the change.
