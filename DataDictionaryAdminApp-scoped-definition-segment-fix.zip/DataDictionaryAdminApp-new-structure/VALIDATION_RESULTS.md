# Validation Results

Validation for the scoped Attribute Definition / Attribute Description / Segment update:

- 77/77 automated tests passed.
- Python `compileall` passed for `src` and `tests`.
- FastAPI/OpenAPI generated successfully with 29 API paths.
- SQLAlchemy SQL Server compilation for business-rule active rows uses `= 1`.
- SQLAlchemy PostgreSQL compilation for business-rule active rows uses `= true`.
- `Total|Liabilities` + `Current|Current2` expands into two raw rows and two staging/final business-rule rows.
- Per-pair Attribute Definition and Attribute Description values are retained independently.
- Segment supports one broadcast value or positional pipe-separated values.
- Fresh-install SQL Server/PostgreSQL DDL contains the new scope-level columns.
- Existing-database migration scripts are included for SQL Server and PostgreSQL.

Existing databases must run `003_add_scoped_definition_segment.sql` for the selected database engine before this build is started.
