# Requirement Alignment

## Physical table mapping

| Layer | Object | Purpose |
|---|---|---|
| Raw | `dbo.raw_prj_attribute_new_test` | Excel/UI shaped record, including Portfolio, section/sub-section, data type, calculation fields and display fields |
| Reference | `dbo.prj_portfolio_reference_new_test` | Static/editable portfolio-to-`port_ref_id` mapping |
| External reference | `dbo.prj_data_sources` | Existing read-only source name/code table; not created by app |
| Audit | `dbo.audit_table_new_test` | before/after audit across raw, staging, final and reference changes |
| Staging | `stg.prj_attribute_master_new_test` | pending master changes |
| Staging | `stg.prj_attribute_business_rules_new_test` | pending scope/source/business-rule/prompt/display changes |
| Final | `dbo.prj_attribute_master_new_test` | finalized master data |
| Final | `dbo.prj_attribute_business_rules_new_test` | finalized scope/source/business-rule/prompt/display data |

## Raw to staging mapping

| Raw field | Staging target |
|---|---|
| `prj_id` | master `prj_id`; rules `prj_id` |
| `prj_attribute_name` | master `prj_attribute_name` |
| `attribute_definition` | master `prj_attribute_definition` |
| `prj_physical_attribute_name` | master `prj_physical_attribute_name` |
| `segment` | master `where_in_financial_statement` |
| `portfolio` | rules `port_ref_id` through portfolio reference |
| source UI selection | rules `source_abbr_name` using source code; default `SNPAR` |
| `calculated_or_reported` | rules `editable` + `mapping_type` |
| `data_type` | rules `symbol` |
| `calculation_logic` | rules `calculation_logic` |
| `attribute_description` | rules `prj_attribute_description` + default `prompt_description` |
| generated / Excel tech logic | rules `tech_logic` |
| `display_order` | rules `display_order` |
| `display_name` | rules `display_name` |
| `section` | rules `section` |
| `sub_section` | rules `subsection` |
| UI prompt examples | rules `examples` |

## Calculated/Reported rules

| Input | `editable` | `mapping_type` |
|---|---|---|
| Calculated | N | Calculated |
| Reported | Y | Reported |
| Repeated | Y | first non-Repeated occurrence's type; defaults to Reported if no original exists |

## Finalization semantics

Staging is a pending-change layer. Finalize computes an attribute-level delta and updates final tables only after explicit confirmation. Processed staging rows are cleared after a successful finalization. Raw records remain available as the latest ingestion/edit representation and audit history preserves before/after changes.


## Database engine alignment

- Runtime database selection supports `SQLSERVER` and `POSTGRES` using the same SQLAlchemy entity/repository layer.
- SQL Server uses `mssql+pyodbc`; PostgreSQL uses `postgresql+psycopg`.
- Both engines use the same logical table/schema names, column contract, raw → staging → final lifecycle and API models.
- Engine-specific DDL is isolated under `sql/` and `sql/postgres/`; application CRUD contains no SQL Server-only `OUTPUT`, `TOP`, `SYSUTCDATETIME()` or `SCOPE_IDENTITY()` statements.
- `dbo.prj_data_sources` remains read-only and is deliberately excluded from both create scripts.

## Bulk replacement safeguards

- `MERGE` accepts valid rows and reports row-level rejects.
- `REPLACE` is authoritative: it compares the workbook with active final data and identifies absent PRJ IDs as `DELETED`.
- A `REPLACE` containing parse/mapping errors is rejected before raw/staging data is cleared.
- A runtime failure during `REPLACE` rolls the replacement transaction back instead of leaving a partial replacement.
