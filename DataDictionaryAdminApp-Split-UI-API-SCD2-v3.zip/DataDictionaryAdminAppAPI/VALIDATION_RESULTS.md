# Validation results

- Pre-split combined baseline: **175 tests passed** before restructuring.
- API split suite: **81 tests passed** after namespace split and SCD2 changes.
- Existing HTTP API contract: **34 `/api/v1` routes preserved; 0 removed**.
- Additive route: `GET /api/v1/audit/scd2-history`.
- SCD2 functional rollover test verifies version 1 closes and version 2 becomes current.
- PostgreSQL finalize regression remains passing after SCD2 integration.
- SQL Server/PostgreSQL migration scripts include `011_add_scd2_history.sql`.
