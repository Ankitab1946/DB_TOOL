from pathlib import Path

APP = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")


def test_create_and_edit_use_native_dialogs():
    assert '@st.dialog("Create New Attribute", width="large")' in APP
    assert '@st.dialog("Edit Attribute", width="large")' in APP


def test_native_dialog_keeps_responsive_wide_contract_without_position_override():
    assert '[data-testid="stDialog"] [role="dialog"]' in APP
    assert 'width: min(96vw, 1600px) !important;' in APP
    assert 'max-height: 90vh !important;' in APP
    assert 'top: 50% !important;' not in APP
    assert 'position: fixed !important;' not in APP


def test_create_and_edit_are_invoked_directly_from_user_actions():
    assert 'create_attribute_dialog()' in APP
    assert 'edit_attribute_dialog(selected_prj, detail)' in APP
    assert 'create_modal.open()' not in APP
    assert 'edit_modal.open()' not in APP
