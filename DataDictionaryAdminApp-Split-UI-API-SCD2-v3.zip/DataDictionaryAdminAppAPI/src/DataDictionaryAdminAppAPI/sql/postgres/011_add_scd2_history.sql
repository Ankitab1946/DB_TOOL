-- Central SCD2 companion history. Operational PK/FK contracts remain unchanged.
CREATE TABLE IF NOT EXISTS prj_dbd.scd2_row_history (
    history_id BIGSERIAL PRIMARY KEY,
    source_schema VARCHAR(128) NOT NULL,
    source_table VARCHAR(255) NOT NULL,
    record_key VARCHAR(500) NOT NULL,
    version_number INTEGER NOT NULL,
    effective_from TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    effective_to TIMESTAMP NULL,
    is_current BOOLEAN NOT NULL DEFAULT TRUE,
    operation VARCHAR(50) NOT NULL,
    row_data TEXT NULL,
    source_operation VARCHAR(100) NULL,
    changed_by VARCHAR(128) NOT NULL DEFAULT 'migration',
    changed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_scd2_row_version UNIQUE (source_schema, source_table, record_key, version_number)
);
CREATE INDEX IF NOT EXISTS ix_scd2_row_lookup
    ON prj_dbd.scd2_row_history(source_schema, source_table, record_key, is_current);
CREATE UNIQUE INDEX IF NOT EXISTS uq_scd2_one_current
    ON prj_dbd.scd2_row_history(source_schema, source_table, record_key)
    WHERE is_current = TRUE;

-- Baseline existing rows. Dynamic blocks allow established/read-only tables to be absent.
DO $$
DECLARE spec record;
DECLARE sql_text text;
BEGIN
  FOR spec IN SELECT * FROM (VALUES
    ('prj_dbd','raw_prj_attribute_new_test','raw_row_id'),
    ('prj_stage','prj_attribute_master_new_test','prj_id'),
    ('prj_stage','prj_attribute_business_rules_new_test','scope_id'),
    ('prj_stage','prj_attribute_display_test','display_id'),
    ('prj_dbd','prj_attribute_master_new_test','prj_id'),
    ('prj_dbd','prj_attribute_business_rules_new_test','scope_id'),
    ('prj_dbd','prj_attribute_display_test','display_id'),
    ('prj_dbd','prj_portfolio_reference','port_ref_id'),
    ('prj_dbd','prj_data_sources','source_code'),
    ('prj_dbd','audit_table_new_test','audit_id')
  ) AS x(schema_name, table_name, key_column)
  LOOP
    IF to_regclass(format('%I.%I', spec.schema_name, spec.table_name)) IS NOT NULL THEN
      sql_text := format($f$
        INSERT INTO prj_dbd.scd2_row_history
          (source_schema, source_table, record_key, version_number, effective_from, effective_to,
           is_current, operation, row_data, source_operation, changed_by, changed_at)
        SELECT %L, %L, t.%I::text, 1, CURRENT_TIMESTAMP, NULL,
               TRUE, 'BASELINE', to_jsonb(t)::text, 'MIGRATION', 'migration', CURRENT_TIMESTAMP
        FROM %I.%I t
        WHERE NOT EXISTS (
          SELECT 1 FROM prj_dbd.scd2_row_history h
          WHERE h.source_schema=%L AND h.source_table=%L AND h.record_key=t.%I::text
        )
      $f$, spec.schema_name, spec.table_name, spec.key_column,
           spec.schema_name, spec.table_name,
           spec.schema_name, spec.table_name, spec.key_column);
      EXECUTE sql_text;
    END IF;
  END LOOP;
END $$;
