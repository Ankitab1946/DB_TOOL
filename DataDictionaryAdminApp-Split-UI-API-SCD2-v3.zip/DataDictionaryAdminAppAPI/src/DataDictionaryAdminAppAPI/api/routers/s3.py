from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from DataDictionaryAdminAppAPI.core.database import get_db
from DataDictionaryAdminAppAPI.service.s3_service import S3Service
from DataDictionaryAdminAppAPI.utils.security import require_admin

router = APIRouter(prefix="/s3", tags=["S3 Export"])

@router.post("/export-final")
def export_final(request: Request, db: Session = Depends(get_db)):
    require_admin(request)
    try:
        return S3Service(db).export_final_tables()
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
