#!/usr/bin/env sh
set -eu
if [ "${KERBEROS_ENABLED:-false}" = "true" ]; then
  : "${KERBEROS_PRINCIPAL:?KERBEROS_PRINCIPAL is required}"
  : "${KERBEROS_KEYTAB_PATH:?KERBEROS_KEYTAB_PATH is required}"
  export KRB5_KTNAME="${KERBEROS_KEYTAB_PATH}"
  kinit -kt "${KERBEROS_KEYTAB_PATH}" "${KERBEROS_PRINCIPAL}"
fi
exec "$@"
