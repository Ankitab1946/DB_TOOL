/* SQL Server existing-database migration: split business rules from display metadata.
   Safe to run once; reruns are no-op after successful completion. */
SET NOCOUNT ON;
SET XACT_ABORT ON;
BEGIN TRY
  BEGIN TRANSACTION;

  IF OBJECT_ID(N'stg.prj_attribute_business_rules_new_test',N'U') IS NULL OR OBJECT_ID(N'dbo.prj_attribute_business_rules_new_test',N'U') IS NULL
    THROW 51050,'Business-rule tables are missing. Apply earlier schema migrations first.',1;

  /* ---------- STAGING ---------- */
  IF COL_LENGTH(N'stg.prj_attribute_business_rules_new_test',N'data_type') IS NULL
  BEGIN
    IF OBJECT_ID(N'stg.prj_attribute_business_rules_new_test_v2',N'U') IS NOT NULL DROP TABLE stg.prj_attribute_business_rules_new_test_v2;
    CREATE TABLE stg.prj_attribute_business_rules_new_test_v2 (
      scope_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_stg_rules_v2_005 PRIMARY KEY,
      prj_id varchar(80) NOT NULL, port_ref_id int NOT NULL, source_abbr_name varchar(50) NOT NULL DEFAULT('SNPAR'),
      prompt_description nvarchar(max) NULL, examples_for_llm nvarchar(max) NULL, editable char(1) NOT NULL,
      data_type varchar(50) NULL, attribute_type varchar(50) NOT NULL, business_logic nvarchar(max) NULL,
      calculation_logic nvarchar(max) NOT NULL DEFAULT(N'NA'), created_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()),
      updated_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()), created_by varchar(128) NOT NULL DEFAULT('sysuser'),
      updated_by varchar(128) NOT NULL DEFAULT('sysuser'),
      CONSTRAINT FK_stg_rules_v2_master_005 FOREIGN KEY(prj_id) REFERENCES stg.prj_attribute_master_new_test(prj_id),
      CONSTRAINT FK_stg_rules_v2_port_005 FOREIGN KEY(port_ref_id) REFERENCES dbo.prj_portfolio_reference_new_test(port_ref_id),
      CONSTRAINT CK_stg_rules_v2_editable_005 CHECK(editable IN ('Y','N'))
    );
    SET IDENTITY_INSERT stg.prj_attribute_business_rules_new_test_v2 ON;
    INSERT stg.prj_attribute_business_rules_new_test_v2(scope_id,prj_id,port_ref_id,source_abbr_name,prompt_description,examples_for_llm,editable,data_type,attribute_type,business_logic,calculation_logic,created_at,updated_at,created_by,updated_by)
    SELECT scope_id,prj_id,port_ref_id,source_abbr_name,prompt_description,examples,editable,symbol,mapping_type,tech_logic,calculation_logic,created_at,updated_at,created_by,updated_by
    FROM stg.prj_attribute_business_rules_new_test;
    SET IDENTITY_INSERT stg.prj_attribute_business_rules_new_test_v2 OFF;

    EXEC sp_rename N'stg.prj_attribute_business_rules_new_test',N'prj_attribute_business_rules_legacy_005';
    EXEC sp_rename N'stg.prj_attribute_business_rules_new_test_v2',N'prj_attribute_business_rules_new_test';

    CREATE TABLE stg.prj_attribute_display_test (
      display_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_stg_display_005 PRIMARY KEY,
      scope_id bigint NOT NULL, display_order int NOT NULL, prj_id varchar(80) NOT NULL, display_name nvarchar(500) NULL,
      section nvarchar(255) NOT NULL, subsection nvarchar(255) NOT NULL, prj_attribute_definition nvarchar(max) NULL,
      prj_attribute_description nvarchar(max) NULL, segment nvarchar(255) NOT NULL DEFAULT(N'NA'), report_type nvarchar(120) NOT NULL DEFAULT(N'NA'),
      created_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()), updated_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()),
      created_by varchar(128) NOT NULL DEFAULT('sysuser'), updated_by varchar(128) NOT NULL DEFAULT('sysuser'),
      CONSTRAINT UQ_stg_display_scope_005 UNIQUE(scope_id),
      CONSTRAINT FK_stg_display_scope_005 FOREIGN KEY(scope_id) REFERENCES stg.prj_attribute_business_rules_new_test(scope_id),
      CONSTRAINT FK_stg_display_master_005 FOREIGN KEY(prj_id) REFERENCES stg.prj_attribute_master_new_test(prj_id)
    );
    INSERT stg.prj_attribute_display_test(scope_id,display_order,prj_id,display_name,section,subsection,prj_attribute_definition,prj_attribute_description,segment,report_type,created_at,updated_at,created_by,updated_by)
    SELECT scope_id,display_order,prj_id,display_name,section,subsection,prj_attribute_definition,prj_attribute_description,segment,report_type,created_at,updated_at,created_by,updated_by
    FROM stg.prj_attribute_business_rules_legacy_005;
    CREATE INDEX IX_stg_display_filters_005 ON stg.prj_attribute_display_test(prj_id,section,subsection,display_order);
    CREATE INDEX IX_stg_rules_split_prj_005 ON stg.prj_attribute_business_rules_new_test(prj_id,port_ref_id,source_abbr_name);
    DROP TABLE stg.prj_attribute_business_rules_legacy_005;
  END
  ELSE IF OBJECT_ID(N'stg.prj_attribute_display_test',N'U') IS NULL
    THROW 51051,'Staging business table is already split but stg.prj_attribute_display_test is missing.',1;

  /* ---------- FINAL / DBO ---------- */
  IF COL_LENGTH(N'dbo.prj_attribute_business_rules_new_test',N'data_type') IS NULL
  BEGIN
    IF OBJECT_ID(N'dbo.prj_attribute_business_rules_new_test_v2',N'U') IS NOT NULL DROP TABLE dbo.prj_attribute_business_rules_new_test_v2;
    CREATE TABLE dbo.prj_attribute_business_rules_new_test_v2 (
      scope_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_rules_v2_005 PRIMARY KEY,
      prj_id varchar(80) NOT NULL, port_ref_id int NOT NULL, source_abbr_name varchar(50) NOT NULL DEFAULT('SNPAR'),
      prompt_description nvarchar(max) NULL, examples_for_llm nvarchar(max) NULL, editable char(1) NOT NULL,
      data_type varchar(50) NULL, attribute_type varchar(50) NOT NULL, business_logic nvarchar(max) NULL,
      calculation_logic nvarchar(max) NOT NULL DEFAULT(N'NA'), created_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()),
      updated_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()), created_by varchar(128) NOT NULL DEFAULT('sysuser'),
      updated_by varchar(128) NOT NULL DEFAULT('sysuser'),
      CONSTRAINT FK_rules_v2_master_005 FOREIGN KEY(prj_id) REFERENCES dbo.prj_attribute_master_new_test(prj_id),
      CONSTRAINT FK_rules_v2_port_005 FOREIGN KEY(port_ref_id) REFERENCES dbo.prj_portfolio_reference_new_test(port_ref_id),
      CONSTRAINT CK_rules_v2_editable_005 CHECK(editable IN ('Y','N'))
    );
    SET IDENTITY_INSERT dbo.prj_attribute_business_rules_new_test_v2 ON;
    INSERT dbo.prj_attribute_business_rules_new_test_v2(scope_id,prj_id,port_ref_id,source_abbr_name,prompt_description,examples_for_llm,editable,data_type,attribute_type,business_logic,calculation_logic,created_at,updated_at,created_by,updated_by)
    SELECT scope_id,prj_id,port_ref_id,source_abbr_name,prompt_description,examples,editable,symbol,mapping_type,tech_logic,calculation_logic,created_at,updated_at,created_by,updated_by
    FROM dbo.prj_attribute_business_rules_new_test;
    SET IDENTITY_INSERT dbo.prj_attribute_business_rules_new_test_v2 OFF;

    EXEC sp_rename N'dbo.prj_attribute_business_rules_new_test',N'prj_attribute_business_rules_legacy_005';
    EXEC sp_rename N'dbo.prj_attribute_business_rules_new_test_v2',N'prj_attribute_business_rules_new_test';

    CREATE TABLE dbo.prj_attribute_display_test (
      display_id bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_display_005 PRIMARY KEY,
      scope_id bigint NOT NULL, display_order int NOT NULL, prj_id varchar(80) NOT NULL, display_name nvarchar(500) NULL,
      section nvarchar(255) NOT NULL, subsection nvarchar(255) NOT NULL, prj_attribute_definition nvarchar(max) NULL,
      prj_attribute_description nvarchar(max) NULL, segment nvarchar(255) NOT NULL DEFAULT(N'NA'), report_type nvarchar(120) NOT NULL DEFAULT(N'NA'),
      created_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()), updated_at datetime2(3) NOT NULL DEFAULT(SYSUTCDATETIME()),
      created_by varchar(128) NOT NULL DEFAULT('sysuser'), updated_by varchar(128) NOT NULL DEFAULT('sysuser'),
      CONSTRAINT UQ_display_scope_005 UNIQUE(scope_id),
      CONSTRAINT FK_display_scope_005 FOREIGN KEY(scope_id) REFERENCES dbo.prj_attribute_business_rules_new_test(scope_id),
      CONSTRAINT FK_display_master_005 FOREIGN KEY(prj_id) REFERENCES dbo.prj_attribute_master_new_test(prj_id)
    );
    INSERT dbo.prj_attribute_display_test(scope_id,display_order,prj_id,display_name,section,subsection,prj_attribute_definition,prj_attribute_description,segment,report_type,created_at,updated_at,created_by,updated_by)
    SELECT scope_id,display_order,prj_id,display_name,section,subsection,prj_attribute_definition,prj_attribute_description,segment,report_type,created_at,updated_at,created_by,updated_by
    FROM dbo.prj_attribute_business_rules_legacy_005;
    CREATE INDEX IX_display_filters_005 ON dbo.prj_attribute_display_test(prj_id,section,subsection,display_order);
    CREATE INDEX IX_rules_split_prj_005 ON dbo.prj_attribute_business_rules_new_test(prj_id,port_ref_id,source_abbr_name);
    DROP TABLE dbo.prj_attribute_business_rules_legacy_005;
  END
  ELSE IF OBJECT_ID(N'dbo.prj_attribute_display_test',N'U') IS NULL
    THROW 51052,'Final business table is already split but dbo.prj_attribute_display_test is missing.',1;

  COMMIT TRANSACTION;
  SELECT 'Migration completed successfully' AS migration_status;
END TRY
BEGIN CATCH
  IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
  THROW;
END CATCH;
