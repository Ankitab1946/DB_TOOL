from fastapi import APIRouter, Request

from DataDictionaryAdminApp.config import get_settings
from DataDictionaryAdminApp.core.database import database_connection_status
from DataDictionaryAdminApp.utils.security import current_role, current_user

router = APIRouter(tags=["System"])


@router.get("/health")
def health():
    return {
        "status": "ok",
        "version": "2.1.0",
        "upload_modes": ["MERGE", "INSERT_ONLY", "REPLACE"],
        "database_status_endpoint": True,
    }


@router.get("/system/context")
def context(request: Request):
    settings = get_settings()
    environment = settings.resolve_environment(request.headers.get("X-App-Environment"))
    db_type = settings.resolve_db_type(request.headers.get("X-DB-Type"))
    cfg = settings.database_config(environment, db_type)
    user = current_user(request)
    role = current_role(request)
    if db_type == "POSTGRES":
        server = f"{cfg['host']}:{cfg['port']}"
    else:
        server = cfg["server"]
    return {
        "environment": environment,
        "environments": settings.available_environments(),
        "db_type": db_type,
        "db_types": settings.available_db_types(),
        "database": cfg["database"],
        "server": server,
        "database_enabled": cfg["enabled"],
        "current_user": user,
        "role": role,
        "is_admin": role == "ADMIN",
    }


@router.get("/system/database-status")
def database_status(request: Request):
    settings = get_settings()
    environment = settings.resolve_environment(request.headers.get("X-App-Environment"))
    db_type = settings.resolve_db_type(request.headers.get("X-DB-Type"))
    return database_connection_status(environment, db_type)


# Backward-compatibility alias for a typo that existed in some copied UI builds.
# Keep this hidden from Swagger so /system/database-status remains the canonical API.
@router.get("/system/database-sttaus", include_in_schema=False)
def database_status_typo_alias(request: Request):
    return database_status(request)
