"""Streamlit UI. All database operations are performed through the FastAPI layer."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import pandas as pd
import requests
import streamlit as st
from streamlit_modal import Modal

from DataDictionaryAdminApp.service.excel_service import STANDARD_FIELDS
from DataDictionaryAdminApp.utils.normalizers import canonical_portfolio_label, generate_physical_name, generate_tech_logic, portfolio_from_sheet_name


def load_env() -> None:
    candidates = [Path.cwd() / ".env", *[parent / ".env" for parent in Path(__file__).resolve().parents]]
    for path in candidates:
        if path.exists():
            for raw in path.read_text(encoding="utf-8").splitlines():
                raw = raw.strip()
                if raw and not raw.startswith("#") and "=" in raw:
                    key, value = raw.split("=", 1)
                    os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))
            break


load_env()
API_BASE = os.getenv("API_BASE_URL", "http://localhost:8503/api/v1").rstrip("/")
API = API_BASE if API_BASE.endswith("/api/v1") else API_BASE + "/api/v1"
READ_TIMEOUT = int(os.getenv("API_READ_TIMEOUT_SECONDS", "120"))
WRITE_TIMEOUT = int(os.getenv("API_WRITE_TIMEOUT_SECONDS", "600"))
CURRENT_USER = os.getenv("USERNAME") or os.getenv("USER") or os.getenv("DEFAULT_USER", "sysuser")
HTTP = requests.Session()

st.set_page_config(page_title="PRJ Data Dictionary Administration Platform", page_icon="📚", layout="wide")
st.markdown(
    """
<style>
.stApp { background:#f8fafc; }
.block-container { padding-top:1rem; max-width:1700px; }
.dd-hero { padding:1rem 1.2rem; background:#eaf2fb; border:1px solid #b7c9db; border-radius:8px; margin-bottom:1rem; }
.dd-hero h1 { margin:0; font-size:1.55rem; color:#24486f; }
.dd-hero p { margin:.25rem 0 0; color:#52677e; }
[data-testid="stSidebar"] { background:#f0f5fa; border-right:1px solid #c6d6e5; }
.stTabs [data-baseweb="tab"] { background:#f0f5fa; border:1px solid #c6d6e5; border-radius:6px; padding:0 .9rem; }
.stTabs [aria-selected="true"] { background:#dceafa !important; border-color:#86a7c8 !important; }
[data-testid="stDataFrame"], [data-testid="stDataEditor"] { border:1px solid #c6d6e5; border-radius:6px; overflow:hidden; }
.small-note { color:#5b6f84; font-size:.84rem; }
</style>
""",
    unsafe_allow_html=True,
)
st.markdown(
    """
<div class="dd-hero">
  <h1>PRJ Data Dictionary Administration Platform</h1>
  <p>Raw → staging → final governance, multi-sheet ingestion, prompt maintenance, audit history and S3 export.</p>
</div>
""",
    unsafe_allow_html=True,
)


def headers() -> dict[str, str]:
    return {
        "X-App-Environment": st.session_state.get("environment", os.getenv("SELECTED_ENVIRONMENT", "LOCAL")),
        "X-DB-Type": st.session_state.get("database_type", os.getenv("SELECTED_DB_TYPE", "SQLSERVER")),
        "X-App-User": CURRENT_USER,
        "X-App-Role": st.session_state.get("role", os.getenv("SELECTED_ROLE", "ADMIN")).upper(),
        "Accept": "application/json",
    }


def api(method: str, path: str, *, quiet: bool = False, binary: bool = False, **kwargs):
    timeout = READ_TIMEOUT if method.upper() == "GET" else WRITE_TIMEOUT
    try:
        response = HTTP.request(method, API + path, headers=headers(), timeout=timeout, **kwargs)
    except requests.RequestException as exc:
        if not quiet:
            st.error(f"API connection failed: {exc}")
        return None
    if not response.ok:
        if not quiet:
            try:
                detail = response.json().get("detail", response.json())
            except Exception:
                detail = response.text
            st.error(f"API error {response.status_code}: {detail}")
        return None
    return response if binary else response.json()


def database_status_check() -> dict[str, Any]:
    """Check DB connectivity through FastAPI, with a local diagnostic fallback.

    The fallback is deliberately limited to ``SELECT 1`` connectivity diagnostics;
    normal application reads/writes continue to go through FastAPI only. This also
    gives a useful message when Streamlit has been updated but an older FastAPI
    process is still running without the database-status endpoint.
    """
    api_issue = None
    try:
        response = HTTP.get(API + "/system/database-status", headers=headers(), timeout=READ_TIMEOUT)
        if response.ok:
            result = response.json()
            result["status_source"] = "API"
            return result
        try:
            detail = response.json().get("detail", response.json())
        except Exception:
            detail = response.text
        api_issue = f"HTTP {response.status_code}: {detail}"
    except requests.RequestException as exc:
        api_issue = str(exc)

    try:
        from DataDictionaryAdminApp.core.database import database_connection_status

        result = database_connection_status(
            st.session_state.get("environment", os.getenv("SELECTED_ENVIRONMENT", "LOCAL")),
            st.session_state.get("database_type", os.getenv("SELECTED_DB_TYPE", "SQLSERVER")),
        )
        result["status_source"] = "DIRECT_FALLBACK"
        result["api_issue"] = api_issue
        return result
    except Exception as exc:
        return {
            "connected": False,
            "issue": f"API status check failed: {api_issue or 'unknown error'}; direct database check failed: {exc}",
            "status_source": "FAILED",
            "api_issue": api_issue,
        }


for key, default in {
    "environment": os.getenv("SELECTED_ENVIRONMENT", "LOCAL"),
    "database_type": os.getenv("SELECTED_DB_TYPE", "SQLSERVER").upper(),
    "role": os.getenv("SELECTED_ROLE", "ADMIN").upper(),
    "view_rows": [],
    "view_total": 0,
    "selected_prj": "",
    "upload_preview": None,
    "upload_configs": [],
    "latest_excel": None,
    "show_create": False,
    "show_edit": False,
    "edit_unlocked": False,
    "show_finalize_confirm": False,
    "show_soft_deleted": False,
    "database_status_key": "",
    "database_status": None,
    "flash_message": None,
}.items():
    st.session_state.setdefault(key, default)

context = api("GET", "/system/context", quiet=True) or {
    "environment": st.session_state["environment"],
    "environments": ["LOCAL", "DEV", "UAT", "PROD"],
    "db_type": st.session_state["database_type"],
    "db_types": ["SQLSERVER", "POSTGRES"],
    "database": "Unknown",
    "server": "Unknown",
    "current_user": CURRENT_USER,
    "role": st.session_state.get("role", "ADMIN"),
    "is_admin": st.session_state.get("role", "ADMIN") == "ADMIN",
}

with st.sidebar:
    st.subheader("Runtime Context")
    environments = context.get("environments") or ["LOCAL"]
    current_env = st.session_state.get("environment", environments[0])
    if current_env not in environments:
        current_env = environments[0]
    selected_env = st.selectbox("Environment", environments, index=environments.index(current_env))
    if selected_env != st.session_state.get("environment"):
        st.session_state["environment"] = selected_env
        st.rerun()

    # Always expose both supported database engines. Whether an engine is enabled
    # for the selected environment is shown below without removing the selector.
    db_types = ["SQLSERVER", "POSTGRES"]
    db_labels = {"SQLSERVER": "SQL Server", "POSTGRES": "PostgreSQL"}
    current_db_type = st.session_state.get("database_type", "SQLSERVER").upper()
    if current_db_type not in db_types:
        current_db_type = "SQLSERVER"
    selected_db_type = st.selectbox(
        "Database Type",
        db_types,
        index=db_types.index(current_db_type),
        format_func=lambda value: db_labels[value],
    )
    if selected_db_type != st.session_state.get("database_type"):
        st.session_state["database_type"] = selected_db_type
        st.rerun()

    roles = ["ADMIN", "USER"]
    current_role = st.session_state.get("role", "ADMIN").upper()
    if current_role not in roles:
        current_role = "ADMIN"
    selected_role = st.selectbox(
        "Application Role",
        roles,
        index=roles.index(current_role),
        format_func=lambda value: "Admin" if value == "ADMIN" else "User",
    )
    if selected_role != st.session_state.get("role"):
        st.session_state["role"] = selected_role
        st.rerun()

    refreshed = api("GET", "/system/context", quiet=True) or context
    st.text_input("Database", value=str(refreshed.get("database", "Unknown")), disabled=True)
    st.text_input("Server", value=str(refreshed.get("server", "Unknown")), disabled=True)
    st.text_input("Current User", value=str(refreshed.get("current_user", CURRENT_USER)), disabled=True)
    st.text_input("Access", value=str(refreshed.get("role", st.session_state.get("role", "USER"))), disabled=True)

    status_key = f"{st.session_state['environment']}:{st.session_state['database_type']}"
    if st.session_state.get("database_status_key") != status_key:
        st.session_state["database_status"] = database_status_check()
        st.session_state["database_status_key"] = status_key
    if st.button("Test Database Connection", use_container_width=True):
        st.session_state["database_status"] = database_status_check()
    db_status = st.session_state.get("database_status")
    selected_db_label = db_labels.get(st.session_state["database_type"], st.session_state["database_type"])
    if db_status and db_status.get("connected"):
        st.success(f"{selected_db_label}: Connected")
    elif db_status:
        st.error(f"{selected_db_label}: Not connected")
        st.caption(str(db_status.get("issue") or "Unknown database connection error."))
    if db_status and db_status.get("status_source") == "DIRECT_FALLBACK":
        st.caption(
            "Connectivity was checked directly because the FastAPI database-status endpoint was unavailable. "
            "Restart FastAPI after replacing the latest files."
        )
        if db_status.get("api_issue"):
            st.caption(f"API status issue: {db_status['api_issue']}")

    if not refreshed.get("database_enabled", False):
        st.warning("Database access is disabled for this environment.")

lookups = api("GET", "/lookups", quiet=True) or {"portfolios": [], "sources": [], "sections": [], "subsections": []}
portfolio_labels = list(dict.fromkeys(
    item.get("label") for item in lookups.get("portfolios", []) if item.get("label")
))
bulk_portfolio_options = list(portfolio_labels)
source_options = list(dict.fromkeys(
    item.get("source_code") for item in lookups.get("sources", []) if item.get("source_code")
))
source_names = [item.get("source_name") for item in lookups.get("sources", []) if item.get("source_name")]
source_by_code = {item.get("source_code"): item.get("source_name") for item in lookups.get("sources", [])}

def source_label(code: str) -> str:
    return f"{code}[{source_by_code.get(code, code)}]"

create_modal = Modal("Create New Attribute", key="create_attribute_modal", max_width=1450)
edit_modal = Modal("Edit Attribute", key="edit_attribute_modal", max_width=1450)
finalize_modal = Modal("Finalize and Upload", key="finalize_modal", max_width=720)


def attribute_form(prefix: str, detail: dict[str, Any] | None = None, locked: bool = False) -> dict[str, Any] | None:
    detail = detail or {}
    rules = detail.get("rules") or []
    rule_index = 0
    if rules:
        labels = [f"{r.get('portfolio')} | {r.get('source_abbr_name')} | {r.get('section')} / {r.get('subsection')}" for r in rules]
        selected = st.selectbox("Portfolio / Scope record", range(len(rules)), format_func=lambda i: labels[i], key=f"{prefix}_rule")
        rule_index = int(selected)
    rule = rules[rule_index] if rules else {}

    next_id = api("GET", "/lookups/next-prj-id", quiet=True) if not detail else None
    prj_id = detail.get("prj_id") or (next_id or {}).get("prj_id", "Auto")
    st.text_input("PRJID", value=str(prj_id), disabled=True, key=f"{prefix}_prj")
    c1, c2 = st.columns(2)
    attribute_name = c1.text_input("PRJ Attribute Name *", value=str(detail.get("prj_attribute_name") or ""), disabled=locked, key=f"{prefix}_name")
    physical_default = str(detail.get("prj_physical_attribute_name") or "").strip()
    physical = physical_default
    suggestion = None
    if attribute_name and not physical_default:
        suggestion = api(
            "GET",
            "/lookups/physical-name-suggestions",
            quiet=True,
            params={"attribute_name": attribute_name, "prj_id": detail.get("prj_id") or str(prj_id)},
        )
        physical = str((suggestion or {}).get("selected") or (suggestion or {}).get("generated") or generate_physical_name(attribute_name))
    elif attribute_name and not locked:
        suggestion = api(
            "GET",
            "/lookups/physical-name-suggestions",
            quiet=True,
            params={"attribute_name": attribute_name, "prj_id": detail.get("prj_id") or str(prj_id)},
        )

    if detail:
        physical = c2.text_input(
            "PRJ Physical Attribute Name *",
            value=physical,
            disabled=locked,
            key=f"{prefix}_physical",
        )
    else:
        # New UI attributes are generated by the application. The backend repeats
        # the uniqueness check before staging, so concurrent users are also safe.
        physical_key = f"{prefix}_physical_{physical or 'blank'}"
        c2.text_input(
            "PRJ Physical Attribute Name *",
            value=physical,
            disabled=True,
            key=physical_key,
            help="Auto-generated from Attribute Name and checked for uniqueness across raw, staging and final tables.",
        )
    if suggestion and not locked:
        alternatives = [
            item["name"] for item in suggestion.get("suggestions", [])
            if item.get("available") and item.get("name") != physical
        ]
        if alternatives:
            st.caption("Alternative unique physical names: " + ", ".join(alternatives[:3]))

    c1, c2, c3 = st.columns(3)
    portfolio_default = str(rule.get("portfolio") or (portfolio_labels[0] if portfolio_labels else ""))
    p_options = list(portfolio_labels)
    if portfolio_default and portfolio_default not in p_options:
        p_options.insert(0, portfolio_default)
    if not p_options:
        c1.error("No portfolio values returned from dbo.prj_portfolio_reference_new_test.")
        p_options = [""]
    p_index = p_options.index(portfolio_default) if portfolio_default in p_options else 0
    portfolio = c1.selectbox("Portfolio / Scope *", p_options, index=p_index, disabled=locked, key=f"{prefix}_portfolio")
    src_code = str(rule.get("source_abbr_name") or (source_options[0] if source_options else "SNPAR"))
    s_options = list(source_options)
    if src_code and src_code not in s_options:
        s_options.insert(0, src_code)
    s_options = s_options or ["SNPAR"]
    s_index = s_options.index(src_code) if src_code in s_options else 0
    source_code = c2.selectbox("Source *", s_options, index=s_index, format_func=source_label, disabled=locked, key=f"{prefix}_source")
    current_symbol = str(rule.get("symbol") or "Amount")
    dtype_options = ["Amount", "%", "Ratio", "actual", "Other"]
    if current_symbol not in dtype_options:
        dtype_options.insert(0, current_symbol)
    dtype_index = dtype_options.index(current_symbol) if current_symbol in dtype_options else 0
    data_type = c3.selectbox("DATA TYPE", dtype_options, index=dtype_index, disabled=locked, key=f"{prefix}_dtype")

    c1, c2 = st.columns(2)
    section = c1.text_input("Section *", value=str(rule.get("section") or ""), disabled=locked, key=f"{prefix}_section")
    subsection = c2.text_input("Sub-Section *", value=str(rule.get("subsection") or ""), disabled=locked, key=f"{prefix}_subsection")
    mapping_default = str(rule.get("mapping_type") or "Reported")
    mapping_options = ["Calculated", "Reported", "Repeated"]
    mapping_index = mapping_options.index(mapping_default) if mapping_default in mapping_options else 1
    calculated = st.selectbox("Calculated or Reported *", mapping_options, index=mapping_index, disabled=locked, key=f"{prefix}_mapping")
    calculation_logic = st.text_area("Calculation Logic", value=str(rule.get("calculation_logic") or "NA"), disabled=locked, height=120, key=f"{prefix}_calc")
    segment = st.text_input("Segment", value=str(detail.get("where_in_financial_statement") or "NA"), disabled=locked, key=f"{prefix}_segment")
    attribute_definition = st.text_area("Attribute Definition", value=str(detail.get("prj_attribute_definition") or ""), disabled=locked, height=100, key=f"{prefix}_definition")
    attribute_description = st.text_area("Attribute Description / Proposed Prompt", value=str(rule.get("prj_attribute_description") or ""), disabled=locked, height=120, key=f"{prefix}_description")
    c1, c2 = st.columns(2)
    display_order = c1.number_input("Display Order *", min_value=0, value=int(rule.get("display_order") or 0), step=1, disabled=locked, key=f"{prefix}_order")
    display_name = c2.text_input("Display Name", value=str(rule.get("display_name") or detail.get("prj_attribute_name") or ""), disabled=locked, key=f"{prefix}_display")
    tech_preview = str(rule.get("tech_logic") or generate_tech_logic(calculation_logic))
    tech_logic = st.text_area(
        "Tech Logic",
        value=tech_preview,
        disabled=locked,
        height=120,
        key=f"{prefix}_tech",
        help="Auto-populated from Calculation Logic when blank; it can be updated before saving.",
    )
    examples = st.text_area("Examples (Prompt Management)", value=str(rule.get("examples") or ""), disabled=locked, height=80, key=f"{prefix}_examples")

    if locked:
        return None
    submitted = st.button("Create Attribute" if not detail else "Save Changes", type="primary", key=f"{prefix}_submit")
    if not submitted:
        return None
    if not attribute_name.strip() or not section.strip() or not subsection.strip():
        st.error("PRJ Attribute Name, Section and Sub-Section are mandatory.")
        return None
    return {
        "prj_id": None if not detail else detail.get("prj_id"),
        "portfolio": portfolio,
        "source_abbr_name": source_code,
        "prj_attribute_name": attribute_name,
        "prj_physical_attribute_name": physical or None,
        "physical_name_source": "SUPPLIED" if detail else "AUTO",
        "section": section,
        "sub_section": subsection,
        "data_type": data_type,
        "calculated_or_reported": calculated,
        "calculation_logic": calculation_logic or "NA",
        "segment": segment or "NA",
        "attribute_definition": attribute_definition or None,
        "attribute_description": attribute_description or None,
        "tech_logic": tech_logic or None,
        "display_order": int(display_order),
        "display_name": display_name or attribute_name,
        "examples": examples or None,
        "is_active": True,
    }


is_admin = bool(refreshed.get("is_admin"))
main_tab_labels = ["Data Dictionary", "Prompt Management", "Audit"] + (["Admin Tools"] if is_admin else [])
main_tabs = st.tabs(main_tab_labels)

if st.session_state.get("flash_message"):
    st.success(st.session_state.pop("flash_message"))

with main_tabs[0]:
    workflow_labels = ["View / Edit Latest"] + (["Upload & Edit"] if is_admin else []) + ["Finalize and Upload"]
    workflow_tabs = st.tabs(workflow_labels)
    view_edit_tab = workflow_tabs[0]
    upload_tab = workflow_tabs[1] if is_admin else None
    finalize_tab = workflow_tabs[2] if is_admin else workflow_tabs[1]

    with view_edit_tab:
        st.subheader("View Latest")
        f1, f2, f3, f4 = st.columns(4)
        portfolios = f1.multiselect("Portfolio", portfolio_labels)
        sources = f2.multiselect("Source", source_options, format_func=source_label)
        prj_filter = f3.text_input("PRJ_ID")
        name_filter = f4.text_input("Attribute Name")
        f1, f2, f3, f4 = st.columns(4)
        definition_filter = f1.text_input("Attribute Definition")
        section_filter = f2.selectbox("Section", [""] + list(lookups.get("sections", [])))
        subsection_filter = f3.selectbox("Sub-Section", [""] + list(lookups.get("subsections", [])))
        overlapped = f4.checkbox("Overlapped Attribute only")
        c1, c2, c3, c4 = st.columns([1, 1, 1, 3])
        include_deleted = c1.checkbox("Include inactive", value=False)
        page_size = c2.selectbox("Rows", [50, 100, 250, 500], index=1)
        page_number = c3.number_input("Page", min_value=1, value=1, step=1)
        search = c4.text_input("Search")

        payload = {
            "portfolios": portfolios,
            "sources": sources,
            "prj_id": prj_filter or None,
            "attribute_name": name_filter or None,
            "attribute_definition": definition_filter or None,
            "section": section_filter or None,
            "subsection": subsection_filter or None,
            "search": search or None,
            "overlapped_only": overlapped,
            "include_deleted": include_deleted,
            "page": int(page_number),
            "page_size": page_size,
        }

        create_col, deleted_col, _ = st.columns([1.7, 2.0, 5])
        if create_col.button("Create New Attribute", type="primary", use_container_width=True):
            st.session_state["show_create"] = True
            create_modal.open()
        if deleted_col.button(
            "Hide Soft Deleted Records" if st.session_state.get("show_soft_deleted") else "View Soft Deleted Records",
            use_container_width=True,
        ):
            st.session_state["show_soft_deleted"] = not st.session_state.get("show_soft_deleted", False)
            st.rerun()

        if st.session_state.get("show_soft_deleted"):
            deleted_rows = api("GET", "/data-dictionary/soft-deleted", quiet=True) or []
            st.markdown("#### Soft Deleted Records")
            st.caption(
                "These records are inactive in the final tables. Pending soft deletes remain in Delta until finalized."
            )
            if deleted_rows:
                deleted_frame = pd.DataFrame(deleted_rows)
                deleted_columns = [
                    "prj_id", "prj_attribute_name", "prj_attribute_definition",
                    "prj_physical_attribute_name", "portfolios", "sources",
                    "section", "subsection", "is_active",
                ]
                st.dataframe(
                    deleted_frame[[column for column in deleted_columns if column in deleted_frame.columns]],
                    use_container_width=True,
                    hide_index=True,
                    height=300,
                )
                deleted_ids = [str(row.get("prj_id")) for row in deleted_rows if row.get("prj_id")]
                reactivate_prj = st.selectbox(
                    "Select soft deleted attribute to reactivate",
                    [""] + deleted_ids,
                    key="soft_deleted_selected_prj",
                )
                if st.button(
                    "Reactivate Selected Soft Deleted Record",
                    disabled=not reactivate_prj,
                    key="reactivate_soft_deleted",
                ):
                    response = api("POST", f"/data-dictionary/attributes/{reactivate_prj}/reactivate")
                    if response:
                        st.success("Reactivation staged. Review Delta, then Finalize and Upload.")
            else:
                st.info("No finalized soft deleted records found.")
            st.divider()

        result = api("POST", "/data-dictionary/filter-page", json=payload, quiet=True)
        if result:
            st.session_state["view_rows"] = result.get("rows", [])
            st.session_state["view_total"] = result.get("total", 0)
        rows = st.session_state.get("view_rows", [])

        b1, b2, b3, b4 = st.columns([1.2, 1.2, 1.2, 4])
        if b1.button("View Latest", use_container_width=True):
            result = api("POST", "/data-dictionary/filter-page", json=payload)
            if result:
                st.session_state["view_rows"] = result.get("rows", [])
                rows = st.session_state["view_rows"]
        if b2.button("Download Latest", use_container_width=True):
            response = api("GET", "/data-dictionary/download-latest", binary=True)
            if response:
                st.session_state["latest_excel"] = response.content
        if st.session_state.get("latest_excel"):
            b3.download_button(
                "Download Excel",
                st.session_state["latest_excel"],
                "prj_master_dictionary_latest.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True,
            )
        b4.caption(f"{st.session_state.get('view_total', 0)} matching attribute(s)")

        if rows:
            grid_columns = [
                "prj_id", "prj_attribute_name", "prj_attribute_definition", "prj_physical_attribute_name",
                "editable", "symbol", "portfolios", "sources", "section", "subsection", "is_active",
            ]
            frame = pd.DataFrame(rows)
            visible_frame = frame[[c for c in grid_columns if c in frame.columns]].reset_index(drop=True)
            grid_event = st.dataframe(
                visible_frame,
                use_container_width=True,
                hide_index=True,
                height=430,
                key="view_latest_grid",
                on_select="rerun",
                selection_mode="single-row",
            )
            selected_indexes = list(getattr(grid_event.selection, "rows", []) or [])
            selected_row = frame.iloc[selected_indexes[0]].to_dict() if selected_indexes else None
            selected_prj = str(selected_row.get("prj_id")) if selected_row and selected_row.get("prj_id") else ""
            if selected_prj:
                st.caption(f"Selected attribute: {selected_prj} - {selected_row.get('prj_attribute_name', '')}")

            action1, action2, action3, _ = st.columns([1.2, 1.2, 1.2, 4])
            if action1.button("Edit", disabled=not selected_prj, use_container_width=True):
                st.session_state["selected_prj"] = selected_prj
                st.session_state["show_edit"] = True
                st.session_state["edit_unlocked"] = True
                edit_modal.open()
            if action2.button("Soft Delete", disabled=not selected_prj, use_container_width=True):
                response = api("DELETE", f"/data-dictionary/attributes/{selected_prj}")
                if response:
                    st.session_state["flash_message"] = (
                        f"{selected_prj} soft delete staged successfully. Review Delta, then Finalize and Upload."
                    )
                    st.rerun()
            if action3.button("Reactivate", disabled=not selected_prj, use_container_width=True):
                response = api("POST", f"/data-dictionary/attributes/{selected_prj}/reactivate")
                if response:
                    st.session_state["flash_message"] = (
                        f"{selected_prj} reactivation staged successfully. Review Delta, then Finalize and Upload."
                    )
                    st.rerun()
        else:
            st.info("No records loaded for the selected filters.")

    if is_admin and upload_tab is not None:
        with upload_tab:
            st.subheader("Bulk Upload: Single Sheet or Multi-Sheet Merger")
            st.caption(
                "Each selected sheet has its own header row, data-start row, portfolio and source-column mapping. "
                "Portfolio is auto-detected from the sheet name when possible and can be changed from the dropdown."
            )
            uploaded = st.file_uploader("Master Dictionary Excel", type=["xlsx"], key="master_upload_file")
            if uploaded:
                file_tuple = (uploaded.name, uploaded.getvalue(), uploaded.type or "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                sheets_result = api("POST", "/master-upload/sheets", files={"file": file_tuple})
                sheets = sheets_result.get("sheets", []) if sheets_result else []
                mode_type = st.radio("Sheet mode", ["Single Sheet", "Multi-Sheet Merger"], horizontal=True)
                selected_sheets = (
                    [st.selectbox("Sheet", sheets)] if mode_type == "Single Sheet" and sheets
                    else st.multiselect("Sheets to merge", sheets, default=sheets[: min(2, len(sheets))])
                )
                configs: list[dict[str, Any]] = []
                for sheet_name in selected_sheets:
                    with st.expander(f"Mapping: {sheet_name}", expanded=True):
                        c1, c2, c3 = st.columns(3)
                        header_row = c1.number_input(
                            "Header row (1-based)",
                            min_value=1,
                            max_value=50,
                            value=2,
                            step=1,
                            key=f"header_{sheet_name}",
                            help="Excel row containing the actual column names.",
                        )
                        data_start_key = f"data_start_{sheet_name}"
                        minimum_data_row = int(header_row) + 1
                        if data_start_key not in st.session_state:
                            st.session_state[data_start_key] = minimum_data_row
                        elif int(st.session_state[data_start_key]) < minimum_data_row:
                            st.session_state[data_start_key] = minimum_data_row
                        data_start_row = c2.number_input(
                            "Data starts at row (1-based)",
                            min_value=minimum_data_row,
                            max_value=500,
                            step=1,
                            key=data_start_key,
                            help="Use this to skip second/third header or explanatory rows after the selected header row.",
                        )
                        detected_portfolio = portfolio_from_sheet_name(sheet_name)
                        detected_portfolio_label = canonical_portfolio_label(detected_portfolio) if detected_portfolio else ""
                        portfolio_choices = [""] + list(bulk_portfolio_options)
                        portfolio_index = (
                            portfolio_choices.index(detected_portfolio_label)
                            if detected_portfolio_label in portfolio_choices
                            else 0
                        )
                        portfolio_override = c3.selectbox(
                            "Portfolio",
                            portfolio_choices,
                            index=portfolio_index,
                            key=f"port_{sheet_name}",
                            format_func=lambda value: value or "Auto-detect from sheet name",
                            help=(
                                "Automatically defaults from the sheet name: e.g. 'Insurance Attribute' → FI Insurance, "
                                "'Bank Attribute' → FI Banks. Select another value only when you want to override detection."
                            ),
                        )
                        preview = api(
                            "POST",
                            "/master-upload/preview-sheet",
                            files={"file": file_tuple},
                            data={
                                "sheet_name": sheet_name,
                                "header_row": int(header_row),
                                "data_start_row": int(data_start_row),
                            },
                            quiet=True,
                        )
                        mapping: dict[str, str] = {}
                        if preview:
                            st.caption(
                                f"Portfolio from sheet name: {preview.get('portfolio_detected') or 'Not detected'} | "
                                f"Rows skipped after header: {preview.get('skipped_rows_after_header', 0)}"
                            )
                            columns = [""] + preview.get("columns", [])
                            detected = preview.get("detected_mapping", {})
                            map_cols = st.columns(3)
                            for index, field in enumerate(STANDARD_FIELDS):
                                default_column = detected.get(field, "")
                                default_index = columns.index(default_column) if default_column in columns else 0
                                selected_column = map_cols[index % 3].selectbox(
                                    field,
                                    columns,
                                    index=default_index,
                                    key=f"map_{sheet_name}_{field}",
                                )
                                if selected_column:
                                    mapping[field] = selected_column
                            st.dataframe(pd.DataFrame(preview.get("preview", [])), use_container_width=True, hide_index=True, height=220)
                        configs.append({
                            "sheet_name": sheet_name,
                            "header_row": int(header_row),
                            "data_start_row": int(data_start_row),
                            "portfolio_override": portfolio_override,
                            "mapping": mapping,
                        })
                upload_mode = st.radio(
                    "Database raw-load mode",
                    ["MERGE", "INSERT_ONLY", "REPLACE"],
                    horizontal=True,
                    help=(
                        "MERGE inserts new and updates matching staged/raw records. "
                        "INSERT_ONLY skips PRJ IDs already present in raw, staging or final tables. "
                        "REPLACE clears current raw/staging pending data before loading; final tables remain unchanged until finalization."
                    ),
                )
                backend_health = api("GET", "/health", quiet=True) or {}
                backend_modes = backend_health.get("upload_modes") or []
                backend_supports_current_mode = upload_mode in backend_modes
                if backend_health and not backend_supports_current_mode:
                    st.error(
                        "The FastAPI process is running an older application build and does not advertise support for "
                        f"{upload_mode}. Restart FastAPI using the latest project files before validating or staging."
                    )
                u1, u2 = st.columns(2)
                if u1.button(
                    "Validate and Compare",
                    disabled=not configs or (bool(backend_health) and not backend_supports_current_mode),
                ):
                    preview = api(
                        "POST",
                        "/master-upload/preview",
                        files={"file": file_tuple},
                        data={"configurations_json": json.dumps(configs), "mode": upload_mode},
                    )
                    st.session_state["upload_preview"] = preview
                if u2.button(
                    "Stage Uploaded Data",
                    type="primary",
                    disabled=(
                        not configs
                        or not refreshed.get("is_admin")
                        or (bool(backend_health) and not backend_supports_current_mode)
                    ),
                ):
                    result = api(
                        "POST",
                        "/master-upload/finalize",
                        files={"file": file_tuple},
                        data={"configurations_json": json.dumps(configs), "mode": upload_mode},
                    )
                    if result:
                        st.success(
                            f"Staged {result.get('staged_count', 0)} rows; "
                            f"skipped existing {result.get('skipped_existing_count', 0)} PRJ ID(s); "
                            f"rejected {result.get('rejected_count', 0)} rows."
                        )
                        st.session_state["upload_preview"] = result
                if st.session_state.get("upload_preview"):
                    st.json(st.session_state["upload_preview"])

    with finalize_tab:
        st.subheader("Finalize and Upload")
        delta = api("GET", "/data-dictionary/delta", quiet=True) or {"rows": [], "has_changes": False, "count": 0}
        st.caption(f"Pending delta: {delta.get('count', 0)} attribute(s)")
        if delta.get("rows"):
            st.dataframe(pd.DataFrame(delta["rows"]), use_container_width=True, hide_index=True)
        else:
            st.info("No staged changes. Finalize is disabled.")
        if is_admin:
            c1, c2 = st.columns(2)
        else:
            c1 = st.container()
            c2 = None
        if c1.button("Finalize and Upload", type="primary", disabled=not delta.get("has_changes"), use_container_width=True):
            finalize_modal.open()
        if is_admin and c2 is not None:
            if c2.button("Save Final Tables to S3", use_container_width=True):
                result = api("POST", "/s3/export-final")
                if result:
                    st.success(f"Uploaded {len(result.get('files', []))} final-table extract(s) to S3.")
                    st.json(result)

with main_tabs[1]:
    st.subheader("Prompt Management")
    prompts = api("GET", "/prompts?include_deleted=true", quiet=True) or []
    if prompts:
        search_prompt = st.text_input("Search prompts")
        filtered = prompts
        if search_prompt:
            needle = search_prompt.lower()
            filtered = [row for row in prompts if needle in json.dumps(row, default=str).lower()]
        st.dataframe(pd.DataFrame(filtered), use_container_width=True, hide_index=True, height=420)
        scope_ids = [int(row["scope_id"]) for row in filtered]
        selected_scope = st.selectbox("Select scope_id", scope_ids)
        current = next(row for row in filtered if int(row["scope_id"]) == int(selected_scope))
        prompt_description = st.text_area("Prompt Description", value=str(current.get("prompt_description") or ""), height=150)
        examples = st.text_area("Examples", value=str(current.get("examples") or ""), height=120)
        if st.button("Stage Prompt Changes", type="primary"):
            response = api("PUT", f"/prompts/{selected_scope}", json={"scope_id": selected_scope, "prompt_description": prompt_description or None, "examples": examples or None})
            if response:
                st.success("Prompt changes staged. Use Finalize and Upload in Data Dictionary to publish them.")
    else:
        st.info("No prompt/business-rule rows available.")

with main_tabs[2]:
    st.subheader("Audit History")
    a1, a2, a3, a4 = st.columns(4)
    table_name = a1.text_input("Table")
    action = a2.text_input("Action")
    performed_by = a3.text_input("Performed By")
    source_operation = a4.text_input("Source Operation")
    audit_search = st.text_input("Search before/after values")
    audit_rows = api("POST", "/audit/filter", json={
        "table_name": table_name or None,
        "action": action or None,
        "performed_by": performed_by or None,
        "source_operation": source_operation or None,
        "search": audit_search or None,
    }, quiet=True) or []
    if audit_rows:
        st.dataframe(pd.DataFrame(audit_rows), use_container_width=True, hide_index=True, height=520)
    else:
        st.info("No audit rows found for the selected filters.")

if is_admin:
    with main_tabs[3]:
        st.subheader("Admin Tools")
        portfolios_admin = api("GET", "/portfolio-reference", quiet=True) or []
        st.markdown("#### Portfolio Reference")
        if portfolios_admin:
            st.dataframe(pd.DataFrame(portfolios_admin), use_container_width=True, hide_index=True)
        with st.expander("Add Portfolio"):
            c1, c2 = st.columns(2)
            p_name = c1.text_input("Portfolio Name")
            sector = c2.text_input("Sector Name")
            sub_sector = c1.text_input("Sub-Sector")
            remark = c2.text_input("Remark")
            if st.button("Insert Portfolio", disabled=not refreshed.get("is_admin")):
                result = api("POST", "/portfolio-reference", json={
                    "portfolio_name": p_name,
                    "sector_name": sector,
                    "sub_sector": sub_sector or None,
                    "remark": remark or None,
                })
                if result:
                    st.success(f"Created port_ref_id {result.get('port_ref_id')}")
        st.markdown("#### Deployment")
        st.code("poetry run uvicorn DataDictionaryAdminApp.api.swagger_app:app --host 0.0.0.0 --port 8503")
        st.code("poetry run streamlit run src/DataDictionaryAdminApp/streamlit_app.py --server.port 8501")
        if refreshed.get("db_type") == "POSTGRES":
            st.caption("Run sql/postgres/001_create_tables.sql, then sql/postgres/002_validate_schema.sql before enabling PostgreSQL writes.")
        else:
            st.caption("Run sql/001_create_tables.sql, then sql/002_validate_schema.sql before enabling SQL Server writes.")

if st.session_state.get("show_create"):
    if not create_modal.is_open():
        create_modal.open()
    if create_modal.is_open():
        with create_modal.container():
            payload = attribute_form("create")
            if payload:
                result = api("POST", "/data-dictionary/attributes", json=payload)
                if result:
                    staged_tables = ", ".join(result.get("staged_tables", []))
                    generated_id = result.get("cfv_id") or result.get("prj_id")
                    st.session_state["flash_message"] = (
                        f"CFV ID generated: {generated_id}. Attribute staged successfully. "
                        f"Physical name: {result.get('prj_physical_attribute_name')}. "
                        f"Saved to: {staged_tables}"
                    )
                    st.session_state["show_create"] = False
                    create_modal.close()
                    st.rerun()
            if st.button("Close", key="create_close"):
                st.session_state["show_create"] = False
                create_modal.close()
                st.rerun()

if st.session_state.get("show_edit"):
    selected_prj = st.session_state.get("selected_prj")
    detail = api("GET", f"/data-dictionary/attributes/{selected_prj}", quiet=True) if selected_prj else None
    if not edit_modal.is_open():
        edit_modal.open()
    if edit_modal.is_open():
        with edit_modal.container():
            if detail:
                payload = attribute_form("edit", detail, locked=False)
                if payload:
                    result = api("PUT", f"/data-dictionary/attributes/{selected_prj}", json=payload)
                    if result:
                        st.session_state["flash_message"] = (
                            f"{selected_prj} changes staged successfully. Review the delta before finalization."
                        )
                        st.session_state["show_edit"] = False
                        st.session_state["edit_unlocked"] = False
                        edit_modal.close()
                        st.rerun()
            if st.button("Close", key="edit_close"):
                st.session_state["show_edit"] = False
                st.session_state["edit_unlocked"] = False
                edit_modal.close()
                st.rerun()

if finalize_modal.is_open():
    with finalize_modal.container():
        st.warning("Do you want to update database tables?")
        c1, c2 = st.columns(2)
        if c1.button("Yes Upload", type="primary", use_container_width=True):
            result = api("POST", "/data-dictionary/finalize", json={"confirm": True})
            if result:
                st.success(result.get("message", "Finalized successfully."))
                finalize_modal.close()
                st.rerun()
        if c2.button("Cancel", use_container_width=True):
            finalize_modal.close()
            st.rerun()
