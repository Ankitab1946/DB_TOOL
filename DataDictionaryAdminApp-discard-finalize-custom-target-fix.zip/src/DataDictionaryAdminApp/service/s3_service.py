"""S3/S3-compatible export of the two final application tables."""
from __future__ import annotations

import csv
import io
from datetime import datetime, timezone
from typing import Any

import boto3
from botocore.config import Config
from sqlalchemy import select
from sqlalchemy.orm import Session

from DataDictionaryAdminApp.config import get_settings
from DataDictionaryAdminApp.core.target_tables import S3_EXPORTS, TARGET_TABLE_DEFAULTS
from DataDictionaryAdminApp.model.entities import AttributeBusinessRule, AttributeDisplay, AttributeMaster
from DataDictionaryAdminApp.repositories.data_dictionary_repository import combined_rule_dict, model_dict


class S3Service:
    def __init__(self, db: Session):
        self.db = db
        self.settings = get_settings()

    def _client(self):
        kwargs: dict[str, Any] = {
            "service_name": "s3",
            "region_name": self.settings.aws_region,
            "use_ssl": self.settings.s3_use_ssl,
            "verify": self.settings.s3_verify_ssl,
            "config": Config(s3={"addressing_style": self.settings.s3_addressing_style}),
        }
        if self.settings.effective_s3_endpoint_url:
            kwargs["endpoint_url"] = self.settings.effective_s3_endpoint_url
        if self.settings.aws_access_key_id:
            kwargs["aws_access_key_id"] = self.settings.aws_access_key_id
        if self.settings.aws_secret_access_key:
            kwargs["aws_secret_access_key"] = self.settings.aws_secret_access_key
        return boto3.client(**kwargs)

    @staticmethod
    def _csv_bytes(rows: list[dict[str, Any]]) -> bytes:
        stream = io.StringIO()
        if rows:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
        return stream.getvalue().encode("utf-8-sig")

    def export_final_tables(self) -> dict[str, Any]:
        bucket = self.settings.s3_bucket_name
        if not bucket:
            raise ValueError("S3_BUCKET_NAME is not configured.")
        client = self._client()
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        model_by_table = {
            "dbo.prj_attribute_master_new_test": AttributeMaster,
            "dbo.prj_attribute_business_rules_new_test": AttributeBusinessRule,
        }
        uploaded = []
        prefix = self.settings.s3_prefix.strip("/")
        target_names = self.db.info.get("target_table_names") or TARGET_TABLE_DEFAULTS
        main_schema = (str(self.db.info.get("pg_schema") or "prj_dbd")
                       if self.db.get_bind().dialect.name == "postgresql" else "dbo")
        actual_by_qualified = {
            "dbo.prj_attribute_master_new_test": f"{main_schema}.{target_names['final_master']}",
            "dbo.prj_attribute_business_rules_new_test": f"{main_schema}.{target_names['final_business']}",
        }
        for logical_name, qualified_table in S3_EXPORTS:
            model = model_by_table[qualified_table]
            if model is AttributeBusinessRule:
                rows = [
                    combined_rule_dict(rule, display)
                    for rule, display in self.db.execute(
                        select(AttributeBusinessRule, AttributeDisplay)
                        .join(AttributeDisplay, AttributeDisplay.scope_id == AttributeBusinessRule.scope_id)
                        .order_by(AttributeBusinessRule.scope_id)
                    ).all()
                ]
            else:
                rows = [model_dict(row) for row in self.db.scalars(select(model)).all()]
            actual_table = actual_by_qualified[qualified_table]
            actual_basename = actual_table.split(".", 1)[1]
            filename = f"{actual_basename}_{timestamp}.csv"
            key = f"{prefix}/{filename}" if prefix else filename
            client.put_object(Bucket=bucket, Key=key, Body=self._csv_bytes(rows), ContentType="text/csv")
            uploaded.append({"table": actual_table, "key": key, "rows": len(rows)})
        return {"bucket": bucket, "files": uploaded}
