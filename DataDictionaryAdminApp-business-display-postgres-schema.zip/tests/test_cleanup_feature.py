from pathlib import Path
from unittest.mock import MagicMock

import pytest
from fastapi import HTTPException
from starlette.requests import Request

from DataDictionaryAdminApp.api.routers.system import cleanup_database
from DataDictionaryAdminApp.api.schemas_api import CleanupRequest
from DataDictionaryAdminApp.repositories.data_dictionary_repository import DataDictionaryRepository


def request_with_headers(**headers: str) -> Request:
    raw_headers = [(key.lower().encode(), value.encode()) for key, value in headers.items()]
    return Request({"type": "http", "method": "POST", "path": "/api/v1/system/cleanup", "headers": raw_headers})


def test_repository_cleanup_hard_deletes_mutable_tables_and_custom_portfolios():
    db = MagicMock()
    db.scalar.side_effect = [2, 3, 4, 5, 6, 7, 8, 9, 10]

    deleted = DataDictionaryRepository(db).hard_delete_dictionary_data()

    assert len(deleted) == 9
    assert sum(deleted.values()) == 54
    assert deleted["dbo.prj_portfolio_reference_new_test (custom rows)"] == 10
    assert "dbo.prj_data_sources" not in deleted
    assert db.execute.call_count == 9
    assert db.scalar.call_count == 9


def test_cleanup_endpoint_requires_admin_and_two_confirmations():
    db = MagicMock()
    request = request_with_headers(**{"X-App-Role": "ADMIN", "X-App-User": "tester"})

    with pytest.raises(HTTPException) as exc:
        cleanup_database(CleanupRequest(), request, db)
    assert exc.value.status_code == 422

    with pytest.raises(HTTPException) as exc:
        cleanup_database(
            CleanupRequest(first_confirmation=True, second_confirmation=True, confirmation_text="wrong"),
            request,
            db,
        )
    assert exc.value.status_code == 422


def test_cleanup_endpoint_commits_and_returns_counts(monkeypatch):
    db = MagicMock()
    request = request_with_headers(**{"X-App-Role": "ADMIN", "X-App-User": "tester"})

    monkeypatch.setattr(
        DataDictionaryRepository,
        "hard_delete_dictionary_data",
        lambda self: {
            "dbo.raw_prj_attribute_new_test": 3,
            "stg.prj_attribute_master_new_test": 2,
        },
    )
    result = cleanup_database(
        CleanupRequest(
            first_confirmation=True,
            second_confirmation=True,
            confirmation_text="DELETE ALL DATA",
        ),
        request,
        db,
    )
    assert result["deleted_total"] == 5
    assert any("port_ref_id 1-4" in item for item in result["preserved_tables"])
    assert any("prj_data_sources" in item for item in result["preserved_tables"])
    db.commit.assert_called_once()


def test_cleanup_is_admin_only():
    db = MagicMock()
    request = request_with_headers(**{"X-App-Role": "USER", "X-App-User": "tester"})
    with pytest.raises(HTTPException) as exc:
        cleanup_database(
            CleanupRequest(
                first_confirmation=True,
                second_confirmation=True,
                confirmation_text="DELETE ALL DATA",
            ),
            request,
            db,
        )
    assert exc.value.status_code == 403


def test_streamlit_cleanup_has_two_confirmation_steps():
    source = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
    assert '"Cleanup Database"' in source
    assert "Confirmation 1 of 2" in source
    assert "Confirmation 2 of 2" in source
    assert '"DELETE ALL DATA"' in source
    assert '"/system/cleanup"' in source
