/* PostgreSQL deployment preflight. Raises an exception on any missing object/column. */
DO $$
DECLARE
    item text;
    required text[][] := ARRAY[
        ARRAY['dbo','raw_prj_attribute_new_test','portfolio'],
        ARRAY['dbo','raw_prj_attribute_new_test','prj_id'],
        ARRAY['dbo','raw_prj_attribute_new_test','prj_attribute_name'],
        ARRAY['dbo','raw_prj_attribute_new_test','prj_physical_attribute_name'],
        ARRAY['dbo','raw_prj_attribute_new_test','section'],
        ARRAY['dbo','raw_prj_attribute_new_test','sub_section'],
        ARRAY['dbo','raw_prj_attribute_new_test','data_type'],
        ARRAY['dbo','raw_prj_attribute_new_test','calculated_or_reported'],
        ARRAY['dbo','raw_prj_attribute_new_test','calculation_logic'],
        ARRAY['dbo','raw_prj_attribute_new_test','segment'],
        ARRAY['dbo','raw_prj_attribute_new_test','attribute_definition'],
        ARRAY['dbo','raw_prj_attribute_new_test','attribute_description'],
        ARRAY['dbo','raw_prj_attribute_new_test','display_order'],
        ARRAY['dbo','raw_prj_attribute_new_test','tech_logic'],
        ARRAY['dbo','raw_prj_attribute_new_test','display_name'],
        ARRAY['stg','prj_attribute_master_new_test','prj_id'],
        ARRAY['stg','prj_attribute_master_new_test','prj_attribute_definition'],
        ARRAY['stg','prj_attribute_master_new_test','where_in_financial_statement'],
        ARRAY['stg','prj_attribute_business_rules_new_test','scope_id'],
        ARRAY['stg','prj_attribute_business_rules_new_test','port_ref_id'],
        ARRAY['stg','prj_attribute_business_rules_new_test','source_abbr_name'],
        ARRAY['stg','prj_attribute_business_rules_new_test','editable'],
        ARRAY['stg','prj_attribute_business_rules_new_test','symbol'],
        ARRAY['stg','prj_attribute_business_rules_new_test','mapping_type'],
        ARRAY['stg','prj_attribute_business_rules_new_test','calculation_logic'],
        ARRAY['stg','prj_attribute_business_rules_new_test','prj_attribute_definition'],
        ARRAY['stg','prj_attribute_business_rules_new_test','prj_attribute_description'],
        ARRAY['stg','prj_attribute_business_rules_new_test','segment'],
        ARRAY['stg','prj_attribute_business_rules_new_test','tech_logic'],
        ARRAY['stg','prj_attribute_business_rules_new_test','display_order'],
        ARRAY['stg','prj_attribute_business_rules_new_test','display_name'],
        ARRAY['stg','prj_attribute_business_rules_new_test','section'],
        ARRAY['stg','prj_attribute_business_rules_new_test','subsection'],
        ARRAY['stg','prj_attribute_business_rules_new_test','prompt_description'],
        ARRAY['stg','prj_attribute_business_rules_new_test','examples'],
        ARRAY['dbo','prj_attribute_master_new_test','prj_id'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','scope_id'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','prj_attribute_definition'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','prj_attribute_description'],
        ARRAY['dbo','prj_attribute_business_rules_new_test','segment']
    ];
    rec text[];
BEGIN
    IF to_regnamespace('stg') IS NULL THEN
        RAISE EXCEPTION 'Schema validation failed: schema stg is missing.';
    END IF;

    FOREACH rec SLICE 1 IN ARRAY required LOOP
        IF NOT EXISTS (
            SELECT 1 FROM information_schema.columns c
            WHERE c.table_schema = rec[1] AND c.table_name = rec[2] AND c.column_name = rec[3]
        ) THEN
            item := rec[1] || '.' || rec[2] || '.' || rec[3];
            RAISE EXCEPTION 'Schema validation failed: % is missing.', item;
        END IF;
    END LOOP;

    IF to_regclass('dbo.prj_data_sources') IS NULL AND to_regclass('dbo.prj_data_source') IS NULL THEN
        RAISE EXCEPTION 'Schema validation failed: read-only dependency dbo.prj_data_sources (or singular dbo.prj_data_source) is missing.';
    END IF;
END $$;

SELECT 'Schema validation passed' AS validation_result;
