from pathlib import Path

from DataDictionaryAdminApp.api.schemas_api import AttributeUpsert
from DataDictionaryAdminApp.repositories.data_dictionary_repository import portfolio_label
from DataDictionaryAdminApp.service.data_dictionary_service import DataDictionaryService
from DataDictionaryAdminApp.utils.normalizers import canonical_portfolio_label


def test_portfolio_labels_use_distinct_portfolio_and_sector_pair():
    assert portfolio_label("FI", "Banks") == "FI Banks"
    assert portfolio_label("FI", "Insurance") == "FI Insurance"
    assert portfolio_label("Corporate", "Corporate") == "Corporate Corporate"
    assert portfolio_label("UKC", "UKC") == "UKC UKC"
    assert canonical_portfolio_label("Corporate") == "Corporate Corporate"
    assert canonical_portfolio_label("UKC") == "UKC UKC"


def test_streamlit_source_format_and_database_status_controls():
    source = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
    assert 'return f"{code}[{source_by_code.get(code, code)}]"' in source
    assert '"/system/database-status"' in source
    assert '"Test Database Connection"' in source
    assert 'max_width=1650' in source


def test_create_attribute_stages_raw_master_and_business_rule():
    class FakeRepo:
        def __init__(self):
            self.calls = []

        def next_prj_id(self):
            return "PRJ101"

        def portfolio_ref(self, value):
            assert value == "FI Banks"
            return {"port_ref_id": 1, "portfolio_name": "FI", "sector_name": "Banks"}

        def physical_name_for_prj(self, prj_id):
            return None

        def available_physical_name(self, base, exclude_prj_id=None):
            assert base == "gross land bldgs"
            return base

        def physical_name_exists(self, name, exclude_prj_id=None):
            return False

        def original_mapping_type(self, prj_id):
            return None

        def source_code(self, source_name, source_abbr_name=None):
            return source_abbr_name or "SNPAR"

        def upsert_raw(self, row, user, operation):
            self.calls.append("dbo.raw_prj_attribute_new_test")

        def upsert_staging_master(self, row, user, operation):
            self.calls.append("stg.prj_attribute_master_new_test")

        def upsert_staging_rule(self, row, user, operation):
            self.calls.append("stg.prj_attribute_business_rules_new_test")

    service = DataDictionaryService(db=None)  # repository is replaced before use
    service.repo = FakeRepo()
    payload = AttributeUpsert(
        portfolio="FI Banks",
        source_abbr_name="SNPR",
        prj_attribute_name="Land & Buildings(Gross)",
        physical_name_source="AUTO",
        section="Balance Sheet",
        sub_section="Assets",
        data_type="Amount",
        calculated_or_reported="Reported",
        display_order=1,
    )
    result = service.stage_attribute_pending(payload, "tester", "UI_CREATE")
    assert result["prj_id"] == "PRJ101"
    assert result["prj_physical_attribute_name"] == "gross land bldgs"
    assert service.repo.calls == result["staged_tables"]
