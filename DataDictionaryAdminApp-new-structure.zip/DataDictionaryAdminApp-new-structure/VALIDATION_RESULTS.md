# Validation Results

Validation performed on the generated source package before ZIP creation.

## Automated checks

- `python -m compileall -q src tests` — PASS
- `PYTHONPATH=src pytest -q` — PASS: 21 tests
- FastAPI OpenAPI generation — PASS: 26 API paths
- `pyproject.toml` TOML parse — PASS
- `docker-compose.yml` YAML parse — PASS
- Runtime Python scan for legacy table names — PASS: no legacy table dependencies
- Runtime Python scan for SQL Server-only CRUD constructs (`SYSUTCDATETIME`, `OUTPUT INSERTED`, `SCOPE_IDENTITY`, `TOP`) — PASS: none in runtime CRUD code
- SQL Server DDL contract test — PASS
- PostgreSQL DDL contract test — PASS
- Exact ORM raw/master/business-rule/audit/reference column tests — PASS

## Important deployment validation

No live SQL Server/Azure SQL or PostgreSQL instance was supplied. Therefore physical DDL execution, permissions, network authentication, existing `dbo.prj_data_sources` shape, and S3 credentials cannot be integration-tested here.

Before enabling writes in DEV:

- SQL Server/Azure SQL: run `src/DataDictionaryAdminApp/sql/002_validate_schema.sql`.
- PostgreSQL: run `src/DataDictionaryAdminApp/sql/postgres/002_validate_schema.sql`.
- Confirm the existing read-only `dbo.prj_data_sources` (or accepted singular `dbo.prj_data_source`) exposes `source_code` and `source_name`.
