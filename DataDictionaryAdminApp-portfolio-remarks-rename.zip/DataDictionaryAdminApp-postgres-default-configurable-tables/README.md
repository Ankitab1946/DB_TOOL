# PRJ Data Dictionary Administration Platform v2

Poetry-based FastAPI + Streamlit application implementing the new **raw → staging → final** PRJ Data Dictionary structure with selectable **SQL Server/Azure SQL or PostgreSQL** connectivity.

## What changed from the baseline project

The application no longer uses the old `*_test` master/scope/prompt table model. Runtime code is aligned to these managed logical objects:

1. `dbo.raw_prj_attribute_new_test`
2. `dbo.prj_portfolio_reference_new_test`
3. `dbo.audit_table_new_test`
4. `stg.prj_attribute_master_new_test`
5. `stg.prj_attribute_business_rules_new_test`
6. `stg.prj_attribute_display_test`
7. `dbo.prj_attribute_master_new_test`
8. `dbo.prj_attribute_business_rules_new_test`
9. `dbo.prj_attribute_display_test`

For SQL Server those logical schemas are physical `dbo`/`stg`. For PostgreSQL the application translates them at runtime to physical schemas `prj_dbd`/`prj_stage`.

The source reference table is an **existing, read-only** dependency and is never created by the application. SQL Server expects `dbo.prj_data_sources` (or singular `dbo.prj_data_source`); PostgreSQL expects the corresponding table in `prj_dbd`.

## Core workflow

```text
Excel / UI create-edit-soft-delete
              |
              v
 dbo.raw_prj_attribute_new_test
              |
              v
 stg.prj_attribute_master_new_test
 stg.prj_attribute_business_rules_new_test
 stg.prj_attribute_display_test
              |
          Delta review
              |
              v
       Finalize confirmation
              |
              v
 dbo.prj_attribute_master_new_test
 dbo.prj_attribute_business_rules_new_test
 dbo.prj_attribute_display_test
              |
       Optional S3 export
```

Every insert/update/soft-delete/finalize operation is recorded in `dbo.audit_table_new_test` with schema name, table name, record key, before value, after value, operation source, user and timestamp.

## UI

The Streamlit application contains four top-level tabs:

- **Data Dictionary**
  - View Latest with API-backed filters
  - Download Latest formatted Excel
  - Add/Edit modal using `streamlit-modal`
  - Soft Delete / Reactivate
  - Edit Latest grid with dirty-row detection
  - Upload & Edit: single sheet or multi-sheet merger
  - Delta and Finalize confirmation
  - S3 final-table export
- **Prompt Management**
  - `prompt_description` and `examples` maintained in the business-rules structure
- **Audit**
  - searchable/filterable history grid
- **Admin Tools**
  - portfolio reference maintenance and deployment commands

The left sidebar selects both the **environment** and **database engine** and shows the selected database, server/host, current user and access level. Every API call carries both selections so reads and writes stay in the chosen runtime context.

## Excel bulk upload

Bulk upload supports different settings per selected worksheet:

- Header row is 1-based and independently configurable for every sheet.
- Source columns are independently mapped to the standard data dictionary fields for every sheet.
- Portfolio can be explicitly overridden or detected from the sheet name:
  - `FI Insurance ...` → Insurance → `FI Insurance`
  - `FI Bank ...` → Banks → `FI Banks`
  - `UKC ...` → `UKC`
  - Corporate / General Industries → `Corporate`
- `MERGE` stages/upserts loaded records.
- `REPLACE` clears raw and pending staging data before loading; final tables remain unchanged until Finalize.
- Rejected rows return exact sheet/row/reason details.

### Resolved requirement ambiguities

- Default source code is **`SNPAR`**. One requirement line says `SNAR`, while the source lookup/default requirements repeatedly use `SNPAR`.
- **Display Order** maps from the workbook Display Order column. A later line says Sub-Section, but the workbook definition and staging business-rule definition have a dedicated Display Order field.
- The requirement text says both “four files” and “TWO file” for S3. This build exports the explicitly listed **two final tables**.
- The requirements ask for four UI tabs but enumerate three. The fourth tab is **Admin Tools**, keeping portfolio/reference operations out of the main workflow.

## Database setup

The application keeps one logical SQLAlchemy model but uses different physical schemas by engine:

| Layer | SQL Server / Azure SQL | PostgreSQL |
|---|---|---|
| staging | `stg` | `prj_stage` |
| main/raw/reference/audit | `dbo` | `prj_dbd` |

The PostgreSQL engine applies `schema_translate_map={"stg":"prj_stage","dbo":"prj_dbd"}` so Create/Edit/Stage/Finalize use the same service code on both engines.

**SQL Server / Azure SQL**

```text
src/DataDictionaryAdminApp/sql/001_create_tables.sql
src/DataDictionaryAdminApp/sql/002_validate_schema.sql
src/DataDictionaryAdminApp/sql/003_preflight_no_legacy_tables.sql   # optional
```

**PostgreSQL 15+**

```text
src/DataDictionaryAdminApp/sql/postgres/001_create_tables.sql
src/DataDictionaryAdminApp/sql/postgres/002_validate_schema.sql
```

The PostgreSQL create script creates `prj_stage` and `prj_dbd`. It intentionally does **not** create `prj_dbd.prj_data_sources`; that remains the existing read-only dependency required for Source Name → Source Code lookup. The singular legacy spelling `prj_dbd.prj_data_source` is also accepted by runtime lookup code. SQL Server continues to use `dbo.prj_data_sources` (or the singular legacy spelling).

The seed mapping is enforced as:

| port_ref_id | portfolio_name | sector_name | UI label |
|---:|---|---|---|
| 1 | FI | Banks | FI Banks |
| 2 | FI | Insurance | FI Insurance |
| 3 | Corporate | Corporate | Corporate |
| 4 | UKC | UKC | UKC |

## Local installation

```bash
cp .env.example .env
poetry install
```

Configure `.env`. Set `SELECTED_DB_TYPE=SQLSERVER` or `POSTGRES`, enable the corresponding database settings for each environment, then start the API:

```bash
poetry run uvicorn DataDictionaryAdminApp.api.swagger_app:app --host 0.0.0.0 --port 8503
```

Start the UI in another terminal:

```bash
poetry run streamlit run src/DataDictionaryAdminApp/streamlit_app.py --server.port 8501
```

Swagger:

```text
http://localhost:8503/docs
```

## Docker

```bash
cp .env.example .env
docker compose up --build
```

Default gateway URL: `http://localhost:8080`.

## Authentication / user audit

The API obtains the audit username from `X-App-User`, `X-Forwarded-User`, the OS username, or `DEFAULT_USER`. In production, the reverse proxy/identity layer should overwrite these headers rather than accepting arbitrary client-supplied identity headers.

Admin writes are permitted only when the resolved username is present in `ADMIN_USERS`. Avoid `ADMIN_USERS=*` outside local development.

## S3-compatible storage

Configure:

```text
S3_BUCKET_NAME=
S3_ENDPOINT_URL=https://host:port
S3_USE_SSL=true
S3_VERIFY_SSL=false
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
S3_PREFIX=data-dictionary
```

The app exports timestamped CSV files for:

- `dbo.prj_attribute_master_new_test`
- `dbo.prj_attribute_business_rules_new_test`

## Validation performed in this package

```bash
python -m compileall -q src tests
PYTHONPATH=src pytest -q
```

The included tests validate exact ORM table/column alignment, SQL Server and PostgreSQL schema contracts, database-engine URL resolution, route availability, normalizers, Excel header mapping, per-sheet portfolio detection, tech-logic generation, Excel metadata/validation output and absence of runtime legacy-table dependencies. The packaged validation run currently passes **132 tests**.

> No live SQL Server or PostgreSQL instance was supplied with the request, so physical DDL execution and end-to-end database integration cannot be proven in this build environment. Run the matching `002_validate_schema.sql` against DEV before enabling writes.

## UI roles

The Streamlit sidebar exposes `Application Role` with `Admin` and `User` options. Admin sees Bulk Upload, S3 final-table export, and Admin Tools. User retains the standard dictionary workflow but those admin-only functions are not rendered. The Streamlit client sends `X-App-Role` to FastAPI so admin-only endpoints apply the same restriction server-side.

The sidebar always exposes `Database Type` with `SQL Server` and `PostgreSQL`; **PostgreSQL is the initial/default selection on page load**. The selected environment still controls whether that engine is enabled and which connection details are used.

## Existing-database migration sequence

For an existing database from the immediately previous release, apply the new split migration and then validate:

**SQL Server / Azure SQL**

```text
005_split_business_display.sql
002_validate_schema.sql
```

**PostgreSQL**

```text
postgres/005_split_business_display_and_schemas.sql
postgres/002_validate_schema.sql
```

If an environment has not yet received the earlier `003` and `004` migrations, apply those first, then `005`, then `002` validation. Do not rerun `001_create_tables.sql` against an existing database.

Migration `005` preserves existing `scope_id` values and splits each staging/final scope into a one-to-one business row and display row. PostgreSQL migration `005` additionally moves the physical staging tables into `prj_stage` and main/raw/reference/audit tables into `prj_dbd`.

## Business/display split

`prj_attribute_business_rules_new_test` now contains only business/LLM fields: `scope_id`, `prj_id`, `port_ref_id`, `source_abbr_name`, `prompt_description`, `examples_for_llm`, `editable`, `data_type`, `attribute_type`, `business_logic`, `calculation_logic`, and audit columns.

`prj_attribute_display_test` is one-to-one with the business scope through `scope_id` and stores `display_order`, `prj_id`, `display_name`, `section`, `subsection` and audit columns. To preserve previously implemented scope-specific behavior, Attribute Definition, Attribute Description, Segment and Report Type are also retained on the display row. The repository rejoins the two tables so Create/Edit/View Latest/Delta/Finalize keep the existing API/UI shape.


## Configurable staging/final target table names

The sidebar includes an expanded **Target Tables** section for the currently selected database. It shows three staging targets and three actual/final targets:

- Attribute Master
- Business Rules
- Attribute Display

PostgreSQL displays these under `prj_stage` (staging) and `PG_SCHEMA` / `prj_dbd` by default (actual/final). SQL Server displays them under `stg` and `dbo`.

The table basenames can be edited independently for PostgreSQL and SQL Server, for example `prj_attribute_master_new_test` -> `prj_attribute_master`. The selected names are sent to FastAPI with every request and are applied to ORM reads/writes, staging, SQL Server finalize, PostgreSQL physical finalize, cleanup reporting, audit table names and S3 export metadata.

This feature **does not rename database objects**. The physical tables entered in the UI must already exist in the displayed schemas with the expected columns/keys. Table names are validated to letters/numbers/underscores only to prevent unsafe SQL identifiers. Reference/raw/audit table names remain governed by the existing fixed contract.
