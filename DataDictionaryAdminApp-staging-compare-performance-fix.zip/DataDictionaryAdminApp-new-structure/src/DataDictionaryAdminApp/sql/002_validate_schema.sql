/* Fails deployment if the managed table/column contract is not aligned. */
SET NOCOUNT ON;

DECLARE @missing TABLE(item nvarchar(400));

IF SCHEMA_ID(N'stg') IS NULL INSERT @missing VALUES(N'schema stg');
IF OBJECT_ID(N'dbo.raw_prj_attribute_new_test',N'U') IS NULL INSERT @missing VALUES(N'dbo.raw_prj_attribute_new_test');
IF OBJECT_ID(N'dbo.prj_portfolio_reference_new_test',N'U') IS NULL INSERT @missing VALUES(N'dbo.prj_portfolio_reference_new_test');
IF OBJECT_ID(N'dbo.audit_table_new_test',N'U') IS NULL INSERT @missing VALUES(N'dbo.audit_table_new_test');
IF OBJECT_ID(N'stg.prj_attribute_master_new_test',N'U') IS NULL INSERT @missing VALUES(N'stg.prj_attribute_master_new_test');
IF OBJECT_ID(N'stg.prj_attribute_business_rules_new_test',N'U') IS NULL INSERT @missing VALUES(N'stg.prj_attribute_business_rules_new_test');
IF OBJECT_ID(N'dbo.prj_attribute_master_new_test',N'U') IS NULL INSERT @missing VALUES(N'dbo.prj_attribute_master_new_test');
IF OBJECT_ID(N'dbo.prj_attribute_business_rules_new_test',N'U') IS NULL INSERT @missing VALUES(N'dbo.prj_attribute_business_rules_new_test');
IF OBJECT_ID(N'dbo.prj_data_sources',N'U') IS NULL AND OBJECT_ID(N'dbo.prj_data_source',N'U') IS NULL
    INSERT @missing VALUES(N'dbo.prj_data_sources (read-only dependency; singular dbo.prj_data_source also accepted)');

DECLARE @required TABLE(schema_name sysname, table_name sysname, column_name sysname);
INSERT @required VALUES
('dbo','raw_prj_attribute_new_test','portfolio'),('dbo','raw_prj_attribute_new_test','prj_id'),
('dbo','raw_prj_attribute_new_test','prj_attribute_name'),('dbo','raw_prj_attribute_new_test','prj_physical_attribute_name'),
('dbo','raw_prj_attribute_new_test','section'),('dbo','raw_prj_attribute_new_test','sub_section'),
('dbo','raw_prj_attribute_new_test','data_type'),('dbo','raw_prj_attribute_new_test','calculated_or_reported'),
('dbo','raw_prj_attribute_new_test','calculation_logic'),('dbo','raw_prj_attribute_new_test','segment'),
('dbo','raw_prj_attribute_new_test','attribute_definition'),('dbo','raw_prj_attribute_new_test','attribute_description'),
('dbo','raw_prj_attribute_new_test','display_order'),('dbo','raw_prj_attribute_new_test','tech_logic'),
('dbo','raw_prj_attribute_new_test','display_name'),
('stg','prj_attribute_master_new_test','prj_id'),('stg','prj_attribute_master_new_test','prj_attribute_definition'),
('stg','prj_attribute_master_new_test','where_in_financial_statement'),
('stg','prj_attribute_business_rules_new_test','scope_id'),('stg','prj_attribute_business_rules_new_test','port_ref_id'),
('stg','prj_attribute_business_rules_new_test','source_abbr_name'),('stg','prj_attribute_business_rules_new_test','editable'),
('stg','prj_attribute_business_rules_new_test','symbol'),('stg','prj_attribute_business_rules_new_test','mapping_type'),
('stg','prj_attribute_business_rules_new_test','calculation_logic'),('stg','prj_attribute_business_rules_new_test','prj_attribute_description'),
('stg','prj_attribute_business_rules_new_test','tech_logic'),('stg','prj_attribute_business_rules_new_test','display_order'),
('stg','prj_attribute_business_rules_new_test','display_name'),('stg','prj_attribute_business_rules_new_test','section'),
('stg','prj_attribute_business_rules_new_test','subsection'),('stg','prj_attribute_business_rules_new_test','prompt_description'),
('stg','prj_attribute_business_rules_new_test','examples'),
('dbo','prj_attribute_master_new_test','prj_id'),('dbo','prj_attribute_business_rules_new_test','scope_id');

INSERT @missing(item)
SELECT CONCAT(r.schema_name,'.',r.table_name,'.',r.column_name)
FROM @required r
WHERE COL_LENGTH(CONCAT(r.schema_name,'.',r.table_name), r.column_name) IS NULL;

IF EXISTS (SELECT 1 FROM @missing)
BEGIN
    SELECT item AS missing_schema_object FROM @missing ORDER BY item;
    THROW 51010, 'Schema validation failed. Review the returned missing_schema_object rows.', 1;
END;

SELECT 'Schema validation passed' AS validation_result;
