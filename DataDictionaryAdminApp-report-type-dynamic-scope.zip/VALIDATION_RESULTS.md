# Validation Results

Validation for the Report Type / dynamic scoped-fields update:

- 91/91 automated tests passed.
- Python `compileall` passed for application source and tests.
- FastAPI/OpenAPI generation passed with the existing route contract.
- `report_type` is present in raw, staging business rules and final business rules for both SQL Server and PostgreSQL DDL.
- Existing-database migration `004_add_report_type_scope_fields.sql` is included for SQL Server and PostgreSQL and rebuilds the unique scope key to include `report_type`.
- Scope ID remains an auto-generated primary key; uniqueness is enforced on `(prj_id, port_ref_id, source_abbr_name, display_order, section, subsection, report_type)`.
- Multiple Section/Sub-Section pairs expand positionally for Attribute Definition, Attribute Description, Segment, Display Order, Calculation Logic, Report Type, Tech Logic, Examples and Display Name.
- Master Dictionary Excel detection/export includes `Report Type` and `Examples`.
- Calculation Logic and other long-form scoped fields preserve internal newlines while splitting only on the positional `|` separator.
- Existing staging/finalize, soft delete/reactivate, cleanup, role controls, S3, filters, and SQL Server/PostgreSQL connection behavior remain unchanged.

Validation for the Clear Filters / Tech Logic NVL / PostgreSQL alignment update:

- 81/81 automated tests passed.
- Python `compileall` passed for the application source.
- FastAPI/OpenAPI generated successfully with 29 API paths.
- Clear Filters now resets the visible Streamlit widget values as well as the active query state.
- Section/Sub-Section and all other filters return to explicit blank/default UI values after Clear Filters.
- Tech Logic preserves SQL-style functions such as `nvl(...)`, PRJ references, arithmetic operators, numeric constants, and grouping brackets.
- `Total Income(PRJ362) = EBITDA(PRJ43843) /nvl(Debt/Amount(PRJ4343)+ EBITDA(PRJ43843))` generates `PRJ362 = PRJ43843/nvl(PRJ4343+PRJ43843)`.
- Existing slash-in-label behavior remains intact: `Debt/Amount(PRJ4343)` is treated as one descriptive label around `PRJ4343`, not as an arithmetic divide.
- PostgreSQL runtime configuration uses `postgresql+psycopg` and PostgreSQL-specific connection arguments.
- Key ORM SELECT/UPDATE/DELETE statements compile successfully against the PostgreSQL dialect.
- PostgreSQL boolean predicates compile as `= true`; no SQL Server-style `IS 1` predicate is generated.
- PostgreSQL fresh-install DDL contains every column declared by all seven application-managed ORM tables.
- PostgreSQL preflight (`sql/postgres/002_validate_schema.sql`) now validates the complete ORM-managed table/column contract plus required `source_code` and `source_name` columns on the read-only data-source dependency.
- PostgreSQL existing-database migration `003_add_scoped_definition_segment.sql` remains aligned with the current business-rule schema.
- No new database schema migration is required for this update.

## SQL Server scoped migration compile-safety fix

- Fixed `003_add_scoped_definition_segment.sql` so SQL Server does not compile UPDATE statements against columns added earlier in the same batch. Backfill is executed with `sys.sp_executesql` after ALTER TABLE completes.
- Migration is idempotent and transaction protected.
- Migration can backfill Attribute Definition from `prj_attribute_definition`, `cfv_attribute_definition`, or `attribute_definition` on older/customized master schemas; the current business-rule target column remains `prj_attribute_definition`.
- Segment backfill accepts `where_in_financial_statement` or `segment` as the source.
- `002_validate_schema.sql` is read-only and now returns detailed object type, schema, table, column and fix hint rows before intentionally failing if alignment is incomplete.
- Full Python regression suite passes after the SQL-only patch.

## SQL Server canonical master-column migration fix
- Existing master aliases (`cfv_attribute_definition`, `attribute_definition`, `segment`) are detected before canonical columns are added.
- Corrected migration adds/backfills canonical ORM columns (`prj_attribute_definition`, `where_in_financial_statement`) before scoped rule backfill.
- All references to newly-added columns are compiled through `sys.sp_executesql` to avoid SQL Server same-batch `Invalid column name` failures.
- Validator is read-only and returns a full OK/MISSING/SKIP diagnostic grid before raising on genuine runtime-contract gaps.
