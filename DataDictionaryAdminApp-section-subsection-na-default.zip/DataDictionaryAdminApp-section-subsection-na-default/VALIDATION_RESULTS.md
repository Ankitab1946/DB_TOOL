# Validation Results

Latest fix: PostgreSQL Portfolio/Scope and Source reference lookup alignment.

- PostgreSQL Portfolio/Scope reads directly from `prj_dbd.prj_portfolio_reference`.
- PostgreSQL Source reads directly from `prj_dbd.prj_data_sources`.
- PostgreSQL reference rows are not hidden by legacy `is_active` values.
- PostgreSQL UI refreshes Portfolio and Source independently from the combined lookup endpoint.
- SQL Server lookup behavior remains unchanged.
- No database migration or DDL change is required.
- Python compileall: PASS
- FastAPI/OpenAPI import: PASS
- OpenAPI paths: 29
- Full pytest regression suite: PASS

## PostgreSQL Finalize publication fix
- PostgreSQL Finalize now publishes through the physical schemas `prj_stage` -> `prj_dbd`.
- Canonical Portfolio/Scope validation uses `prj_dbd.prj_portfolio_reference` before publication.
- Publication covers master, business rules, and display rows and writes audit history before staging cleanup.
- SQL Server retains the existing ORM finalize path unchanged.
- Missing PostgreSQL tables/columns return descriptive API errors rather than a generic Internal Server Error.
- Focused physical-schema publication regression test added.
- Full regression suite: 122 tests passed.
- Python compileall: PASS.
- FastAPI/OpenAPI: PASS (29 paths).


## PG environment-variable rename
- Renamed PostgreSQL connection settings: `POSTGRES_HOST` -> `PG_HOST`, `POSTGRES_PORT` -> `PG_PORT`, `POSTGRES_DATABASE` -> `PG_DATABASE`.
- Added/renamed schema setting to `PG_SCHEMA` (default `prj_dbd`).
- Environment-specific overrides now use `ENV_<ENV>_PG_HOST`, `ENV_<ENV>_PG_PORT`, `ENV_<ENV>_PG_DATABASE`, `ENV_<ENV>_PG_SCHEMA`.
- `POSTGRES_USER`, `POSTGRES_PASSWORD`, `POSTGRES_SSLMODE`, and `ENABLE_POSTGRES` remain unchanged.
- Full pytest regression suite passed; Python compileall passed.


## PostgreSQL default + configurable target table names
- PostgreSQL is now the default database selection on Streamlit page load and the default `Settings.selected_db_type`.
- `.env.example` now defaults `SELECTED_DB_TYPE=POSTGRES`.
- Sidebar shows editable staging and actual/final targets for Attribute Master, Business Rules and Attribute Display.
- Target names are maintained independently for PostgreSQL and SQL Server during the Streamlit session and sent on every API request.
- SQLAlchemy applies request-level qualified table rewrites, preserving existing ORM/service/repository behavior.
- PostgreSQL Finalize reflects the selected `prj_stage` / main-schema table names directly.
- Target identifiers are validated to safe SQL basenames.
- Raw, audit, Portfolio and Data Source reference table contracts remain unchanged.
- Focused runtime test proves ORM redirection to a custom physical table.
- Focused PostgreSQL Finalize test proves custom staging and final table names publish successfully.
- Full pytest regression suite: **132 tests passed**.
- Python compileall: PASS.
- FastAPI/OpenAPI: PASS (29 paths).
- No SQL migration is required for this application-routing change.

## Portfolio remarks rename
- Renamed Portfolio Reference runtime/API/UI field from `remark` to `remarks`.
- Added SQL Server migration `007_rename_portfolio_remark_to_remarks.sql`.
- Added PostgreSQL migration `postgres/007_rename_portfolio_remark_to_remarks.sql`.
- Updated fresh-install DDL and schema validators to require `remarks`.
- API input keeps backward compatibility with legacy `remark`, while serializing/storing the canonical `remarks` field.
- Full regression suite passed after the change.

## Nullable Section/Sub-Section + Finalize single-submit + custom-final delta
- Blank Excel Section/Sub-Section cells are accepted and normalized to database `NULL` instead of rejected items.
- Create/Edit UI continues to require Section and Sub-Section, preserving interactive validation.
- Raw, staging display and final display ORM columns are nullable for Section/Sub-Section.
- Added SQL Server migration `008_make_section_subsection_nullable.sql` and PostgreSQL migration `postgres/008_make_section_subsection_nullable.sql`.
- Fresh-install DDL uses nullable Section/Sub-Section columns and schema validators require those columns to allow NULL.
- Finalize confirmation is single-submit: Yes Upload disables, shows in-progress status, closes on success and reports finalized PRJ-ID count.
- Finalize preview reads exact UI-selected staging/final physical table names whenever custom target names are configured, including the case where only Actual/Final names are changed.
- Finalize tab explicitly shows the currently selected staging-master -> final-master target pair.
- Focused regression coverage added for blank Excel cells, nullable ORM contract, 008 migrations, Finalize UI state, and custom-final-only delta.
- Full pytest regression suite: **141 tests passed**.
- Python compileall: PASS.
- FastAPI/OpenAPI: PASS (29 paths).

## PostgreSQL master column rename: where_in_financial_statement -> segment
- PostgreSQL staging/final Attribute Master physical column is now `segment`.
- SQL Server Attribute Master remains `where_in_financial_statement` unchanged.
- Shared Python/API/UI contract remains backward-compatible; PostgreSQL SQL execution translates the logical legacy master field to physical `segment` without changing bind parameters.
- PostgreSQL Finalize physical reflection/validation/writes use `segment`.
- Custom-target Finalize preview normalizes reflected PostgreSQL `segment` to the existing logical service field for comparison.
- PostgreSQL fresh-install `001_create_tables.sql` and `002_validate_schema.sql` require `segment`.
- Added idempotent PostgreSQL migration `009_rename_master_where_to_segment.sql` for existing default staging/final master tables.
- Full pytest regression suite: **146 tests passed**.
- Python compileall: PASS.
- FastAPI/OpenAPI: PASS (29 paths).

## Section/Sub-Section N/A default release
- Blank Excel Section values normalize to literal `N/A`.
- Blank Excel Sub-Section values normalize to literal `N/A`.
- Rows are not rejected solely because Section/Sub-Section cells are blank.
- Raw, staging display, and final display ORM columns are NOT NULL with application default `N/A`.
- SQL Server/PostgreSQL fresh-install DDL uses NOT NULL DEFAULT `N/A`.
- Migration 010 backfills existing NULL/blank values to `N/A` and restores NOT NULL/defaults.
- Existing Finalize progress flow, custom target table routing, and PostgreSQL master `segment` behavior retained.
- Full pytest suite: 146 passed.
- Python compileall: PASS.
- FastAPI/OpenAPI import: PASS (29 paths).
