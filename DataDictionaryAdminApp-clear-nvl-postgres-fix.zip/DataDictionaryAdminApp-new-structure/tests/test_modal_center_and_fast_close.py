from pathlib import Path


SOURCE = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")


def test_create_and_edit_modals_are_viewport_centered():
    assert 'render_attribute_modal_style("create_attribute_modal")' in SOURCE
    assert 'render_attribute_modal_style("edit_attribute_modal")' in SOURCE
    assert "height: 100vh !important;" in SOURCE
    assert "place-items: center !important;" in SOURCE
    assert "justify-self: center !important;" in SOURCE
    assert "width: 96vw !important;" in SOURCE
    assert "max-width: 1900px !important;" in SOURCE


def test_create_and_edit_x_close_sync_application_state():
    assert "class StateAwareModal(Modal):" in SOURCE
    assert 'state_flag="show_create"' in SOURCE
    assert 'state_flag="show_edit"' in SOURCE
    assert "st.session_state[self.state_flag] = False" in SOURCE


def test_closed_create_edit_modals_are_not_auto_reopened():
    assert 'if not create_modal.is_open():' not in SOURCE
    assert 'if not edit_modal.is_open():' not in SOURCE
    assert 'if st.session_state.get("show_create") and create_modal.is_open():' in SOURCE
    assert 'if st.session_state.get("show_edit") and edit_modal.is_open():' in SOURCE
