# Validation Results

Validation date: 2026-08-17

## Fixes in this build

1. Database connectivity status
   - Added `/api/v1/system/database-status`.
   - The sidebar automatically tests the selected Environment + Database Type once when the selection changes.
   - A manual `Test Database Connection` button is also available.
   - The UI shows `Connected` or `Not connected` and surfaces a sanitized driver/database diagnostic without exposing the configured password.

2. Create/Edit Attribute dialog sizing
   - Create and Edit modal maximum width increased from 1050px to 1220px for a balanced working area.

3. Portfolio dropdown
   - Values are read from `dbo.prj_portfolio_reference_new_test`.
   - Dropdown labels use the distinct `portfolio_name + sector_name` pair, e.g. `FI Banks`, `FI Insurance`, `Corporate Corporate`, `UKC UKC`.
   - Duplicate portfolio/sector pairs are removed from the UI while preserving a deterministic `port_ref_id` mapping.
   - Bulk-upload sheet-name auto-detection continues to map Insurance/Bank sheets to `FI Insurance`/`FI Banks`; raw persistence still stores `Insurance`/`Banks` for FI rows per the existing raw-table mapping.

4. Source dropdown
   - Values are read from `dbo.prj_data_sources` (or legacy singular `dbo.prj_data_source` if that is the deployed table name).
   - Display format is `source_code[source_name]`.
   - Only `source_code` is persisted to `source_abbr_name` in the business-rule staging/final flow.

5. Create Attribute staging
   - A successful Create Attribute transaction writes to:
     - `dbo.raw_prj_attribute_new_test`
     - `stg.prj_attribute_master_new_test`
     - `stg.prj_attribute_business_rules_new_test`
   - No duplicate `stg.raw_prj_attribute_new_test` was added because the existing architecture already uses the `dbo.raw_*` table as the raw persistence layer before the two normalized staging tables.
   - SQLAlchemy connection/operational/schema errors are converted to actionable API responses instead of a generic 500 where possible.

6. PRJ Physical Attribute Name
   - UI creation auto-generates from Attribute Name, including the required example: `Land & Buildings(Gross)` -> `gross land bldgs`.
   - Exact duplicate checking spans raw, staging and final tables.
   - New auto-generated names receive the first available deterministic suffix when the base is already in use.
   - Existing PRJ IDs preserve their current physical name when incoming UI/bulk data leaves the field blank.
   - Explicit Excel physical names are preserved and rejected if they collide with another PRJ ID.
   - Blank Excel physical names are generated and then uniqueness-checked by the backend.
   - Alternative available names are shown in the UI. Exact database checks are used instead of a Bloom filter because uniqueness cannot tolerate false positives.

## Automated validation

- `python -m compileall -q src tests`: PASS
- `pytest -q`: 32 tests PASS
- FastAPI OpenAPI application load: PASS
- API paths: 28
- `/api/v1/system/database-status`: PRESENT
- SQL Server unsafe `.is_(True)` runtime scan: PASS
- SQL Server boolean-dialect contract test: PASS
- PostgreSQL boolean-dialect contract test: PASS
- Existing bulk-upload header/data-start, MERGE/INSERT_ONLY/REPLACE, soft-delete/reactivate and role-control tests: PASS
- New portfolio-label/source-format/database-status UI contract tests: PASS
- New Create Attribute raw + staging write-contract test: PASS

No new database table is required for this patch. Existing SQL Server/PostgreSQL DDL remains valid.
