"""Excel ingestion/export service with per-sheet header and mapping configuration."""
from __future__ import annotations

import io
from datetime import datetime, timezone
from typing import Any

import pandas as pd
from openpyxl import Workbook
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation

from DataDictionaryAdminApp.api.schemas_api import AttributeUpsert
from DataDictionaryAdminApp.config import get_settings
from DataDictionaryAdminApp.utils.normalizers import (
    align_int_pipe_values,
    detect_column_mapping,
    ensure_int,
    generate_physical_name,
    generate_tech_logic,
    normalize_text,
    pair_nullable_pipe_values,
    pair_pipe_values,
    portfolio_from_sheet_name,
)


STANDARD_FIELDS = [
    "prj_id",
    "prj_attribute_name",
    "prj_physical_attribute_name",
    "section",
    "sub_section",
    "data_type",
    "calculated_or_reported",
    "calculation_logic",
    "segment",
    "report_type",
    "attribute_definition",
    "attribute_description",
    "display_order",
    "tech_logic",
    "display_name",
    "examples",
    "portfolio",
]

REQUIRED_BULK_FIELDS = {"prj_id", "prj_attribute_name", "section", "sub_section", "calculated_or_reported", "display_order"}


def _cell(value: Any, preserve_newlines: bool = False) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    text = str(value).strip()
    return text if preserve_newlines else normalize_text(text)


class ExcelService:
    @staticmethod
    def sheet_names(content: bytes) -> list[str]:
        with pd.ExcelFile(io.BytesIO(content), engine="openpyxl") as workbook:
            return list(workbook.sheet_names)

    @staticmethod
    def read_sheet(
        content: bytes,
        sheet_name: str,
        header_row: int,
        data_start_row: int | None = None,
    ) -> pd.DataFrame:
        """Read one sheet using 1-based Excel row numbers.

        ``header_row`` identifies the row containing column names. ``data_start_row``
        identifies the first actual data row and can be used to skip one or more
        explanatory/sub-header rows between the header and the data.
        """
        if header_row < 1:
            raise ValueError("header_row is 1-based and must be >= 1")
        first_possible_data_row = header_row + 1
        if data_start_row is None:
            data_start_row = first_possible_data_row
        if data_start_row < first_possible_data_row:
            raise ValueError("data_start_row must be greater than header_row")

        frame = pd.read_excel(
            io.BytesIO(content),
            sheet_name=sheet_name,
            header=header_row - 1,
            engine="openpyxl",
        )
        rows_to_skip_after_header = data_start_row - first_possible_data_row
        if rows_to_skip_after_header:
            # Keep the original RangeIndex so rejected-row reporting still maps
            # back to the correct 1-based Excel row number.
            frame = frame.iloc[rows_to_skip_after_header:]
        return frame

    def preview_sheet(
        self,
        content: bytes,
        sheet_name: str,
        header_row: int,
        data_start_row: int | None = None,
    ) -> dict[str, Any]:
        frame = self.read_sheet(content, sheet_name, header_row, data_start_row)
        frame = frame.dropna(how="all")
        mapping = detect_column_mapping(frame.columns)
        effective_data_start = data_start_row or (header_row + 1)
        return {
            "sheet_name": sheet_name,
            "header_row": header_row,
            "data_start_row": effective_data_start,
            "skipped_rows_after_header": max(0, effective_data_start - header_row - 1),
            "columns": [str(column) for column in frame.columns],
            "detected_mapping": mapping,
            "portfolio_detected": portfolio_from_sheet_name(sheet_name),
            "preview": frame.head(10).astype(object).where(frame.head(10).notna(), "").astype(str).to_dict(orient="records"),
        }

    def parse_workbook(self, content: bytes, configurations: list[dict[str, Any]]) -> dict[str, Any]:
        rows: list[AttributeUpsert] = []
        rejected: list[dict[str, Any]] = []
        for config in configurations:
            sheet_name = str(config["sheet_name"])
            header_row = int(config.get("header_row", 1))
            data_start_row = int(config.get("data_start_row") or (header_row + 1))
            frame = self.read_sheet(content, sheet_name, header_row, data_start_row).dropna(how="all")
            detected = detect_column_mapping(frame.columns)
            supplied = config.get("mapping") or {}
            mapping = {**detected, **{k: v for k, v in supplied.items() if v}}
            missing = sorted(field for field in REQUIRED_BULK_FIELDS if field not in mapping)
            if missing:
                rejected.append({"sheet": sheet_name, "row": None, "reason": f"Missing required mappings: {', '.join(missing)}"})
                continue
            portfolio_override = normalize_text(config.get("portfolio_override"))
            sheet_portfolio = portfolio_override or portfolio_from_sheet_name(sheet_name)
            for index, record in frame.iterrows():
                excel_row = int(index) + header_row + 1
                try:
                    values: dict[str, Any] = {}
                    for field in STANDARD_FIELDS:
                        source_column = mapping.get(field)
                        preserve = field in {"calculation_logic", "attribute_definition", "attribute_description", "tech_logic", "examples"}
                        values[field] = _cell(record.get(source_column), preserve_newlines=preserve) if source_column else ""
                    values["portfolio"] = values["portfolio"] or sheet_portfolio
                    if not values["portfolio"]:
                        raise ValueError("Portfolio could not be detected. Select a Portfolio for this sheet or map a Portfolio column.")
                    if not values["prj_id"]:
                        raise ValueError("PRJID is mandatory for bulk upload.")
                    if not values["prj_attribute_name"]:
                        raise ValueError("PRJ Attribute Name is mandatory.")
                    if not values["calculated_or_reported"]:
                        raise ValueError("Calculated or Reported is mandatory.")
                    values["section"] = values["section"] or "N/A"
                    values["sub_section"] = values["sub_section"] or "N/A"
                    pairs = pair_nullable_pipe_values(values["section"], values["sub_section"])
                    display_orders = align_int_pipe_values(values["display_order"], len(pairs), "Display Order", default=-1)
                    if any(value < 0 for value in display_orders):
                        raise ValueError("Display Order must be numeric and is mandatory.")
                    display_order = display_orders[0] if len(display_orders) == 1 else "|".join(str(value) for value in display_orders)
                    calculation_logic = values["calculation_logic"] or "NA"
                    supplied_physical = values["prj_physical_attribute_name"]
                    physical = supplied_physical or generate_physical_name(values["prj_attribute_name"])
                    physical_name_source = "SUPPLIED" if supplied_physical else "AUTO"
                    tech = values["tech_logic"] or generate_tech_logic(calculation_logic)
                    rows.append(AttributeUpsert(
                        prj_id=values["prj_id"],
                        portfolio=values["portfolio"],
                        prj_attribute_name=values["prj_attribute_name"],
                        prj_physical_attribute_name=physical,
                        physical_name_source=physical_name_source,
                        section=values["section"],
                        sub_section=values["sub_section"],
                        data_type=values["data_type"] or None,
                        calculated_or_reported=values["calculated_or_reported"],
                        calculation_logic=calculation_logic,
                        segment=values["segment"] or "NA",
                        report_type=values["report_type"] or "NA",
                        attribute_definition=values["attribute_definition"] or None,
                        attribute_description=values["attribute_description"] or None,
                        display_order=display_order,
                        tech_logic=tech,
                        display_name=values["display_name"] or values["prj_attribute_name"],
                        examples=values["examples"] or None,
                    ))
                except Exception as exc:
                    rejected.append({"sheet": sheet_name, "row": excel_row, "reason": str(exc)})
        return {"rows": rows, "rejected": rejected}

    @staticmethod
    def latest_workbook(rows: list[dict[str, Any]]) -> bytes:
        settings = get_settings()
        workbook = Workbook()
        sheet = workbook.active
        sheet.title = "Master Dictionary"
        columns = [
            ("PRJID", "prj_id"),
            ("Attribute Name", "prj_attribute_name"),
            ("PRJ Physical Attribute Name", "prj_physical_attribute_name"),
            ("Portfolio / Scope", "portfolios"),
            ("Source", "sources"),
            ("Section", "section"),
            ("Sub-Section", "subsection"),
            ("DATA TYPE", "symbol"),
            ("Calculated or Reported", "mapping_type"),
            ("Calculation Logic", "calculation_logic"),
            ("Segment", "segment"),
            ("Report Type", "report_type"),
            ("Attribute Definition", "prj_attribute_definition"),
            ("Attribute Description", "prj_attribute_description"),
            ("Display Order", "display_order"),
            ("Tech Logic", "tech_logic"),
            ("Display Name", "display_name"),
            ("Examples", "examples"),
        ]
        for col_index, (label, _) in enumerate(columns, start=1):
            cell = sheet.cell(row=1, column=col_index, value=label)
            cell.font = Font(bold=True)
            cell.fill = PatternFill("solid", fgColor="D9EAF7")
            cell.alignment = Alignment(wrap_text=True, vertical="top")
        for row_index, row in enumerate(rows, start=2):
            for col_index, (_, key) in enumerate(columns, start=1):
                cell = sheet.cell(row=row_index, column=col_index, value=row.get(key))
                cell.alignment = Alignment(wrap_text=True, vertical="top")
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        widths = [14, 34, 32, 22, 18, 24, 24, 15, 22, 45, 24, 20, 45, 55, 14, 45, 34, 45]
        for index, width in enumerate(widths, start=1):
            sheet.column_dimensions[sheet.cell(1, index).column_letter].width = width
        validation = DataValidation(type="list", formula1='"Calculated,Reported,Repeated"', allow_blank=False)
        sheet.add_data_validation(validation)
        validation.add(f"I2:I{max(2, len(rows)+500)}")
        dtype_validation = DataValidation(type="list", formula1='"Amount,%,Ratio,actual"', allow_blank=True)
        sheet.add_data_validation(dtype_validation)
        dtype_validation.add(f"H2:H{max(2, len(rows)+500)}")

        meta = workbook.create_sheet("Metadata")
        metadata = [
            ("Template Version", settings.excel_template_version),
            ("Generated UTC", datetime.now(timezone.utc).isoformat()),
            ("Record Count", len(rows)),
            ("Source Tables", "dbo.prj_attribute_master_new_test + dbo.prj_attribute_business_rules_new_test"),
        ]
        for row_index, pair in enumerate(metadata, start=1):
            meta.cell(row=row_index, column=1, value=pair[0]).font = Font(bold=True)
            meta.cell(row=row_index, column=2, value=pair[1])
        meta.column_dimensions["A"].width = 24
        meta.column_dimensions["B"].width = 80

        stream = io.BytesIO()
        workbook.save(stream)
        return stream.getvalue()
