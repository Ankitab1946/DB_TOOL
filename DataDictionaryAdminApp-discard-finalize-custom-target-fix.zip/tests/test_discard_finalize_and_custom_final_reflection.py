from __future__ import annotations

from pathlib import Path

from sqlalchemy import create_engine, select, text
from sqlalchemy.orm import Session

import DataDictionaryAdminApp.core.database  # register SQL rewrite listener
from DataDictionaryAdminApp.core.target_tables import TARGET_TABLE_DEFAULTS, build_table_rewrites
from DataDictionaryAdminApp.model.entities import (
    AttributeBusinessRule,
    AttributeDisplay,
    AttributeMaster,
    PortfolioReference,
    RawAttribute,
    StagingAttributeDisplay,
    StagingAttributeMaster,
    StagingBusinessRule,
)
from DataDictionaryAdminApp.service.data_dictionary_service import DataDictionaryService

ROOT = Path(__file__).resolve().parents[1]
UI = (ROOT / "src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
ROUTER = (ROOT / "src/DataDictionaryAdminApp/api/routers/data_dictionary.py").read_text(encoding="utf-8")
REPO = (ROOT / "src/DataDictionaryAdminApp/repositories/data_dictionary_repository.py").read_text(encoding="utf-8")


def _engine_with_dictionary_tables():
    engine = create_engine("sqlite+pysqlite:///:memory:", future=True)
    with engine.begin() as conn:
        conn.exec_driver_sql("ATTACH DATABASE ':memory:' AS stg")
        conn.exec_driver_sql("ATTACH DATABASE ':memory:' AS dbo")
        # Create only the tables needed by delta/discard in dependency order.
        for table in (
            PortfolioReference.__table__,
            AttributeMaster.__table__,
            StagingAttributeMaster.__table__,
            AttributeBusinessRule.__table__,
            AttributeDisplay.__table__,
            StagingBusinessRule.__table__,
            StagingAttributeDisplay.__table__,
            RawAttribute.__table__,
        ):
            table.create(conn, checkfirst=True)
    return engine


def test_discard_finalize_removes_only_selected_staging_and_preserves_final():
    engine = _engine_with_dictionary_tables()
    with Session(engine) as session:
        session.add(
            AttributeMaster(
                prj_id="PRJ1",
                prj_attribute_name="Final Revenue",
                prj_attribute_definition=None,
                prj_physical_attribute_name="final_revenue",
                where_in_financial_statement="Income",
                is_active=True,
                created_by="tester",
                updated_by="tester",
            )
        )
        session.add_all(
            [
                StagingAttributeMaster(
                    prj_id="PRJ1",
                    prj_attribute_name="Edited Revenue",
                    prj_attribute_definition=None,
                    prj_physical_attribute_name="final_revenue",
                    where_in_financial_statement="Income",
                    is_active=True,
                    created_by="tester",
                    updated_by="tester",
                ),
                StagingAttributeMaster(
                    prj_id="PRJ2",
                    prj_attribute_name="Brand New",
                    prj_attribute_definition=None,
                    prj_physical_attribute_name="brand_new",
                    where_in_financial_statement="NA",
                    is_active=True,
                    created_by="tester",
                    updated_by="tester",
                ),
                RawAttribute(
                    raw_row_id=1,
                    portfolio="Corporate",
                    prj_id="PRJ2",
                    prj_attribute_name="Brand New",
                    prj_physical_attribute_name="brand_new",
                    section="N/A",
                    sub_section="N/A",
                    calculated_or_reported="Reported",
                    calculation_logic="NA",
                    segment="NA",
                    report_type="NA",
                    display_order=1,
                    is_active=True,
                    created_by="tester",
                    updated_by="tester",
                ),
            ]
        )
        session.commit()

        service = DataDictionaryService(session)
        before = service.delta()
        assert {row["prj_id"] for row in before["rows"]} == {"PRJ1", "PRJ2"}

        result = service.discard_finalize("tester", ["PRJ2"], True)
        assert result["discarded"] == 1
        assert result["prj_ids"] == ["PRJ2"]
        assert result["new_prj_ids_removed_from_raw"] == ["PRJ2"]

        # Existing pending PRJ1 remains staged and its Final row is unchanged.
        assert session.get(StagingAttributeMaster, "PRJ1") is not None
        assert session.get(StagingAttributeMaster, "PRJ2") is None
        assert session.get(AttributeMaster, "PRJ1").prj_attribute_name == "Final Revenue"
        assert session.get(AttributeMaster, "PRJ2") is None
        assert session.scalars(select(RawAttribute).where(RawAttribute.prj_id == "PRJ2")).all() == []

        after = service.delta()
        assert [row["prj_id"] for row in after["rows"]] == ["PRJ1"]


def test_discard_finalize_api_and_ui_selection_contract():
    assert '@router.post("/discard-finalize")' in ROUTER
    assert 'selection_mode="multi-row"' in UI
    assert '"Discard Selected Changes"' in UI
    assert '"/data-dictionary/discard-finalize"' in UI
    assert '"Yes, Discard Selected"' in UI
    assert 'Actual / Final tables were not changed' in UI


def test_custom_target_reflection_does_not_follow_legacy_fk_targets():
    engine = create_engine("sqlite+pysqlite:///:memory:", future=True)
    with engine.begin() as conn:
        conn.exec_driver_sql("ATTACH DATABASE ':memory:' AS stg")
        conn.exec_driver_sql("ATTACH DATABASE ':memory:' AS dbo")
        conn.exec_driver_sql("""
            CREATE TABLE stg.prj_attribute_master_new_test (
                prj_id TEXT PRIMARY KEY, prj_attribute_name TEXT NOT NULL,
                prj_attribute_definition TEXT, prj_physical_attribute_name TEXT NOT NULL,
                where_in_financial_statement TEXT NOT NULL, is_active BOOLEAN NOT NULL)
        """)
        conn.exec_driver_sql("""
            CREATE TABLE stg.prj_attribute_business_rules_new_test (
                scope_id INTEGER PRIMARY KEY, prj_id TEXT NOT NULL, port_ref_id INTEGER NOT NULL,
                source_abbr_name TEXT NOT NULL, prompt_description TEXT, examples_for_llm TEXT,
                editable TEXT NOT NULL, data_type TEXT, attribute_type TEXT NOT NULL,
                business_logic TEXT, calculation_logic TEXT NOT NULL)
        """)
        conn.exec_driver_sql("""
            CREATE TABLE stg.prj_attribute_display_test (
                display_id INTEGER PRIMARY KEY, scope_id INTEGER NOT NULL, display_order INTEGER NOT NULL,
                prj_id TEXT NOT NULL, display_name TEXT, section TEXT, subsection TEXT,
                prj_attribute_definition TEXT, prj_attribute_description TEXT,
                segment TEXT NOT NULL, report_type TEXT NOT NULL)
        """)
        conn.exec_driver_sql("CREATE TABLE dbo.raw_prj_attribute_new_test (raw_row_id INTEGER PRIMARY KEY, prj_id TEXT NOT NULL)")
        conn.exec_driver_sql("""
            CREATE TABLE dbo.prj_attribute_master (
                prj_id TEXT PRIMARY KEY, prj_attribute_name TEXT NOT NULL,
                prj_attribute_definition TEXT, prj_physical_attribute_name TEXT NOT NULL,
                where_in_financial_statement TEXT NOT NULL, is_active BOOLEAN NOT NULL)
        """)
        # Legacy FK metadata still points at the old/default final basename, which
        # intentionally does not exist in this database.
        conn.exec_driver_sql("""
            CREATE TABLE dbo.prj_attribute_business_rules (
                scope_id INTEGER PRIMARY KEY, prj_id TEXT NOT NULL, port_ref_id INTEGER NOT NULL,
                source_abbr_name TEXT NOT NULL, prompt_description TEXT, examples_for_llm TEXT,
                editable TEXT NOT NULL, data_type TEXT, attribute_type TEXT NOT NULL,
                business_logic TEXT, calculation_logic TEXT NOT NULL,
                FOREIGN KEY(prj_id) REFERENCES prj_attribute_master_new_test(prj_id))
        """)
        conn.exec_driver_sql("""
            CREATE TABLE dbo.prj_attribute_display (
                display_id INTEGER PRIMARY KEY, scope_id INTEGER NOT NULL, display_order INTEGER NOT NULL,
                prj_id TEXT NOT NULL, display_name TEXT, section TEXT, subsection TEXT,
                prj_attribute_definition TEXT, prj_attribute_description TEXT,
                segment TEXT NOT NULL, report_type TEXT NOT NULL,
                FOREIGN KEY(scope_id) REFERENCES prj_attribute_business_rules_new_test(scope_id))
        """)
        conn.exec_driver_sql("""
            INSERT INTO stg.prj_attribute_master_new_test
            (prj_id,prj_attribute_name,prj_physical_attribute_name,where_in_financial_statement,is_active)
            VALUES ('PRJ9','Revenue','revenue','Income',1)
        """)

    names = dict(TARGET_TABLE_DEFAULTS)
    names.update({
        "final_master": "prj_attribute_master",
        "final_business": "prj_attribute_business_rules",
        "final_display": "prj_attribute_display",
    })
    routed = engine.execution_options(target_table_rewrites=build_table_rewrites("SQLSERVER", "prj_dbd", names))
    with Session(routed) as session:
        session.info["target_table_names"] = names
        service = DataDictionaryService(session)
        result = service.delta()
        assert result["has_changes"] is True
        assert result["rows"][0]["prj_id"] == "PRJ9"
        discarded = service.discard_finalize("tester", ["PRJ9"], True)
        assert discarded["discarded"] == 1
        assert session.execute(
            text("SELECT count(*) FROM stg.prj_attribute_master_new_test WHERE prj_id='PRJ9'")
        ).scalar_one() == 0

    assert "resolve_fks=False" in REPO
    assert "target_table_rewrites=()" in REPO
