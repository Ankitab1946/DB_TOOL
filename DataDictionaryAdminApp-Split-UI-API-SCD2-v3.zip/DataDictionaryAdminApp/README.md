# DataDictionaryAdminApp (Streamlit UI)

UI-only deployment for the PRJ Data Dictionary Administration Platform.

- Runs Streamlit on port 8501.
- Performs all persistence/business operations through `API_BASE_URL`.
- Contains no SQLAlchemy models, repositories, FastAPI routers, or database credentials.
- Keeps client-side field normalization, target-table header validation and Excel UI constants required by the existing screens.

Default local API: `http://localhost:8503/api/v1`.

## Deployment
Set `API_BASE_URL` to the deployed `DataDictionaryAdminAppAPI` base URL ending in `/api/v1`. No database, Vault, SQLAlchemy, ODBC or PostgreSQL credentials are required in the UI deployment.
