from pathlib import Path

from DataDictionaryAdminApp.api.schemas_api import AttributeUpsert
from DataDictionaryAdminApp.utils.normalizers import normalize_pipe_values, split_pipe_values


def test_pipe_values_are_trimmed_deduplicated_and_ordered():
    assert normalize_pipe_values(" Assets | Liabilities | Assets |  ") == "Assets|Liabilities"
    assert split_pipe_values("Current|Non-Current|Current") == ["Current", "Non-Current"]


def test_attribute_payload_accepts_multiple_sections_and_subsections():
    payload = AttributeUpsert(
        portfolio="FI Banks",
        prj_attribute_name="Test Attribute",
        section="Balance Sheet | Income Statement",
        sub_section="Assets | Revenue",
        calculated_or_reported="Reported",
        display_order=1,
    )
    assert payload.section == "Balance Sheet|Income Statement"
    assert payload.sub_section == "Assets|Revenue"


def test_bulk_performance_optimizations_are_present():
    root = Path(__file__).parents[1] / "src" / "DataDictionaryAdminApp"
    service = (root / "service" / "data_dictionary_service.py").read_text(encoding="utf-8")
    repo = (root / "repositories" / "data_dictionary_repository.py").read_text(encoding="utf-8")
    ui = (root / "streamlit_app.py").read_text(encoding="utf-8")

    assert "prepare_bulk_cache" in service
    assert 'preload_state(id_set, "stg")' in service
    assert 'preload_state(id_set, "dbo")' in service
    assert "emit_deferred_insert_audits" in repo
    assert "_source_table_cache" in repo
    assert "create_next_prj_id" in ui
    assert "Separate multiple values with | (pipe)." in ui
