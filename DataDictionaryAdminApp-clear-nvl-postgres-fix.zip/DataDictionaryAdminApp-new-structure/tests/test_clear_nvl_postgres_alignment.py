from pathlib import Path
import re

from sqlalchemy import delete, select, true, update
from sqlalchemy.dialects import postgresql

from DataDictionaryAdminApp.model.entities import (
    AttributeBusinessRule,
    AttributeMaster,
    AuditTable,
    PortfolioReference,
    RawAttribute,
    StagingAttributeMaster,
    StagingBusinessRule,
)
from DataDictionaryAdminApp.utils.normalizers import generate_tech_logic


STREAMLIT = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
PG_SQL_DIR = Path("src/DataDictionaryAdminApp/sql/postgres")


def test_clear_filters_explicitly_blank_visible_widget_state():
    block = STREAMLIT.split("def clear_view_filters()", 1)[1].split("def database_status_check", 1)[0]
    assert '"view_portfolio_filter": []' in block
    assert '"view_source_filter": []' in block
    assert '"view_prj_id_filter": ""' in block
    assert '"view_attribute_name_filter": ""' in block
    assert '"view_attribute_definition_filter": ""' in block
    assert '"view_section_filter": ""' in block
    assert '"view_subsection_filter": ""' in block
    assert '"view_search_filter": ""' in block
    assert '"view_overlapped_filter": False' in block
    assert '"view_include_inactive_filter": False' in block
    assert '"view_page_number_filter": 1' in block
    assert '"view_page_size_filter": 100' in block


def test_tech_logic_preserves_nvl_and_bodmas_while_removing_label_slashes():
    assert generate_tech_logic(
        "Total Income(PRJ362) = EBITDA(PRJ43843) /nvl(Debt/Amount(PRJ4343)+ EBITDA(PRJ43843))"
    ) == "PRJ362 = PRJ43843/nvl(PRJ4343+PRJ43843)"
    assert generate_tech_logic(
        "Total(PRJ1) = nvl((EBITDA(PRJ2) + Debt(PRJ3)) / Amount(PRJ4), 0)"
    ) == "PRJ1 = nvl((PRJ2+PRJ3)/PRJ4,0)"


def test_core_runtime_statements_compile_for_postgres():
    dialect = postgresql.dialect()
    statements = [
        select(PortfolioReference).where(PortfolioReference.is_active == true()),
        select(AttributeMaster, AttributeBusinessRule, PortfolioReference)
        .join(AttributeBusinessRule, AttributeBusinessRule.prj_id == AttributeMaster.prj_id)
        .join(PortfolioReference, PortfolioReference.port_ref_id == AttributeBusinessRule.port_ref_id)
        .where(AttributeMaster.is_active == true(), AttributeBusinessRule.is_active == true()),
        select(RawAttribute).where(RawAttribute.prj_id == "PRJ1", RawAttribute.is_active == true()),
        select(StagingAttributeMaster).where(StagingAttributeMaster.prj_id == "PRJ1"),
        select(StagingBusinessRule).where(StagingBusinessRule.prj_id == "PRJ1"),
        update(AttributeMaster).where(AttributeMaster.prj_id == "PRJ1").values(is_active=False),
        delete(AuditTable).where(AuditTable.table_name == "x"),
    ]
    compiled = [str(stmt.compile(dialect=dialect, compile_kwargs={"literal_binds": True})) for stmt in statements]
    assert all("dbo." in sql or "stg." in sql for sql in compiled)
    assert any("= true" in sql.lower() for sql in compiled)
    assert not any(" is 1" in sql.lower() for sql in compiled)


def test_postgres_ddl_validate_and_migration_cover_orm_contract():
    create_sql = (PG_SQL_DIR / "001_create_tables.sql").read_text(encoding="utf-8").lower()
    validate_sql = (PG_SQL_DIR / "002_validate_schema.sql").read_text(encoding="utf-8").lower()
    migration_sql = (PG_SQL_DIR / "003_add_scoped_definition_segment.sql").read_text(encoding="utf-8").lower()

    managed_models = (
        RawAttribute,
        PortfolioReference,
        AuditTable,
        StagingAttributeMaster,
        StagingBusinessRule,
        AttributeMaster,
        AttributeBusinessRule,
    )
    for model in managed_models:
        table = model.__table__
        qualified = f"{table.schema}.{table.name}".lower()
        assert qualified in create_sql

        # Fresh PostgreSQL DDL must contain every ORM column for every managed
        # table. This catches silent drift between SQL Server-oriented model work
        # and the PostgreSQL deployment scripts.
        block_match = re.search(
            rf"create table if not exists\s+{re.escape(qualified)}\s*\((.*?)\n\);",
            create_sql,
            flags=re.DOTALL | re.IGNORECASE,
        )
        assert block_match, qualified
        ddl_columns = set()
        for raw_line in block_match.group(1).splitlines():
            line = raw_line.strip().rstrip(",")
            column_match = re.match(r"([a-z_][a-z0-9_]*)\s+", line, flags=re.IGNORECASE)
            if column_match and not line.startswith("constraint"):
                ddl_columns.add(column_match.group(1).lower())
        assert {column.name.lower() for column in table.columns} == ddl_columns

        for column in table.columns:
            # PostgreSQL preflight validates the full ORM-managed column contract,
            # including audit metadata and the latest scoped rule fields.
            expected_triplet = f"array['{table.schema}','{table.name}','{column.name}']".lower()
            assert expected_triplet in validate_sql

    assert "source_code" in validate_sql
    assert "source_name" in validate_sql
    assert "add column if not exists prj_attribute_definition" in migration_sql
    assert "add column if not exists segment" in migration_sql
    assert "boolean not null default true" in create_sql
    assert "generated by default as identity" in create_sql
    assert "dbo.prj_data_sources" in validate_sql
