from fastapi import HTTPException

from DataDictionaryAdminApp.api.schemas_api import AttributeUpsert
from DataDictionaryAdminApp.service.data_dictionary_service import DataDictionaryService


class MinimalRepo:
    def physical_name_exists(self, name, exclude_prj_id=None):
        return False

    def physical_name_for_prj(self, prj_id):
        return None

    def available_physical_name(self, base_name, exclude_prj_id=None):
        return base_name


def _payload(prj_id: str, physical: str) -> AttributeUpsert:
    return AttributeUpsert(
        prj_id=prj_id,
        portfolio="FI Banks",
        source_abbr_name="SNPAR",
        prj_attribute_name="Equity Investment",
        prj_physical_attribute_name=physical,
        physical_name_source="SUPPLIED",
        section="Assets",
        sub_section="Current",
        data_type="Amount",
        calculated_or_reported="Reported",
        display_order=1,
    )


def _service() -> DataDictionaryService:
    service = DataDictionaryService(db=None)
    service.repo = MinimalRepo()
    service._portfolio_cache = {
        "fi banks": {"port_ref_id": 1, "portfolio_name": "FI", "sector_name": "Banks", "label": "FI Banks"}
    }
    service._source_name_cache = {}
    service._source_code_cache = {"snpar"}
    service._original_type_cache = {}
    return service


def test_bulk_same_cfv_case_difference_is_not_false_duplicate():
    service = _service()
    service._physical_owner_cache = {"eqty_inv": "CFV100"}
    service._physical_by_prj_cache = {"cfv100": "Eqty_inv"}

    service.validate_bulk_physical_name_uniqueness([_payload("cfv100", "Eqty_inv")])
    _, master, _ = service._make_rows(_payload("cfv100", "Eqty_inv"), bulk_physical_policy=True)
    assert master["prj_physical_attribute_name"] == "Eqty_inv"


def test_bulk_duplicate_with_existing_database_cfv_is_rejected_with_details():
    service = _service()
    service._physical_owner_cache = {"eqty_inv": "CFV100"}
    service._physical_by_prj_cache = {"cfv100": "Eqty_inv"}

    try:
        service.validate_bulk_physical_name_uniqueness([_payload("CFV200", "Eqty_inv")])
    except HTTPException as exc:
        assert exc.status_code == 409
        assert isinstance(exc.detail, dict)
        duplicate = exc.detail["duplicates"][0]
        assert duplicate["physical_attribute_name"] == "Eqty_inv"
        assert set(duplicate["cfv_ids"]) == {"CFV100", "CFV200"}
        assert duplicate["existing_database_cfv_id"] == "CFV100"
    else:
        raise AssertionError("Cross-CFV duplicate must be rejected")


def test_bulk_duplicate_inside_workbook_is_rejected_and_not_auto_renamed():
    service = _service()
    service._physical_owner_cache = {}
    service._physical_by_prj_cache = {}

    try:
        service.validate_bulk_physical_name_uniqueness([
            _payload("CFV1", "Eqty_inv"),
            _payload("CFV2", "Eqty_inv"),
        ])
    except HTTPException as exc:
        assert exc.status_code == 409
        duplicate = exc.detail["duplicates"][0]
        assert set(duplicate["cfv_ids"]) == {"CFV1", "CFV2"}
        assert duplicate["existing_database_cfv_id"] is None
    else:
        raise AssertionError("Workbook duplicate must be rejected instead of auto-renamed")


def test_repeated_scope_rows_for_same_cfv_are_allowed():
    service = _service()
    service._physical_owner_cache = {}
    service._physical_by_prj_cache = {}
    service.validate_bulk_physical_name_uniqueness([
        _payload("CFV1", "Eqty_inv"),
        _payload("cfv1", "EQTY_INV"),
    ])


def test_ui_create_edit_still_rejects_true_cross_cfv_duplicate():
    service = _service()
    service._physical_owner_cache = {"eqty_inv": "CFV1"}
    service._physical_by_prj_cache = {"cfv1": "Eqty_inv"}

    try:
        service._make_rows(_payload("CFV2", "Eqty_inv"), bulk_physical_policy=False)
    except HTTPException as exc:
        assert exc.status_code == 409
        assert "already exists for another PRJ ID" in str(exc.detail)
    else:
        raise AssertionError("UI duplicate physical name should remain a conflict")
