from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / "src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
REPO = (ROOT / "src/DataDictionaryAdminApp/repositories/data_dictionary_repository.py").read_text(encoding="utf-8")
LOOKUPS = (ROOT / "src/DataDictionaryAdminApp/api/routers/lookups.py").read_text(encoding="utf-8")


def test_create_edit_modal_uses_native_dialog_without_backdrop_position_override():
    assert '@st.dialog("Create New Attribute", width="large")' in APP
    assert '@st.dialog("Edit Attribute", width="large")' in APP
    assert '[data-testid="stDialog"] [role="dialog"]' in APP
    assert "data-modal-container='true'" not in APP
    assert "position: fixed !important;" not in APP
    assert "display: grid !important;" not in APP


def test_postgres_next_prj_id_uses_required_physical_schemas():
    assert 'if bind.dialect.name == "postgresql":' in REPO
    assert 'main_schema = self._physical_schema("dbo")' in REPO
    assert 'staging_schema = self._physical_schema("stg")' in REPO
    assert 'stg_master_name = self.target_table_name("stg_master")' in REPO
    assert 'final_master_name = self.target_table_name("final_master")' in REPO
    assert 'UNION ALL SELECT prj_id' in REPO


def test_postgres_schema_problem_is_actionable_not_generic_500():
    assert 'HTTPException(status_code=503, detail=str(exc))' in LOOKUPS
    assert 'PostgreSQL Data Dictionary schema is not ready' in REPO


def test_postgres_next_prj_id_runtime_uses_union_query(monkeypatch):
    import DataDictionaryAdminApp.repositories.data_dictionary_repository as module
    from DataDictionaryAdminApp.repositories.data_dictionary_repository import DataDictionaryRepository

    class Dialect:
        name = "postgresql"

    class Bind:
        dialect = Dialect()

    class Inspector:
        @staticmethod
        def has_table(table, schema=None):
            return True

    class ScalarResult:
        @staticmethod
        def all():
            return ["PRJ2", "CFV19", "PRJ7"]

    class DB:
        @staticmethod
        def get_bind():
            return Bind()

        @staticmethod
        def scalars(stmt):
            sql = str(stmt)
            assert "prj_dbd.raw_prj_attribute_new_test" in sql
            assert "prj_stage.prj_attribute_master_new_test" in sql
            return ScalarResult()

    monkeypatch.setattr(module, "inspect", lambda bind: Inspector())
    assert DataDictionaryRepository(DB()).next_prj_id() == "PRJ20"


def test_postgres_next_prj_id_reports_missing_schema_table(monkeypatch):
    import pytest
    import DataDictionaryAdminApp.repositories.data_dictionary_repository as module
    from DataDictionaryAdminApp.repositories.data_dictionary_repository import DataDictionaryRepository

    class Dialect:
        name = "postgresql"

    class Bind:
        dialect = Dialect()

    class Inspector:
        @staticmethod
        def has_table(table, schema=None):
            return not (schema == "prj_stage" and table == "prj_attribute_master_new_test")

    class DB:
        @staticmethod
        def get_bind():
            return Bind()

    monkeypatch.setattr(module, "inspect", lambda bind: Inspector())
    with pytest.raises(RuntimeError, match="prj_stage.prj_attribute_master_new_test"):
        DataDictionaryRepository(DB()).next_prj_id()
