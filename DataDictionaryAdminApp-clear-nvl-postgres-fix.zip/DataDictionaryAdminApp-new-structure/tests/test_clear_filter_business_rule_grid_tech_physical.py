from pathlib import Path

from DataDictionaryAdminApp.utils.normalizers import generate_physical_name, generate_tech_logic


STREAMLIT = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
REPOSITORY = Path("src/DataDictionaryAdminApp/repositories/data_dictionary_repository.py").read_text(encoding="utf-8")


def test_clear_all_filters_is_one_click_and_triggers_refresh():
    assert 'def clear_view_filters()' in STREAMLIT
    assert '"Clear Filters"' in STREAMLIT
    assert 'on_click=clear_view_filters' in STREAMLIT
    assert 'st.session_state["filter_submit_requested"] = True' in STREAMLIT


def test_view_latest_is_business_rule_grain():
    block = REPOSITORY.split('def filter_final', 1)[1].split('def soft_deleted_rows', 1)[0]
    assert 'select(m, r, p)' in block
    assert '.join(r, r.prj_id == m.prj_id)' in block
    assert '"scope_id": rule.scope_id' in block
    assert '"section": rule.section' in block
    assert '"subsection": rule.subsection' in block


def test_tech_logic_ignores_slash_inside_label_and_preserves_bodmas_brackets():
    assert generate_tech_logic(
        "Total Income(PRJ362) = EBITDA(PRJ43843) / Debt(PRJ4343)"
    ) == "PRJ362 = PRJ43843/PRJ4343"
    assert generate_tech_logic(
        "Total Income(PRJ362) = EBITDA(PRJ43843) /Debt/Amount(PRJ4343)"
    ) == "PRJ362 = PRJ43843/PRJ4343"
    assert generate_tech_logic(
        "Total(PRJ1) = (EBITDA(PRJ2) + Debt(PRJ3)) / Amount(PRJ4)"
    ) == "PRJ1 = (PRJ2+PRJ3)/PRJ4"
    assert generate_tech_logic(
        "Total(PRJ1) = EBITDA(PRJ2) * (Debt(PRJ3) + Amount(PRJ4))"
    ) == "PRJ1 = PRJ2*(PRJ3+PRJ4)"


def test_generated_physical_name_uses_underscores_and_abbreviations():
    assert generate_physical_name("Total Income") == "tot_inc"
    assert generate_physical_name("Land & Buildings(Gross)") == "gross_land_bldgs"


def test_create_edit_modal_is_near_full_width_and_centered():
    assert 'max_width=1900' in STREAMLIT
    assert 'width: 96vw !important;' in STREAMLIT
    assert 'place-items: center !important;' in STREAMLIT
    assert 'max-height: 90vh !important;' in STREAMLIT
