from pathlib import Path

from DataDictionaryAdminApp.utils.normalizers import generate_tech_logic


SOURCE = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")


def test_requested_tech_logic_example_is_compact_and_prj_only():
    source = "Total Income(PRJ362) = EBITDA(PRJ43843) -Debt(PRJ4343)"
    assert generate_tech_logic(source) == "PRJ362 = PRJ43843-PRJ4343"


def test_calculation_details_are_collapsible_and_save_action_is_stretched():
    assert 'with st.expander("Calculation and Attribute Details", expanded=False):' in SOURCE
    assert 'tech_calc_key = f"{prefix}_tech_source_calc"' in SOURCE
    assert 'st.session_state[tech_key] = generate_tech_logic(calculation_logic)' in SOURCE
    assert '"Create Attribute" if not detail else "Save Changes"' in SOURCE
    assert 'width="stretch"' in SOURCE


def test_soft_deleted_records_use_separate_selectable_grid_and_reactivate_action():
    assert 'key="soft_deleted_grid"' in SOURCE
    assert 'selection_mode="single-row"' in SOURCE
    assert 'deleted_selected_row' in SOURCE
    assert '"Reactivate Selected Soft Deleted Record"' in SOURCE
    assert '"Select soft deleted attribute to reactivate"' not in SOURCE
