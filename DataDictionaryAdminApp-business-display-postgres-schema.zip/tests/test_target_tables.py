from DataDictionaryAdminApp.core.target_tables import APPLICATION_MANAGED_TABLES, DATA_SOURCES, S3_EXPORTS


def test_exact_managed_table_contract():
    assert APPLICATION_MANAGED_TABLES == (
        "dbo.raw_prj_attribute_new_test",
        "dbo.prj_portfolio_reference_new_test",
        "dbo.audit_table_new_test",
        "stg.prj_attribute_master_new_test",
        "stg.prj_attribute_business_rules_new_test",
        "stg.prj_attribute_display_test",
        "dbo.prj_attribute_master_new_test",
        "dbo.prj_attribute_business_rules_new_test",
        "dbo.prj_attribute_display_test",
    )
    assert DATA_SOURCES == "dbo.prj_data_sources"


def test_only_two_final_s3_extracts():
    assert len(S3_EXPORTS) == 2
    assert {table for _, table in S3_EXPORTS} == {
        "dbo.prj_attribute_master_new_test",
        "dbo.prj_attribute_business_rules_new_test",
    }
