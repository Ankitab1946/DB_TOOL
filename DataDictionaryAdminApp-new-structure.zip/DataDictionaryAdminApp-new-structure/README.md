# PRJ Data Dictionary Administration Platform v2

Poetry-based FastAPI + Streamlit application implementing the new **raw → staging → final** PRJ Data Dictionary structure with selectable **SQL Server/Azure SQL or PostgreSQL** connectivity.

## What changed from the baseline project

The application no longer uses the old `*_test` master/scope/prompt table model. Runtime code is aligned to these managed objects only:

1. `dbo.raw_prj_attribute_new_test`
2. `dbo.prj_portfolio_reference_new_test`
3. `dbo.audit_table_new_test`
4. `stg.prj_attribute_master_new_test`
5. `stg.prj_attribute_business_rules_new_test`
6. `dbo.prj_attribute_master_new_test`
7. `dbo.prj_attribute_business_rules_new_test`

`dbo.prj_data_sources` is treated as an **existing, read-only** dependency and is never created by the application. For compatibility, lookup code also accepts the singular legacy spelling `dbo.prj_data_source` if that is what exists in an environment.

## Core workflow

```text
Excel / UI create-edit-soft-delete
              |
              v
 dbo.raw_prj_attribute_new_test
              |
              v
 stg.prj_attribute_master_new_test
 stg.prj_attribute_business_rules_new_test
              |
          Delta review
              |
              v
       Finalize confirmation
              |
              v
 dbo.prj_attribute_master_new_test
 dbo.prj_attribute_business_rules_new_test
              |
       Optional S3 export
```

Every insert/update/soft-delete/finalize operation is recorded in `dbo.audit_table_new_test` with schema name, table name, record key, before value, after value, operation source, user and timestamp.

## UI

The Streamlit application contains four top-level tabs:

- **Data Dictionary**
  - View Latest with API-backed filters
  - Download Latest formatted Excel
  - Add/Edit modal using `streamlit-modal`
  - Soft Delete / Reactivate
  - Edit Latest grid with dirty-row detection
  - Upload & Edit: single sheet or multi-sheet merger
  - Delta and Finalize confirmation
  - S3 final-table export
- **Prompt Management**
  - `prompt_description` and `examples` maintained in the business-rules structure
- **Audit**
  - searchable/filterable history grid
- **Admin Tools**
  - portfolio reference maintenance and deployment commands

The left sidebar selects both the **environment** and **database engine** and shows the selected database, server/host, current user and access level. Every API call carries both selections so reads and writes stay in the chosen runtime context.

## Excel bulk upload

Bulk upload supports different settings per selected worksheet:

- Header row is 1-based and independently configurable for every sheet.
- Source columns are independently mapped to the standard data dictionary fields for every sheet.
- Portfolio can be explicitly overridden or detected from the sheet name:
  - `FI Insurance ...` → Insurance → `FI Insurance`
  - `FI Bank ...` → Banks → `FI Banks`
  - `UKC ...` → `UKC`
  - Corporate / General Industries → `Corporate`
- `MERGE` stages/upserts loaded records.
- `REPLACE` clears raw and pending staging data before loading; final tables remain unchanged until Finalize.
- Rejected rows return exact sheet/row/reason details.

### Resolved requirement ambiguities

- Default source code is **`SNPAR`**. One requirement line says `SNAR`, while the source lookup/default requirements repeatedly use `SNPAR`.
- **Display Order** maps from the workbook Display Order column. A later line says Sub-Section, but the workbook definition and staging business-rule definition have a dedicated Display Order field.
- The requirement text says both “four files” and “TWO file” for S3. This build exports the explicitly listed **two final tables**.
- The requirements ask for four UI tabs but enumerate three. The fourth tab is **Admin Tools**, keeping portfolio/reference operations out of the main workflow.

## Database setup

The application uses the same logical `dbo` and `stg` schemas on both supported engines. Run the scripts for the engine selected in the UI/API.

**SQL Server / Azure SQL**

```text
src/DataDictionaryAdminApp/sql/001_create_tables.sql
src/DataDictionaryAdminApp/sql/002_validate_schema.sql
src/DataDictionaryAdminApp/sql/003_preflight_no_legacy_tables.sql   # optional
```

**PostgreSQL 15+**

```text
src/DataDictionaryAdminApp/sql/postgres/001_create_tables.sql
src/DataDictionaryAdminApp/sql/postgres/002_validate_schema.sql
src/DataDictionaryAdminApp/sql/postgres/003_preflight_no_legacy_tables.sql   # optional
```

Both create scripts intentionally do **not** create `dbo.prj_data_sources`; that object remains the existing read-only dependency required for Source Name → Source Code lookup. The validation scripts fail if that dependency (or the singular spelling `dbo.prj_data_source`) is missing.

The seed mapping is enforced as:

| port_ref_id | portfolio_name | sector_name | UI label |
|---:|---|---|---|
| 1 | FI | Banks | FI Banks |
| 2 | FI | Insurance | FI Insurance |
| 3 | Corporate | Corporate | Corporate |
| 4 | UKC | UKC | UKC |

## Local installation

```bash
cp .env.example .env
poetry install
```

Configure `.env`. Set `SELECTED_DB_TYPE=SQLSERVER` or `POSTGRES`, enable the corresponding database settings for each environment, then start the API:

```bash
poetry run uvicorn DataDictionaryAdminApp.api.swagger_app:app --host 0.0.0.0 --port 8503
```

Start the UI in another terminal:

```bash
poetry run streamlit run src/DataDictionaryAdminApp/streamlit_app.py --server.port 8501
```

Swagger:

```text
http://localhost:8503/docs
```

## Docker

```bash
cp .env.example .env
docker compose up --build
```

Default gateway URL: `http://localhost:8080`.

## Authentication / user audit

The API obtains the audit username from `X-App-User`, `X-Forwarded-User`, the OS username, or `DEFAULT_USER`. In production, the reverse proxy/identity layer should overwrite these headers rather than accepting arbitrary client-supplied identity headers.

Admin writes are permitted only when the resolved username is present in `ADMIN_USERS`. Avoid `ADMIN_USERS=*` outside local development.

## S3-compatible storage

Configure:

```text
S3_BUCKET_NAME=
S3_ENDPOINT_URL=https://host:port
S3_USE_SSL=true
S3_VERIFY_SSL=false
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
S3_PREFIX=data-dictionary
```

The app exports timestamped CSV files for:

- `dbo.prj_attribute_master_new_test`
- `dbo.prj_attribute_business_rules_new_test`

## Validation performed in this package

```bash
python -m compileall -q src tests
PYTHONPATH=src pytest -q
```

The included tests validate exact ORM table/column alignment, SQL Server and PostgreSQL schema contracts, database-engine URL resolution, route availability, normalizers, Excel header mapping, per-sheet portfolio detection, tech-logic generation, Excel metadata/validation output and absence of runtime legacy-table dependencies. The packaged validation run currently passes **21 tests**.

> No live SQL Server or PostgreSQL instance was supplied with the request, so physical DDL execution and end-to-end database integration cannot be proven in this build environment. Run the matching `002_validate_schema.sql` against DEV before enabling writes.
