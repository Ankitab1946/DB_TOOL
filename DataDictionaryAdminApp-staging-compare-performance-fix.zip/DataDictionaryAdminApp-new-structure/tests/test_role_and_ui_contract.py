from pathlib import Path

from starlette.requests import Request

from DataDictionaryAdminApp.utils.security import current_role, require_admin


def request_with_headers(**headers: str) -> Request:
    raw_headers = [(key.lower().encode(), value.encode()) for key, value in headers.items()]
    return Request({"type": "http", "method": "GET", "path": "/", "headers": raw_headers})


def test_explicit_admin_role_is_admin():
    request = request_with_headers(**{"X-App-Role": "ADMIN", "X-App-User": "tester"})
    assert current_role(request) == "ADMIN"
    assert require_admin(request) == "tester"


def test_explicit_user_role_is_not_admin():
    request = request_with_headers(**{"X-App-Role": "USER", "X-App-User": "tester"})
    assert current_role(request) == "USER"
    try:
        require_admin(request)
    except Exception as exc:
        assert getattr(exc, "status_code", None) == 403
    else:
        raise AssertionError("USER role must not pass require_admin")


def test_streamlit_ui_contains_required_controls_and_role_gating():
    source = Path("src/DataDictionaryAdminApp/streamlit_app.py").read_text(encoding="utf-8")
    assert '"Database Type"' in source
    assert 'db_types = ["SQLSERVER", "POSTGRES"]' in source
    assert '"Application Role"' in source
    assert 'roles = ["ADMIN", "USER"]' in source
    assert '"Create New Attribute"' in source
    assert 'workflow_labels = ["View / Edit Latest"]' in source
    assert 'if is_admin and upload_tab is not None:' in source
    assert 'if is_admin and c2 is not None:' in source
    assert '"Save Final Tables to S3"' in source
    assert '"View Soft Deleted Records"' in source
    assert '"Data starts at row (1-based)"' in source
    assert '["MERGE", "INSERT_ONLY", "REPLACE"]' in source
    assert '"Portfolio"' in source
